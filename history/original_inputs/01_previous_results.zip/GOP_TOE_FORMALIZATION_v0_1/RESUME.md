# Resume contract

1. Read STATE.json, PROGRESS.md, NEXT_ACTION.md, configs/compute_budget.json and sources/MASTER_PROMPT.md.
2. Inspect logs for an active process before launching anything. The delivered archive will identify whether any process is active; never assume background persistence.
3. Keep original source, frozen candidates, fitted weights, predictions and evaluations unchanged. Verify SHA256SUMS.txt for archived bytes.
4. Reproduction smoke belongs in a fresh output directory. Do not overwrite confirmation evidence.
5. Revisions after locked evaluation require a new scientific version and untouched mechanism-level evaluation. New noise seeds alone are not mechanism replication.
6. Read results/REQUIREMENTS_AUDIT.csv for remaining work. NOT_EXECUTED/UNRESOLVED fields are not positive findings.
