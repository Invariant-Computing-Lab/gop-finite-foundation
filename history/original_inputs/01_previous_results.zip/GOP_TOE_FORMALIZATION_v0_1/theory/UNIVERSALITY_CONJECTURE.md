# The universality conjecture and its accountable F0 instance

Scientific version: F0, defined before locked benchmark scoring. This is a proposed restricted architecture, not an established physical law. The source paper's unrestricted state-space notation was explicitly bookkeeping (source paper, section 3); the following restrictions are new study proposals.

## U0, U1 and U2

**U0, representation.** Processes, observation apparatus, internal records, actions, signal carriers and receivers can be represented in a common typed composition language. This is much weaker than physical unification.

**U1, restricted prediction.** The concrete F0 architecture below imposes shared restrictions on generators, instruments, memory and admissible coordinates. World-specific constants are allowed; family-specific unlimited functions, decoders and hidden lifts are not.

**U2, physical unification.** Every physically realizable process, whether agentive or not, is conjectured to admit an accountable realization under one common law architecture; sensing, knowing, communicating and acting are processes inside that architecture. This is the intended universal claim, not a conclusion of the study. A non-agentive physical interaction is not called an occupation by this claim.

The unrestricted existence statement “some future architecture L explains all physics” is not operationally falsifiable on its own. We therefore put its *specific F0 instantiation* at risk; failure of F0 does not prove that no future common architecture exists.

## Quantified finite-resolution claim

An admissible physical regime R declares: a subsystem boundary; physically measurable coordinates with units; a compact preparation domain K; initial distributions; admissible apparatus and intervention sequences I; output coordinates; resolution scales s_j>0; a sampling interval h; a finite horizon T=Nh; and a resource budget B. Define the dimensionless recorded trajectory distance

`d_N(y,y') = min(1, max_{0<=n<=N,j} |y_nj-y'_nj|/s_j)`.

For finite outcomes use discrete distance 1 for unequal outcomes. Let W_d denote the Wasserstein-1 distance for this bounded metric; unlike total variation it remains informative for slightly displaced deterministic trajectories. The finite F0 claim is:

`for every admissible R, K, I, N and declared resolution epsilon, there exist theta_R and an admissible affine coordinate map g_R, of total description length <= B(R,epsilon,N), such that sup_{u in I} W_d(P_R^{u,N}, P_F0(theta_R,g_R)^{u,N}) <= epsilon`.

The map and parameters are fixed before evaluation interventions or output trajectories are seen. Initial/boundary data do not encode future answers. The unification conjecture additionally requires the same architecture to cover mechanics, stochastic thermodynamics, quantum dynamics, local propagation, gravity and interacting fields. These remain separate obligations even when no test is executable.

For this finite study, B means at most 16 physically declared real state coordinates per subsystem block, a known finite interaction graph, polynomial degree at most 2 in each elementary classical map, one explicit previous-message buffer per declared link, and at most 2 qubits in executed quantum examples. The total block count and graph, not just the size of each block, must be frozen for each regime; adding auxiliary nodes counts as a model revision. The autonomous drift witness has exactly one block, one coordinate and no instruments, buffers or auxiliary subsystems. Coefficients are IEEE-754 float64, with exact stored arrays and dimensions; every coefficient, coordinate calibration, buffer and initialization rule counts. A local polynomial with d input scalars and m outputs uses at most `m[1+d+d(d+1)/2]` coefficients, plus separately counted controls/noise. The numerical quantum restriction is a study scope, not a claim that the universe has two qubits. The degree, physical-coordinate and memory restrictions are candidate restrictions.

This is a deliberately stringent candidate. The statement for every epsilon cannot be rescued by raising polynomial degree, adding undeclared physical variables, nonlinear latent embeddings or hidden buffers after failure. Those changes create F1. An empirically meaningful finite instance fixes epsilon, horizon and budget before evaluation; finite synthetic success supports only that instance.

## What F0 shares and what it fits

Shared and frozen: causal ordering, typed classical/quantum composition, degree bound, constant diffusion restriction, locality rule, coordinate class, buffer depth, solver policy, parameter-count accounting and scoring contract. There is **no demonstrated single numerical constant** fitted across all domains. Shared architecture with separately fitted coefficients is less than a single derived physical law.

World parameters include masses, frequencies, damping, couplings and noise scales. Sensor calibration is distinct from those parameters. Agent/controller policies and synthetic target definitions are distinct from physical constants. Initial states and imposed experimental schedules are neither fitted laws nor universal constants. All quantities fitted on development data must be frozen at transfer; any target-world refit is explicitly few-shot adaptation with a reported budget.

## Prohibited outcomes and a decisive witness

At a fixed declared physical state with no additional degrees of freedom, F0-G forbids a cubic drift term. It forbids state-dependent diffusion in this classical sector, instantaneous controllable influence across disconnected factors, negative quantum probabilities and arbitrary copying of unknown quantum states. An omitted delay cannot become a free hidden state after evaluation.

The testable generator-level subcommitment **G0** adds to the trajectory criterion: when a regime has declared infinitesimal drift `b_R(x)=lim_{h->0} E[(X_(t+h)-X_t)/h | X_t=x]`, the same declared-state model must satisfy `sup_K |b_R-b_F0|<=epsilon_b` in the physically calibrated dimensionless coordinate. No additional clocked instrument jumps or auxiliary dynamics may imitate this autonomous drift. G0 is an additional explicit restriction, not something implied by a finite-time Wasserstein score.

On K=[-1,1], the smooth confining deterministic process `dx/dt=-x-x^3` supplies a constructive witness against G0. No quadratic polynomial q has `sup_K |-x-x^3-q(x)|<1/4`. Its best quadratic approximation is `q(x)=-7x/4`, attaining error 1/4. This follows from the four alternating points in the proof supplement. Thus G0 fails for this ordinary effective regime whenever epsilon_b<1/4 under the fixed physical-coordinate, one-node and one-state budget. A cubic-force oscillator gives the same component-wise obstruction. The conjunction of F0's intended universal commitments therefore fails this particular necessary subcommitment. This does not by itself falsify the more permissive finite-time trajectory encoding claim, nor an architecture allowed to add nonlinear lifts or extra physical subsystems. It is an analytic model-class counterexample, not evidence of a newly discovered violation of nature or proof that an effective cubic equation is physically fundamental.

The learned degree-2 one-step benchmark model is denoted **F0-P**. It is a tractable transition surrogate, not the exact finite-time map of every F0-G generator: even a quadratic ODE can have a rational or nonpolynomial flow. F0-P predictive failure therefore does not by itself falsify F0-G. The analytic drift witness does. Conversely success of F0-P establishes neither recovery of a generator nor physical unification.

## Additional reality/observation thesis

H_obs states that empirical knowledge records depend on embodied/apparatus-mediated observation, representation, communication and intervention. The larger ontological H_reality, that these relations constitute physical reality in a stronger sense, is retained as a separate author-motivated hypothesis. No manipulation of observer records here discriminates that thesis from observer-independent ontologies producing the same records. The study neither proves nor operationally falsifies H_reality. Human observation is not assumed to create physical existence.

## Inputs and intended outputs

| Input assumption | Permitted derived/tested output | Not established |
|---|---|---|
| Classical probabilities, Brownian noise, declared SDE | Normalized trajectories under well-posedness; predictions | Origin of probability or stochasticity |
| Euclidean coordinates, time parameter, known graph | Coordinate covariance and discrete locality | Spacetime or Lorentz covariance |
| Chosen harmonic Hamiltonian | Its energy-conservation identity and numerical residual | Derivation of Hamilton's principle |
| Reservoir temperature and fluctuation-dissipation relation | Gibbs stationary density in the selected Langevin submodel | General second law or thermodynamic unification |
| Hilbert space, Born rule, GKSL generator, CP instruments | Validity, backaction and dephasing predictions | Derivation of quantum mechanics |
| Known intervention targets and sensor gains | Identifiability conditional on those assumptions | Automatic causal discovery |
| Designer viability/goal variables | Synthetic task consequences of communication/control | Human meaning, consciousness, clinical utility or autonomous agency |

Institutional scope is unchanged: this is a study within the existing architecture, not a fifth program; RARI, OCIL/OCIR, AFC and SACRA retain their separate responsibilities and validation needs.
