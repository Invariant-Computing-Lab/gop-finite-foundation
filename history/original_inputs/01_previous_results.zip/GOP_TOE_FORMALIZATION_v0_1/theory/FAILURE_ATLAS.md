# Failure atlas and interpretation boundaries

Negative findings are retained. None is averaged away by successes in other regimes. Predictor benchmark failures, generator obstructions, observation ambiguity, integration error and missing physics are different failure types.

| Failure | Exact scope and evidence | Consequence | What would count as a revision |
|---|---|---|---|
| Cubic autonomous drift cannot meet quadratic G0 tolerance below 1/4 | Fixed calibrated scalar state, one node, no jumps/lifts; proof P7 | F0's same-state infinitesimal drift subcommitment fails | F1 adds a cubic term, with one extra scalar coefficient in the witness |
| F1 cubic library cannot uniformly approximate quintic drift below 1/16 | Fresh mechanism `-x-x^5`; `results/generator_revision/summary.json` | The cubic repair does not rescue universal polynomial adequacy | New degree/library/state assumptions; not retrospective reuse of this opened test as confirmation |
| Inverse-square force is not a quadratic polynomial in resolved radial coordinate | `results/physics_newton_raw.npz`; nonzero third divided difference | Exact direct-coordinate force restriction fails | Declare a different physically justified representation and its extra complexity |
| Autonomous Hermitian-Pauli dissipators are unital | Maximally mixed input versus amplitude damping, trace-distance gap about .122108 | This unconditional reduced generator library is too narrow | General jump library/Kossakowski matrix or a declared physical dilation; measurement feedback is a different scope |
| Reduced quantum state is not sufficient for a memory-bearing future | Two-qubit retained-environment witness, reduced distances 1,0,1 | Memoryless reduced closure fails | Include the environment/process history; the already augmented two-qubit model is not falsified |
| Passive sum observation is non-injective | `(x1,x2)` and `(x1+delta,x2-delta)` | No unique inverse without extra information | A selective intervention or defensible prior |
| Unknown sensor gain leaves a scale gauge | `(g,x)` and `(g/c,cx)` induce the same readings | Only gain-times-components identifiable | Independently calibrated reference/gain |
| Nearly null intervention is ill-conditioned | At k=1.001, sigma=.03, Var(x1-hat)=1800 | Full rank is not useful precision | A larger correctly labeled intervention within physical constraints |
| Wrong intervention labels give bias | True k=2, analyst k=1.5, true x=(.7,-.2), estimate=(1.4,-.9) | More noise replicates do not remove structural bias | Correct target/strength labels and check stationarity |
| Saturation destroys distinctions | States (1,1) and (2,2) both give clipped readings (1,1) at k=2 | Observation cannot be inverted uniquely | Different sensor range or additional measurements |
| Euler-Maruyama has finite-step bias | F0-G scalar solver endpoint errors .0112723, .00553019, .00273949 for h=.1,.05,.025 | Integrator error is distinct from theory failure | Smaller h or a better solver with a convergence check |
| Relativity, GR and QFT bridges absent | No covariant metric/field construction or interaction recovery | Physical unification remains unresolved | Explicit map, field dynamics, limits and discriminating predictions |
| Apparatus/reservoir energy accounting incomplete | Prescribed hybrid measurement/actuator/channel maps | Global closure is not established | Physical apparatus and reservoir variables with energy/entropy balances |
| Human meaning/autonomy not established | Designer targets and feedback controllers | Synthetic proxy performance cannot validate lived meaning or occupational benefit | Separate construct validation and human evidence |

## Actually executed transparent identification checks

The toy used one stationary latent state and 100,000 Gaussian noise replicates, reusing the same noise draws to compare intervention strengths. These are not 100,000 independent worlds. The empirical covariance differed from the analytic covariance by approximately 0.49%, 0.31%, 0.29% and 0.29% for k=2,1.1,1.01,1.001, respectively. Nominal componentwise 95% Gaussian intervals covered approximately 95%; this conditional known-model check is not a distribution-shift guarantee. Gain-gauge and wrong-label equations agreed to floating-point precision. Symbolic-package verification was unavailable; the written elementary algebra and numerical inverse checks are separately retained.

## Actually executed hybrid construction check

The F0-G module generated 256 conditioned hybrid steps. Density-matrix eigenvalues stayed nonnegative (minimum approximately 4.76e-6), trace errors were below 4.45e-16 and instrument branch probabilities summed to one within 4.45e-16. The selected dephasing channel matched its analytic form to displayed floating precision; its Choi matrix was positive semidefinite within tolerance. These are software/consistency checks under an imported quantum model. They are not evidence for a new quantum law.

## Predictor benchmark results

The saved benchmark status and raw world-level metrics are authoritative for F0-P and its baselines. Poor finite-step observed-coordinate performance does not automatically identify which generator or observation assumption failed. In particular, a quadratic generator's exact flow is not generally a quadratic transition. The final synthesis must therefore preserve F0-P and F0-G labels. No result from a domain-specific oracle comparator may be counted as a learned-model victory.
