# Frozen synthetic causal control specification

This suite supplements the fitted forecasting experiments. It uses independently
specified deterministic finite mechanisms and fixed random seed 20261002.
It does not fit models, use locked forecast data, or estimate population effects.
Every result is a synthetic observation or exhaustive finite-state check.
One CPU thread; intended runtime below 30 seconds. All numbers are in fixed
dimensionless reference units. Source: `src/control_checks.py`.

Before executing the suite, hash this specification and source into
`configs/control_checks_freeze.json`. Outputs: `results/controls/summary.json`
and `results/controls/control_arrays.npz`.

1. **Resource regulation.** Compare passive, reactive, and integral controllers
   under identical initial resource r=1 and the same 1,000-step external supply.
   dt=.05; capacity=2; maintenance=.16; action cost=.06*a^2; initial a=.5.
   Supply is .60 + .05 sin(.031t), reduced by .30 at steps 300–649.
   Passive a=.5; reactive a=clip(.5+.9*(1-r),0,1); adaptive adds m with
   m'=clip((1-.12dt)m+dt*(1-r),-1,1). Report resource minimum, absolute target
   error, fraction r>.25, total action cost, and exact budget residual.
   A controller advantage is neither required nor interpreted as autonomous
   agency. Residual tolerance 1e-12; trajectory differences are descriptive.

2. **Communication and goals.** Use 2,048 fixed-seed uniform binary ±1 messages,
   faithfully encoded with gain -2 and decoded by the known inverse. Report
   bit accuracy and empirical source entropy/mutual information. Flipping a
   receiver's assigned goal while retaining its old action policy must make
   task accuracy zero despite perfect transmission; corrected policy must
   recover accuracy one. Paired source do(+1)/do(-1) with identical channel
   noise must produce receiver difference 2 when connected and exactly zero
   when disconnected. No human semantic meaning is inferred.

3. **Memory witness.** Histories with identical current and one-lag emissions,
   identical current receiver state, but distinct emissions two lags earlier
   under delay=3 must produce distinct next receiver states. This disproves a
   deterministic predictor restricted to those identical observed inputs for
   that observation boundary. It does not disprove an adequately augmented
   latent Markov process.

4. **Coactivity/common cause.** A 256-step common input drives two uncoupled
   scalar AR(.8) systems. Start equally at zero, giving correlation one.
   At step 40 intervene on first coordinate ±.5, holding input and all other
   quantities fixed. Difference in the second system one update later must
   be zero without coupling and .12 with coupling .12. A common signal alone
   therefore cannot establish dyadic causal organization.

5. **Observation/discrimination.** Four equiprobable states (±1,±1) observed
   through A=((0,2),(-.5,0)). Correct inversion must have error zero and
   nearest-state discrimination accuracy one. A wrong calibration that flips
   the first recovered coordinate must have accuracy zero. A constant zero
   embedding must have accuracy .25 under fixed deterministic tie breaking.
   Invariance alone is not sufficient; retained discrimination is required.

6. **Reversibility/erasure/provenance.** Exhaust all eight 3-bit inputs. Rotate
   after CNOT must have eight distinct outputs; erasing the middle bit must
   have four. Retaining the erased input bit in a separate provenance register
   must restore eight distinguishable augmented outputs. Report counts and
   log2 counts. Mathematical zero is an ordinary bit value; it is not absence
   or universal annihilation. Logical counts do not imply a thermodynamic
   Landauer experiment.

Tolerances are floating-point software tolerances, not practical statistical
effect-size margins. No p-values, population confidence intervals, or empirical
clinical interpretations are claimed. All finite counterexamples retain
assumptions and their exact limited implication in the output.
