# Prospective intervention-design control

This separate control was specified after construction of the main candidate.
It does not change any frozen generator, forecast protocol, model or previous
result. Freeze this specification and `src/intervention_design_control.py`
before generating its Monte Carlo noise. It provides no new candidate
intervention-selection algorithm: the fixed informative intervention is compared
with an ordinary D-optimal choice, and they coincide by construction.

## Observation model and equal budget

Stationary unknown state x=(1,-.4) for Monte Carlo verification; x is not given
to the estimator. Every acquisition has exactly two independent measurements:
`y0=x1+x2+e0`, `yu=k*x1+x2+eu`; e0,eu iid N(0,sigma²), sigma=.03.
The intervention affects only the first component and does not otherwise alter
the unknown state or sensor. Costs are equal by assumption for k in [1.1,2].
Changing this cost assumption changes the optimization problem.

Comparators: passive k=1; random k~Uniform[1.1,2]; fixed informative k=2;
conventional D-optimal k=2. No strategy gets extra observations, truth inputs,
fitting data, or a larger intervention range. These are repeated acquisitions
of one fixed synthetic state, not independent worlds or participant data.

## Analytic predictions frozen before simulation

With h=k-1 and M=((1,1),(k,1)), Fisher information is J=MᵀM/sigma².
`det J=h²/sigma⁴`; `logdet J=2log|h|-4log sigma`; its derivative for k>1
is 2/h>0. Thus the D-optimal solution is k=2 under the stated constraints.

For k≠1 the exact inverse estimator has covariance

    sigma² * [[2/h², -(k+1)/h²],
              [-(k+1)/h², (k²+1)/h²]].

At k=2 this is sigma²*((2,-3),(-3,5)), giving mean squared Euclidean error
7 sigma². With random h~Uniform[a,b], a=.1,b=1,

    E[h^-2]=(1/a-1/b)/(b-a),
    E[h^-1]=log(b/a)/(b-a),
    E[Cov]/sigma² = [[2 E[h^-2], -E[h^-1]-2 E[h^-2]],
                    [-E[h^-1]-2 E[h^-2], 1+2 E[h^-1]+2 E[h^-2]]].

The random estimator remains unbiased conditional on the correctly recorded k;
its unconditional covariance is therefore the displayed expected covariance.
The passive design has Fisher rank one: only x1+x2 is identified, with variance
sigma²/2 for the average of the two observations. Do not report a unique
two-component passive estimate or finite recovery covariance as identification.

Two mislabeled controls keep the same acquisition count: actual k=1 but label
k=2 (ineffective intervention), and actual k=2 but label k=1.5. Their inverse
estimates are biased. Compute analytic bias as `M(label)^-1 M(actual)x-x` and
MSE as squared bias plus trace of estimator noise covariance. These controls
demonstrate dependence on valid intervention metadata; they are not evidence
against the correct algebra.

## Execution, tolerances, and outputs

Use NumPy RNG seed 202610021, N=100000 acquisitions, shared measurement-noise
draws for paired design comparisons. Random k is independently sampled from
the recorded interval. Save the noise and random k so all estimates are
reconstructible. No model fitting or threshold tuning is performed.

Software checks: algebraic equality of fixed informative and D-optimal
predictions; monotone Fisher determinant on a 101-point grid; passive rank1;
Monte Carlo covariance Frobenius relative error below .05; Monte Carlo MSE
relative error below .05. These are numerical-verification tolerances, not
claimed effect-size margins or statistical hypothesis tests. Report actual
Monte Carlo error, sample means, covariances, and paired equality.

Outputs: `results/intervention_design_control/summary.json`, `design_table.csv`,
and `acquisitions.npz`. Freeze hashes in
`configs/intervention_design_control_freeze.json`. Runtime budget 5 seconds,
one numerical thread. Conclusion scope: an informative intervention beats
poorly conditioned/random designs in this model; the fixed informative policy
has no advantage over the strong classical D-optimal baseline.
