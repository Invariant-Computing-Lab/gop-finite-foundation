# F0 equation card

All displayed variables are nondimensional unless their physical units are written explicitly. This card defines **F0-G** (generator plus composed instruments). **F0-P**, the fitted quadratic transition predictor, is a numerical surrogate tested separately.

**(1) Restricted local classical generator**

`dz_i = [c_i + sum_j A_ij z_j + sum_{j<=k} B_ijk z_j z_k + sum_l E_il u_l] dt + sum_a Sigma_ia dW_a`.

Only the declared block and its graph neighbours may occur in a component's drift. Each subsystem has <=16 declared real coordinates, including sensor, internal, actuator and buffer variables where modeled. No undeclared algebraic lifting is permitted. D=Sigma Sigma^T is constant and positive semidefinite. A Lyapunov/nonexplosion argument or explicit finite-horizon existence check is required; merely writing a polynomial SDE does not supply global solutions.

**(2) Measurement and physical backaction**

`y_n = H z_n + d + R^(1/2) xi_n`,
`z_n^O = J z_n + l + G y_n + Q_O^(1/2) eta_n`.

R,Q_O are PSD and all noises/sensor correlations are declared. This is an affine Gaussian classical instrument. It can inject energy; its apparatus and work source must be included before claiming closure. Coarse observation H may be rank-deficient. Missingness is an observation mask, not a value zero. Quantum outcomes instead use the CP instruments in (5).

**(3) Internal update, actuation and delayed communication**

`m_n^+ = P_phi(m_n,y_n,b_n)`,
`(a_n,s_n) = P_pi(m_n^+,y_n)`,
`b_(n+1) = F b_n + K s_n + nu_n`.

P_phi and P_pi are *specified* degree<=2 polynomial maps with stored coefficients and dimension budgets. The old buffer b_n is consumed before b_(n+1) is stored; there is no instantaneous interpretation loop. F=0 gives a single-message FIFO buffer. F!=0 is a one-state linear fading-memory channel, not unlimited independent lag registers; the chosen variant must be declared. Channel noise is independent unless a shared reservoir is represented. Each endpoint may decode its incoming buffer by its own declared polynomial internal update. Sender correctness does not imply receiver goal relevance.

**(4) Causal step**

`K_h = D_h o C o A o U o O`.

O measures and changes the apparatus/world state; U updates internal records using the previous buffer; A sets actuator/signal coordinates; C propagates and stores the next buffer; D_h evolves the remaining classical and quantum state for h. Actual arrays/state partitions define which coordinates each map can change. The controller and perturbation apparatus are within the extended state whenever global closure is claimed. Elementary polynomial maps may compose to a higher-degree map; F0-P is not asserted to equal this composition exactly.

**(5) Quantum generator and outcomes (imported quantum structure)**

`L_z(rho) = -i[H(z),rho]/hbar + sum_alpha gamma_alpha(z)[L_alpha rho L_alpha^dagger - {L_alpha^dagger L_alpha,rho}/2]`,
`H(z)=sum_P h_P(z) P`, `Phi_h,z=exp(h L_z)`.

P and L_alpha are fixed one- or two-site Pauli strings (Hermitian, support<=2). This particular library models Hamiltonian interactions and Pauli dephasing/noise; it does not contain arbitrary jump operators such as amplitude damping unless a new library is declared. h_P are real degree<=2 functions; gamma_alpha are nonnegative constants in executed finite examples (more general predeclared nonnegative sums of squares would be a separately counted extension). At most 2 qubits are numerically executed. For a Pauli measurement P, `M_±=(I±P)/2`; for unsharp strength eta, `M_±=sqrt[(I±eta P)/2]`, |eta|<=1. Branch state is `I_y(rho)=M_y rho M_y^dagger`; probability is its trace, and conditional state divides by that trace only for p_y>0. Classical outcome registers carry y; an unknown quantum state is never copied into them. Sequential outcome probability is `Tr[I_yN Phi ... I_y1 Phi(rho0)]`.

**Units.** With physical z_i and time, c_i has [z_i]/time, A_ij has [z_i]/([z_j] time), B_ijk has [z_i]/([z_j][z_k] time), Sigma_ia has [z_i]/sqrt(time), H_sensor,ji has [y_j]/[z_i], and a quantum h_P has energy; gamma has 1/time. Choose scales z_i=s_i z'_i and t=t0 t' before polynomial regression. Adding unlike unscaled units is forbidden.

**Coordinates.** Only blockwise invertible affine transformations z'=Tz+r, with physically declared calibration and compatible graph partition, preserve the candidate class. Drift becomes T b(T^-1(z'-r)), diffusion T Sigma. General nonlinear coordinate changes induce Ito corrections/state-dependent diffusion and are not asserted symmetries. Coarse-graining is distinct from coordinate relabeling.

**Integrator.** Euler-Maruyama uses z_(n+1)=z_n+h b(z_n,u_n)+sqrt(h) Sigma xi_n. Deterministic verification uses an independent higher-accuracy solver where available; structured oscillator checks can use the analytic flow. Quantum finite-dimensional generators use a matrix exponential or explicitly valid Kraus channel. Nonexplosion/step convergence and invariant residuals are distinct from model-class fit. No silent clipping or trajectory replacement is permitted.

**Completely substituted loop example.** Let z=(q,p,m,b), h=.05, zero noise, initial z=(1,0,0,0). Measure y=q and back-react p^O=p+.02y. Set m^+=.8m+.2(y+b), a=-.4m^+, s=.5m^+, and b'=.9s (F=0). Evolve q'=q+.05 p^O, p'=p^O+.05[-q-.1p^O+a]. The resulting state is `(1.001,-.0341,.2,.09)`, with action -.08 and transmitted signal .1. At the next step the receiver consumes b=.09. Backaction and actuation exchange energy with the apparatus; this is not a closed conservative oscillator.

**Inference is separate.** Conditional Gaussian least squares/ridge fits the chosen polynomial feature coefficients. Calibration can estimate noise and residual intervals using calibration worlds. The loss is an estimation objective, not the master physical equation. Root benchmark artifacts specify the actual parameter/search counts, sensor access, train splits and fitted arrays. This equation card does not imply that the benchmark implements every instrument above.
