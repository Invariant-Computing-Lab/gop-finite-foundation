# Original commitments, imported mathematics and new finite restrictions

The original paper does not claim new equations of motion. It contributes a conceptual connection between operational agency, observer-conditioned knowledge, communication, intervention and occupational transformation. RARI, OCIL/OCIR, AFC and SACRA remain distinct programs. This follow-up makes a particular restricted proposal executable and exposes its failure; it does not establish a new fundamental law.

| Element | Provenance | What this study adds | What cannot be claimed |
|---|---|---|---|
| Boundaries, action versus imposed intervention, observer records and provenance | Source paper sections 2–5 | Explicit state roles, intervention assumptions and scored losses | First discovery of relationality or observer dependence |
| Classical stochastic kernel composition | Established mathematics; ledger R01 | Specific finite instrument ordering and parameter/state budget | Derivation of probability |
| Polynomial dynamical identification | Established method family; R03 | Degree-two F0 with affine/no-lift restriction, preserved negative results, cubic F1 revision | Novelty from polynomial regression itself |
| Hamiltonian and stochastic physical models | Established supplied submodels; R04 for thermodynamic path accounting | Separate consistency checks and input/output ledger | Derivation of mechanics or the second law |
| Quantum Hilbert states, GKSL, Born instruments | Established; R05–R06 (abstract-level source access recorded) | Finite Hermitian-Pauli library and explicit hybrid outcome/control loop | Derivation of quantum postulates or general quantum fields |
| Reduced non-Markovian process problem | Established operational account; R07 | Small retained-environment witness and declared closure boundary | Failure of all enlarged-state descriptions |
| Viability-dependent task information | Established proposal; R02 | Synthetic intervention-sensitive proxy tests where executed | Human lived meaning or intrinsic normativity |
| F0 G0 infinitesimal drift restriction | New study restriction | Exact degree-two cubic obstruction and numerical identification | A newly discovered physical force law |
| Broad U2 physical-unification conjecture | Author-motivated ambition made explicit | Quantifiers, budgets, prohibited outcomes and unresolved sectors | Verified ToE or a demonstrated universally shared numerical law |

The explanatory contribution is presently **unestablished**. The strongest concrete contribution is an accountable falsification scaffold with explicit candidate equations, transparent assumptions, actual computations and retained counterexamples. The use of existing physical laws makes this candidate a constrained composition architecture with imported physical sectors; it does not show that those laws emerge from occupation.

## Comparator eligibility and reporting

The learned F0-P benchmark is a supplementary observed-state predictor. Comparator fairness must be judged within each saved benchmark track: access to observations, intervention metadata, calibration, target-world adaptation and compute differs from oracle physics checks. An analytic oscillator solver or known-generator quantum channel is an **oracle/consistency track**, not a learned comparator with the same information budget. A cubic polynomial baseline broadens the feature library; it is not a full implementation of SINDy unless actual sparse support selection is implemented and reported. Likewise no small neural network may be called an RNN, and no quadratic conservative model may be called a trained Hamiltonian neural network without that training procedure.

Related technical literature supports comparator selection, not claims that every recommended comparator was executed. The final requirements ledger identifies missing Kalman/system-identification/strong design-policy or structure-preserving learned comparisons where relevant. Separate per-family fitting establishes neither zero-shot common-law transfer nor one shared inferred parameter set.

## Construction demonstration versus frozen tests

`src/candidates/f0_generator.py` and `src/toy_identification.py` were constructed and executed to verify equations and software. Their post-construction manifest preserves the actual code/results but does not retrospectively preregister them. Analytic counterexamples were found during definition and are stated as proofs, not as blinded experimental discoveries. The separately frozen pipeline and scalar revision contracts record their own order of execution; those are the appropriate evidence for claims about untouched evaluation.

The F0-G example couples classical measurement/backaction, memory, actuation, delayed communication, quantum measurement outcomes and classically controlled quantum dynamics. This is a actual conditioned hybrid trajectory. It does not fully model the energetic apparatus responsible for prescribed maps, so global closure remains unresolved.
