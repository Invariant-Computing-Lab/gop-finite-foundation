# Frozen physical compatibility specification — F0

This specification is written before executing the physical suite. The executable
`src/physics_checks.py` is hashed together with this file, the quantum generator,
and software tests into `results/physics_freeze.json` before numerical execution.
This is a finite deterministic compatibility audit with one optional synthetic
tomography generator, not a statistical test of universal physics. No locked
benchmark data, benchmark scores, or candidate revisions enter this suite.

## Candidate and interpretation

F0-G restricts the continuous classical drift in its declared physical coordinates
to total polynomial degree at most two; a finite-state jump generator is an
additional explicitly imported stochastic sector. Its quantum sector imports
finite-dimensional density operators, Born probabilities and GKSL evolution with
strictly Hermitian one- and two-local Pauli jump operators, instantiated here at
at most two qubits. These dissipators are unital. General linear combinations
with non-diagonal Kossakowski coefficients are not silently added to F0.
Discrete composition uses finite local maps. Integrator error is not a failure
of F0-G. A fitted polynomial one-step map, F0-P, is a surrogate, not an exact flow
of the polynomial generator.

The oscillator, Ornstein–Uhlenbeck (OU) process, equilibrium jump rates, Born rule,
and quantum channel formalism are inputs. Compatibility with those inputs is not
their derivation. The single physical-coordinate Newtonian force obstruction below
does not rule out every budgeted auxiliary embedding; those embeddings remain
unconstructed and untested. The reduced memoryless witness rejects a reduction,
not the augmented two-qubit F0 architecture.

## Fixed checks and thresholds

| Check | Independent reference and candidate | Predeclared necessary condition |
|---|---|---|
| Harmonic oscillator | Analytic sinusoidal solution vs velocity-Verlet for q'=p, p'=-q, q(0)=1,p(0)=0, mass=frequency=1; horizon 10, h=0.1,0.05,0.025 | Endpoint convergence order >1.8 at both refinements; maximum relative energy error at h=.025 <0.0002 |
| Newtonian inverse square | Exact rational values of a(r)=-1/r² at r=1,2,3,4; third divided difference vs degree-two force in the declared radial coordinate | Nonzero exact third divided difference is an algebraic obstruction to exact degree-two force on any interval containing these radii. This is explicitly scoped direct-coordinate incompatibility, not poor fitted transition error |
| Newtonian two-body oracle | DOP853 integration of q'=p,p'=-q/||q||³ in a reduced mass=GM=1 orbital model, initial q=(1,0),p=(0,.8), T=12 | Relative energy and angular momentum residual <1e-8; establishes a viable comparator only, outside F0's direct polynomial drift |
| Two-state thermodynamics | Energy (0,1.1), beta=1.3, attempt rate .7; k01=.7 exp(-beta*Delta/2), k10=.7 exp(beta*Delta/2); analytic transition vs matrix exponential | Detailed balance and transition agreement <1e-12; Gibbs stationary residual <1e-12 |
| Exact entropy identity | Enumerate all length-four sampled transitions, initial p=(.8,.2), h=.2; reverse process uses final forward distribution and the same time-independent rates | Sum P_F exp(-sigma)=1 within 1e-12; sigma=log(P_F/P_R) agrees with system entropy plus bath entropy within 1e-12; mean sigma >= -1e-12 and agrees with relative-entropy decrease <1e-12 |
| OU stochastic dynamics | Analytic Gaussian transition moments vs Euler–Maruyama moment recursion: kappa=1.4,gamma=.9,kBT=.8,m0=1,v0=.2,T=1,h=.1,.05,.025 | Mean/variance joint error refinement order >.85; finest joint error <.015; fluctuation–dissipation stationary variance is imported, discrete bias reported |
| Local lattice | Reference periodic convolution vs synchronous nearest-neighbor matrix map (weights .2,.6,.2), 41 sites, eight ticks | Agreement <1e-14; disturbance outside graph-distance <=tick exactly zero within 1e-14; influence within cone nonzero. One tick means one synchronous layer |
| Quantum evolution | Independent analytic Bloch rotation/dephasing and Kraus implementation vs exponentiated GKSL Liouvillian | Trace, Hermiticity, Bloch solution and Kraus agreement <1e-12; density and Choi minimum eigenvalue >-1e-12; Choi partial-trace TP residual <1e-12 |
| Quantum instruments | Computational-basis instrument applied to |+><+| | Branch probabilities .5 within 1e-12; branch normalized positivity; summed instrument equals Z dephasing; coherence destroyed within 1e-12 |
| No controllable signaling | Bell state; identity, bit flip, local amplitude damping and unread Z measurement on A | Marginal B remains I/2 within 1e-12. Conditioned remote state changes are separately shown; a communicated outcome is required to use them |
| Unitality obstruction | Input I/2; independent amplitude-damping Kraus channel with kappa=.4,t=.7 vs the strict Hermitian-Pauli F0-G prediction I/2 | F0-G is exactly unital, but the reference trace distance from I/2 equals (1-exp(-.28))/2 > .1. Reject strict F0-G for this open single-qubit process, without revising its jumps |
| Memory witness | Two initial S histories (|0>,|1>), common E=|0>; two successive SWAPs | System trace distance sequence (1,0,1) within 1e-12. Identical reduced states at tick one cannot predict both distinct next states using one memoryless map; augmented process remains valid |

All thresholds are numerical tolerances or deterministic approximation thresholds,
not effect-size margins on independently sampled physical worlds. There is no
multiple-testing p-value interpretation. Tests are not empirical measurements of
nature. A false numerical requirement is reported without tuning the requirement.

## Thermodynamic conventions

Use kB=1, T=1/beta, fixed energies, no external work and one equilibrium reservoir.
Heat into the system is Q=E_final-E_initial; bath entropy is -beta Q. Entropy along
a sampled path is sigma=log p0(initial)/pT(final) - beta Q. The reversed path is
sampled from pT under the same undriven detailed-balanced transition matrix. This
is a complete finite path enumeration, so there is no unobserved rare-event
sampling loophole. Waiting times cancel under reversal of this time-homogeneous
equilibrium process; the executed identity is for the discretely sampled paths.
For OU, potential is kappa*q²/2, friction gamma, one bath with kBT=.8, and
diffusion amplitude sqrt(2*kBT/gamma). No active feedback is present.

## Quantum generator S09

`generate_quantum(world_id, split, seed, steps=128)` produces `x,y` with
`(steps+1,3)` Bloch coordinates, `u` with `(steps,1)`, a three-element numeric
`context=[omega,gamma,kappa]`, and metadata. The reference evolves the exactly
solved Z-Hamiltonian, Z-dephasing and amplitude-damping model. `x` contains oracle
expectations, reserved for evaluation. `y` uses 512 independent shots for each of
three distinct tomography settings at each time, on independently prepared
ensembles. These are NOT simultaneous values of incompatible observables on one
qubit, or a single post-measurement trajectory. Measurement is terminal for each
replica; subsequent time points use fresh replicas with the prescribed evolution.
Thus y may lie outside the Bloch ball due to shot noise. This prepared-ensemble
access is stronger than natural single-trajectory observation and must not be
presented as access parity across classical and quantum sectors. All learned
models in S09 must receive the same y,u,context; x must not be a fitting target
unless the track is explicitly marked oracle. Applied controls are interventions;
the generator does not claim a globally closed quantum experiment.

Amplitude damping in S09 is an independent adversarial mechanism outside the
strict Hermitian-Pauli jump sector of F0-G. A learned polynomial F0-P prediction
score cannot establish that F0-G admits it. The no-signaling amplitude-damping
calculation is an imported CPTP-channel baseline, not a claimed F0-G realization.
Allowing a separate initialized environment can produce non-unital reduced
channels; the obstruction is to the specified autonomous reduced generator and
does not rule out all budgeted system-environment realizations.

## Remaining physical obligations

The lattice has a finite graph-tick influence cone, not Lorentz covariance or a
continuum causal metric. The inverse-square orbit is Newtonian, not GR. No
Einstein field equation, gauge-field action, quantum field renormalization,
particle spectrum, or common derivation of the classical and quantum sectors is
constructed. Their missing structures remain unresolved; they are not passed by
these small tests. Raw arrays, exact rational witness, fixed config, and measured
execution log are retained. Numerical execution budget: 120 seconds; one BLAS
thread. The suite itself should take well below this bound.
