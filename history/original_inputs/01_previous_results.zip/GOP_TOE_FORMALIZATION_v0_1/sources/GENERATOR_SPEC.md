# Independent reference world specification

Version: reference-v1, 2026-10-02. Source: `src/reference_worlds/generators.py`.
This NumPy-only module imports no candidate, baseline, fitting, or scoring code.
It implements nine classical families; S09 is independently implemented in
`src/reference_worlds/quantum.py`. These are deliberately small synthetic
mechanisms, not empirical evidence or exhaustive implementations of the prompt.

## Interface and information access

`generate(family, world_id, split, seed, steps=128)` returns `x`, `y`, `y_raw`,
`mask`, `u`, `context`, `dt`, `meta`, and `auxiliary`. States and observations have
shape `(steps+1,d)`; interventions have `(steps,k)`; context has `(p,)`.
Only calibrated/imputed `y`, public `u`, and the static public simulator
setpoints in `context` are eligible predictor inputs. `x`, `auxiliary`, and
`meta.true_sensor_matrix_privileged` are excluded. A missing-data mask is
available; whether a learner actually uses it must be reported.

| Family | d | k | p | State coordinates | Primary finite target |
|---|---:|---:|---:|---|---|
| S01 | 2 | 1 | 4 | two linear Gaussian states | observed-channel prediction under rank/gain ambiguity |
| S02 | 2 | 2 | 4 | position, velocity | finite-horizon Duffing trajectory |
| S03 | 4 | 2 | 5 | qx,qy,px,py | mechanical trajectory and energy diagnostic |
| S04 | 2 | 2 | 4 | two trap coordinates | stochastic observed transition and uncertainty |
| S05 | 3 | 1 | 5 | resource, integral memory, actuator | resource/controller trajectory; assigned viability proxy |
| S06 | 4 | 2 | 5 | source, receiver memory, emission, action | delayed communication and goal-conditioned action |
| S07 | 2 | 2 | 5 | two synthetic task outputs | coupled trajectory versus common-input synchrony |
| S08 | 5 | 1 | 3 | five lattice amplitudes | local discrete propagation |
| S10 | 3 | 2 | 2 | three binary registers | gate output and unseen ordered composition |

World parameters, initial conditions, and intervention protocols are seeded by
the SHA-256-derived tuple `(reference-v1,family,split,world_id)`; `seed` changes
process and measurement randomness, not those setpoints. The same world cannot
be counted again merely because a nested noise seed changes. The registered
pipeline uses training IDs 0–23, development 100–107, calibration 200–207, and
locked IDs 300–315, with split-specific PRNG streams.

All numeric dynamics use fixed simulator reference units. Labels L, M, R, and
tau denote fixed reference scales, not quantities inferred from a whole
trajectory. Dimensionally heterogeneous components must be normalized with
training-only scales before regression. Context is public experimental design
information; access to exact configured physical setpoints makes this a
conditional-prediction experiment, not blind physical-parameter identification.

## Reference equations and controls

**S01.** `x[t+1]=A x[t]+(u[t],0)+epsilon`, with
`A=((a,c),(-c,b))`, a in [0.70,0.90], b in [0.72,0.93], c in
[0.03,0.10], and independent Gaussian process SD 0.025. dt=1.
Some worlds expose only `(x1+x2, unavailable)`; others use an unknown shared
gain. The unavailable channel is masked and zero-initialized, never asserted
to be a measured zero. An accurate predictor of y does not identify latent x
through this non-injective/gauge-ambiguous observation. Stronger selective
interventions and MNAR observations are designated shifts. No fundamentally
new transition mechanism is implemented in this family.

**S02.** `dq/dt=v`, `dv/dt=-delta*v-s(t)*alpha*q-beta*q^3+u_force`;
alpha,beta in [0.7,1.3], delta in [0.12,0.25], dt=.05, four RK4 substeps.
The public second input is stiffness sign s(t). The mechanism holdout switches
from +1 to -1 at the trajectory midpoint. Other shifts include stronger force
and clipped sensing. This is a finite Duffing/switching benchmark; chaos is
not independently established, and no Lyapunov or attractor result is claimed.
A failed quadratic discrete predictor does not alone disprove a quadratic
continuous generator: finite-time flow and vector field are distinct objects.

**S03.** Training uses two separable harmonic Hamiltonians
`H=sum(p_i^2/(2m)+m*omega_i^2*q_i^2/2)` with exact constant-force propagators,
dt=.025. The designated mechanism holdout uses planar central force
`F(q)=-m*mu*q/||q||^3`, integrated by four velocity-Verlet substeps.
Initial conditions are bounded near-circular orbits. External force is recorded
in u. Energy conservation is an eligible necessary condition only in zero-work
settings; mechanical energy generally changes in these forced trajectories.
The Newtonian force is imported, not derived; no GR result follows.

**S04.** For fixed center lambda and temperature T during each step,
`q'=lambda+exp(-mobility*k*dt)*(q-lambda)+N(0,(T/k)*(1-exp(-2*mobility*k*dt)))`.
Two independent coordinates use dt=.1, k in [.8,1.4], mobility in [.7,1.2],
T in [.08,.2]; the first trap center is externally controlled and the second is
zero. k_B=1 in fixed reference units. Potential `U=.5 sum k_i(q_i-lambda_i)^2`.
Protocol work is the energy change from changing lambda at fixed q; heat into
the system is the remaining energy change during relaxation. Auxiliary work
and heat obey first-law bookkeeping exactly at the sampled endpoints. The
temperature-switch holdout is a new protocol within the same OU mechanism,
not unseen-mechanism discovery. No fluctuation theorem is inferred from these
trajectories alone; detailed reservoir/reverse-process tests are separate.

**S05.** State `(r,m,a)`, dt=.1; resource budget is
`r'=clip(r+dt*(harvest-maintenance-cost*a^2),0,2)`. Maintenance=.16,
cost=.08. Ordinary harvest is `u*a`; held-out saturating harvest is
`u*a/(.5+a)`. Assigned target is r=1. Passive control sets a=.5; reactive
control uses `clip(.5+gain*(1-r),0,1)`; the integral controller adds memory m
and updates `m'=clip((1-.12dt)m+dt*(1-r),-1,1)`.
The old actuator acts during the current step; updates affect the next step.
The boundary term from clipping is included in the auxiliary budget.
The Boolean r>.25 is a designer-assigned viability proxy; it does not establish
autonomy, biological survival, clinical benefit, or lived meaning.

**S06.** `s'=rho*s+u_source`, `e'=encoding*s`,
`r'=beta*r+(1-beta)*connected*(e[t+1-delay]/encoding+noise)`,
`a'=goal*r`. Negative-time emissions are zero. Source/r parameters, encoding,
connection, and delay are public context. Goal is the second public input and
can reverse sign. Training delay is 1; mechanism holdout delay is 3. The latter
needs an emission older than current and one-lag observations. Its failure is
a limited-memory restriction under an explicitly declared observation boundary,
not evidence against all Markov models with adequately augmented state.
Disconnected control multiplies the full received term by zero. Assigned target
`goal*s` is a synthetic task proxy, not a theory of semantics.
Connection status is zero when `(world_id//4+world_id%4)%4==0`, so every
four-world locked transfer stratum contains one disconnected control; connection
is not determined by transfer class. This was corrected before development and
freezing, without generating any locked data.

**S07.** `x1'=decay*x1+c12*tanh(x2-x1)+gain1*u1+noise`, and symmetrically
for x2 with c21. Training interaction is symmetric or zero. Common-input
controls have c12=c21=0 and u1=u2. Mechanism holdout can make coupling one-way;
tool substitution changes a known gain. Good synchrony is not alone evidence
of causal coupling. The squared output difference is an assigned coordination
proxy; this is not a musical co-occupation or participant-meaning study.

**S08.** `x'=((1-decay)I+kappa*L_graph)x+(u,0,0,0,0)`, with kappa in
[.12,.24], decay in [.005,.04]. Graph L is the five-node reflecting chain;
the topology holdout connects the endpoints into a ring. Every discrete update
passes influence across at most one graph edge. The resulting discrete cone
does not prove relativistic causal structure or Lorentz covariance, and the
continuum diffusion limit must not be called relativistic propagation.

**S10.** Bits `(a,b,c)` use gates 0 identity, 1 rotate `(b,c,a)`,
2 CNOT `(a,a XOR b,c)`, 3 erase `(a,0,c)`, 4 NOT `(1-a,b,c)`.
Two public command columns specify ordered gates. Training has at most one
nonidentity gate per step; held-out compositions have two active known gates.
No hidden future tape is included in context. Gate enumeration can establish
logical reversibility and loss of distinctions, not physical energy cost.

## Observation and split conditions

Ordinary sensors have small additive noise (SD .008); S10 noiseless bit sensors
are exact. Observer-transfer worlds apply a known invertible permutation/scale
matrix; its inverse is applied to the raw values. S02 additionally clips raw
values to [-.65,.65], which cannot be inverted. S01 unknown-gain and rank-loss
instruments are left ambiguous. Selected intervention-shift worlds drop first
channel observations with probability .35 above the fixed threshold x1(0)+.15;
the latent-dependent rule is explicitly MNAR. Missing y entries are causally
carried forward, initialized to zero, and remain accompanied by a mask.
No normalization uses future trajectory statistics.

Locked world IDs modulo four request known conditions, observer transfer,
intervention transfer, and mechanism/composition transfer. Family-specific
classification must follow the actual mechanism: S01 ordinary parameter draws
are not new mechanisms; S04 temperature schedules are intervention shifts.

## Failure criteria and limits

Primary predictive margins and statistical decisions are defined by the frozen
pipeline scoring contract, not retrospectively by this generator. A numerical
overflow, loss of required state bounds, broken exact OU moments, or incorrect
logical gate transition is a generator/software defect, not scientific
falsification. A valid and verified counterexample to a candidate's registered
restriction is assessed separately from software defects.

No claim is made that every wish-list perturbation is implemented in every
family. This module does not implement human meaning, clinical outcomes, QFT,
general relativity, multi-scale biological organisms, all intervention label
errors, or autonomous agency. Independent physical, identification, and causal
control suites fill selected additional obligations; they do not make this
finite family list exhaustive.

## Executed generator smoke

Executed locally: all nine families, two smoke worlds each, two nested seeds,
32 steps; total 36 trajectories, approximately .027 seconds with one BLAS
thread. Shapes, finite observations, fixed context length, and equality of
public context/inputs across nested seeds passed. No locked trajectories were
generated for this smoke. This is software verification, not confirmation.
Before full development, transfer labels were corrected so S01 ordinary draws
remain known-mechanism and S04 temperature switches are intervention shifts;
S06 connectivity assignment was decoupled from transfer class. These are
pre-freeze specification corrections, not post-result scientific revisions.
