# Source-to-proposal map

Prepared 2 October 2026 (Europe/Istanbul). This document is a new audit reconstructed from the supplied paper and master prompt. It is **not** the missing `02_SOURCE_AND_CHANGE_MAP.md` from the previously described ZIP.

## Materials actually supplied

- The five-page author-review conceptual paper, version 0.1, dated 2 October 2026, was read in full, including its 30 references, through its extracted text. Original PDF SHA-256: `0a6577d878b15d995dc3b127bc16731e506328879c5565f7e137ca12e51cc3de`.
- The Markdown and text execution prompts are byte-identical. SHA-256 for both: `08a3ee91e1dcbcd125e0a9c3dc17eedd734218788bcb2c03c85f34bee22d47ea`. `sources/MASTER_PROMPT.md` preserves those bytes.
- The described ZIP, editable DOCX, `02_SOURCE_AND_CHANGE_MAP.md`, `03_PRIMARY_READING_LIST.md`, and packaged continuation command were not supplied. They have not been read or reconstructed as if they were originals.
- GOT, The Reality Law, The Occupation Framework, the historical RARI reports, and the Invariant Computing program document are cited by the paper but their full texts were not supplied or independently inspected in this run. No historical numerical results or proofs are imported from them.

## Attribution and chronology

The source identifies **Emirhan Yıldırım**, occupational therapy student; Invariant Computing Program, Istanbul, Türkiye; ORCID `0009-0002-5884-3660`. It describes an early independent search for theoretical unity in physics, followed by occupational therapy/science as a proposed route. This chronology is preserved. These are author-provided facts, not independent credential verification. No new collaborators, institutional appointments, clinical qualifications, or endorsements are inferred.

| Topic | Source and locator | Follow-up treatment and evidentiary category |
|---|---|---|
| Generalized occupation | Sections 1–2, pp. 1–2 | Retain agent–world engagement and explicit boundaries. Non-agentive physical processes are included in the universal conjecture without being renamed occupations. Author proposal. |
| Agency | Section 2, p. 2 | Retain operational justification; generic feedback does not suffice. Designer-assigned viability or utility remains a synthetic proxy. No proof of consciousness or human agency. |
| Human occupational meaning | Sections 2, 5–6, pp. 2–4 | Preserve biography, culture, participation, choice, and normative pluralism. None is established by synthetic task accuracy or a scalar reward. |
| State-space equations | Section 3, p. 2 | The source explicitly characterizes them as bookkeeping. An explicit F0 dynamical restriction is a new proposal; it is not retrospectively attributed to the original paper. |
| Endogenous observers and intervention | Sections 2–3 and 5, pp. 2–3 | Preserve the separation between system evolution, measurement arrangement, agency and imposed perturbation; include physical sensing and controllers where closure is claimed. |
| Communication | Section 3, p. 2 | Retain separation of transmission, reference and interpretation. Intervention-sensitive synthetic task relevance does not establish shared human meaning. |
| Invariance and uncertainty | Section 3, p. 2 | Retain transformation families, tolerances, discrimination and calibrated compatible alternatives. Formal proofs and executable nulls are new follow-up work. |
| Dimensionality and efficiency | Section 2, p. 2 | Eleven dimensions remain revisable. Do not impose universal efficiency or equate successful optimization with a better life. |
| Four-program architecture | Section 4, p. 3 | RARI: perturbation, identity, agency, boundaries. OCIL/OCIR: observer-conditioned representation, transformation, uncertainty, provenance. AFC: relational computation and preserved distinctions, with its separate non-null proposal. SACRA: agency and transformation in systems of meaning. This study adds no fifth program. |
| Three propositions | Section 5, p. 3 | Intervention-based identification and observer-aware transfer motivate synthetic tests; occupational continuity remains a distinct human-study proposition, untested here. |
| Duet exemplar | Section 5, p. 3 | Original is a proposed human study, not reported data. Coupled synthetic agents cannot validate its clinical or experiential claims. |
| Physical unification | Sections 6–7, p. 4; master prompt Sections 0, 3–5 | The stronger quantified universality conjecture, candidate dynamics and physical-obligation matrix are added by this execution request. Established laws inserted as submodels remain imported inputs. |
| Evaluation | Source declarations, p. 4; master prompt Sections 6–9 | Source has no new experiments. All numerical results of this follow-up require actual code, frozen assumptions, predictions and run records. |

## Limits on novelty

Markov kernels, quantum instruments/GKSL generators, Hamiltonian dynamics, stochastic thermodynamics, sparse regression and conformal ranks are imported mathematics. Proving that a chosen submodel obeys an inserted constraint is a conditional consistency result. New contributions, if supported by the executed artifacts, are the particular bounded candidate, its instantiated observer/action/channel restrictions, and the reproducible counterexamples and comparative tests. Neither a common syntax nor synthetic compatibility supplies a derivation of general relativity, quantum fields, human meaning, or universal physical laws.
