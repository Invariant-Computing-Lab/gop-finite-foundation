# Post-evaluation interpretation audit of nominal transfer labels

This file corrects interpretation only. Frozen generator code, data, predictions, test-type labels, selection rules and primary results remain unchanged. No results are reclassified for a new confirmatory analysis.

| Frozen cell | Executed manipulation | Permitted interpretation |
|---|---|---|
| S03 / intervention_shift | The same ordinary input sampling rule is used as in known-mechanism worlds; fresh world RNG only | NOMINAL_LABEL_ONLY. Additional known-mechanism draws, not intervention-policy transfer |
| S07 / intervention_shift | The same ordinary input sampling rule is used as in known-mechanism worlds; fresh world RNG only | NOMINAL_LABEL_ONLY. Additional known-mechanism draws, not intervention-policy transfer |
| S10 / intervention_shift | The same single-active-gate distribution is used as in known-mechanism worlds; fresh world RNG only | NOMINAL_LABEL_ONLY. Additional known-mechanism draws, not intervention-policy transfer |
| S01 / observer_shift | The world-id-selected rank-loss/unknown-gain sensor submodes can override the nominal new invertible sensor transform | Mixed sensor conditions; not every nominal observer world realizes a changed instrument |
| S09 / known_mechanism | All sixteen worlds use the same declared quantum mechanism with new configured parameters and initial conditions | Known-mechanism generalization only; no held-out quantum mechanism, observer or policy transfer was implemented |

The primary estimand remains the exact fixed mixture that was generated, and the bootstrap retains its frozen nominal strata. Any claim about a named intervention transfer must use the executed mechanism rather than trust a label. `results/test_type_summary.csv` explicitly calls its field `test_type_frozen_label`; the S10 plot calls the relevant stratum *Nominal intervention*. These diagnostics do not retroactively create a missing manipulation. A future experiment must implement and prospectively freeze actual policy shifts in the missing cells.

The generator author confirmed these limitations after locked evaluation. This is a design-coverage limitation, not grounds for silently editing the frozen simulator or rerunning confirmation.
