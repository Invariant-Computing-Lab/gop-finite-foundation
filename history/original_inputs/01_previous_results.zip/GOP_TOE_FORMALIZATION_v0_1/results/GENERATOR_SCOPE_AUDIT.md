# Post-evaluation audit of nominal transfer labels

This audit was written after the locked forecast run. It changes neither the
frozen source, stored predictions, original labels, nor numerical results.
It restricts interpretation where a nominal label overstates the implemented
experimental manipulation. The distinctions below follow source-code inspection,
not selection of favorable numerical outcomes.

| Family and nominal test type | Actual implementation | Permitted interpretation |
|---|---|---|
| S03 intervention_shift | Same random constant-force input distribution as ordinary oscillator worlds; no dedicated intervention-shift branch | Additional independently drawn known-mechanism worlds; no tested policy shift |
| S07 intervention_shift | Same input distribution and same coupling/control assignment rule as ordinary worlds; no dedicated intervention-shift branch | Additional independently drawn known-mechanism worlds; no tested policy shift |
| S10 intervention_shift | Same distribution of one active gate and one identity gate as ordinary worlds | Additional independently drawn known-gate worlds; no tested policy shift |
| S01 observer_shift | Permutation/scaling is overridden for world IDs satisfying rank-loss or unknown-gain instrument submode | Mixed instrument conditions; not every labeled world has a novel sensor |

For each of S03, S07, and S10 there are four nominal intervention-shift locked
worlds among IDs 300–315. Repeated noise realizations do not change this count.
The original stratum summaries may be retained for traceability, but an
intervention-transfer conclusion cannot use those twelve worlds as manipulated
policy-shift evidence. New noise or new ordinary-world seeds would not repair
the missing manipulation. A future policy-transfer study requires a new
explicit protocol and untouched evaluation worlds.

S01 worlds with rank-loss or unknown-gain instruments remain useful tests of
partial observation/gauge ambiguity, but calibration-transfer claims must
identify the actual instrument rather than rely only on the stratum name.

Earlier corrections, before development and freezing, already classified S01's
ordinary fourth category as known_mechanism and S04's temperature change as
intervention_shift. S04 therefore does not supply unseen-force-law evidence.
S06 connection status was also balanced across transfer strata before freezing.

The main data use known public experimental setpoints in `context`; the
forecast result is conditional prediction rather than blind recovery of
physical parameters. Predictors target causally imputed observation records
and do not consume the separate missing-data mask. A good prediction of those
records is not evidence of reconstructing the latent state through a rank-loss
or unknown-gain instrument.
