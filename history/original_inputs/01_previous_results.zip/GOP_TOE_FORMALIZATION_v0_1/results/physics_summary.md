# Physical suite: measured results and their scope

Frozen specification and source hashes preceded one measured run at
2026-10-01 22:48:59 UTC. The nine check groups took 0.045 seconds of measured
in-process wall time, with one requested BLAS thread. Six subsequent software
tests independently inspected archived arrays, hashes, and the generator
interface; all passed. This is not nine independent physical experiments or
statistical confirmation of natural laws.

| Check | Measured result | Interpretation |
|---|---|---|
| Harmonic oscillator | Verlet endpoint convergence orders 2.00055 and 2.00014; finest-step relative energy residual 0.000156248 | Consistent integration of an imported linear Hamiltonian member of F0-G |
| Inverse-square force | Exact third divided difference 25/288 at r=1,2,3,4; a quadratic's is zero | Exact direct physical-coordinate F0-G force restriction fails. This does not eliminate every possible finite auxiliary embedding |
| Independent Newtonian orbit | Relative energy residual 2.10e-10; angular momentum residual 1.30e-10 | A valid imported reference orbit, outside the direct polynomial force class; no GR result |
| Equilibrium jump process | 32 paths exactly enumerated; mean total entropy 0.000142546; integral fluctuation expectation 1.0000000000000004 | Imported detailed balance with one specified bath, no driving; numerical identity, not a new entropy law |
| OU moments | Euler moment convergence orders 1.05440 and 1.02645; finest error 0.0134967 | Imported fluctuation–dissipation submodel; discrete stationary bias remains visible |
| Local synchronous lattice | Outside-cone response 0; independent-map residual 5.55e-17 | Finite graph-tick propagation only; no Lorentz covariance, spacetime or continuum field derivation |
| Quantum channel and instrument | Density positivity maintained; Choi minimum eigenvalue -1.59e-31; Born/trace residuals 0; coherence removed by unread measurement | Roundoff-consistent CP/TP in an imported one-qubit GKSL/Born model |
| Bell-pair no-signaling | Remote marginal residual 1.11e-16 for four local trace-preserving channels | Local channels cannot control the unconditioned remote state. Amplitude damping here is a general CPTP baseline |
| Reduced memory witness | Trace distances at successive ticks: 1,0,1; two-local exchange realization residual 2.22e-16 | A single reduced memoryless map fails; the explicit two-qubit process retains the needed state |
| Autonomous unitality obstruction | Amplitude-damping probability 0.244216; trace-distance gap from F0-G unital prediction 0.122108 | Strict Hermitian-Pauli autonomous reduced GKSL block fails this process. Initialized environments or conditional compositions are not ruled out |

The last two obstructions must not be reported as falsification of every possible
compositional or augmented realization. Conversely, success of a flexible fitted
one-step predictor does not remove a restriction of the explicitly specified
continuous generator.

S09's independent data generator includes amplitude damping, deliberately outside
the strict autonomous Hermitian-Pauli generator block. It records noisy tomography
of separate prepared ensembles (512 shots per Pauli axis per time). These are not
simultaneous incompatible measurement outcomes, nor single-system latent access.
Learned predictors receive y,u,context only; exact Bloch x is evaluation metadata.
This suite did not fit or compare quantum learners, inspect benchmark locked data,
or revise F0. Every numerical summary comes from `physics_results.json`; raw
arrays, exact witness values and invocation records are retained.

Missing physical structures remain: a classical–quantum common derivation,
Lorentz-covariant continuum dynamics, gravitational geometry, field-theory gauge
structure and renormalization, and experimentally tested observer/measurement
closure. None is supplied by the successful finite numerical checks.
