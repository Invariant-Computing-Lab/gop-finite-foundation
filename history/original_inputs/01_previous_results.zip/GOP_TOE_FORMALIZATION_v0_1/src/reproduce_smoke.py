"""Clean-copy smoke; never overwrite scientific predictions or refit locked models."""
from pathlib import Path
import json, os, shutil, subprocess, sys, tempfile, time

ROOT=Path(__file__).resolve().parents[1]

def main():
    start=time.perf_counter(); records=[]
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1')
    with tempfile.TemporaryDirectory(prefix='gop-clean-') as tmp:
        clean=Path(tmp)/'GOP_TOE_FORMALIZATION_v0_1';clean.mkdir()
        for folder in ('src','theory'):
            shutil.copytree(ROOT/folder,clean/folder,ignore=shutil.ignore_patterns('__pycache__'))
        for folder in ('results','logs','configs','models','predictions','data/manifests','versions/F0'):
            (clean/folder).mkdir(parents=True,exist_ok=True)
        commands=[['src/run_pipeline.py','smoke'],
                  ['src/candidates/f0_generator.py','--output','results'],
                  ['src/toy_identification.py','--output','results']]
        for args in commands:
            t=time.perf_counter()
            p=subprocess.run([sys.executable]+args,cwd=clean,env=env,capture_output=True,text=True,timeout=120)
            records.append({'command':['python']+args,'exit_code':p.returncode,
                            'seconds':time.perf_counter()-t,'stdout':p.stdout,'stderr':p.stderr})
            if p.returncode:break
        checks={}
        for filename in ('f0_generator_checks.json','toy_identification.json'):
            path=clean/'results'/filename
            if path.exists():
                actual=json.loads(path.read_text()); original=json.loads((ROOT/'results'/filename).read_text())
                checks[filename]={'software_checks_passed':actual['software_checks_passed'],
                                  'matches_archived_result':actual==original}
        result={'scope':'Fresh filesystem copy; smoke and fixed seeded examples only. No locked re-evaluation.',
                'commands':records,'checks':checks,'seconds':time.perf_counter()-start,
                'passed':all(r['exit_code']==0 for r in records) and len(records)==3
                         and all(all(c.values()) for c in checks.values()) and len(checks)==2}
    (ROOT/'logs/clean_reproduction.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='commands'},indent=2))
    return 0 if result['passed'] else 1

if __name__=='__main__':raise SystemExit(main())
