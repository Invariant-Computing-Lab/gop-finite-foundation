"""Frozen small-system physical checks. Run directly; no work occurs on import."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import itertools
import json
import os
from pathlib import Path
import time
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import expm
from reference_worlds.quantum import generate_quantum

ROOT = Path(__file__).resolve().parents[1]
I = np.eye(2, dtype=complex)
X = np.array([[0, 1], [1, 0]], complex)
Y = np.array([[0, -1j], [1j, 0]], complex)
Z = np.diag([1, -1]).astype(complex)


def utcnow():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def freeze():
    files = ["theory/PHYSICS_TEST_SPEC.md", "src/physics_checks.py",
             "src/reference_worlds/quantum.py", "tests/test_physics.py"]
    target = ROOT / "results/physics_freeze.json"
    if target.exists():
        raise RuntimeError("A physical freeze already exists; do not overwrite history.")
    payload = {"frozen_at_utc": utcnow(), "phase": "before_numeric_execution",
               "budget_seconds": 120, "threads": 1,
               "files_sha256": {f: sha(ROOT / f) for f in files}}
    target.write_text(json.dumps(payload, indent=2) + "\n")
    return payload


def assert_frozen():
    payload = json.loads((ROOT / "results/physics_freeze.json").read_text())
    for name, digest in payload["files_sha256"].items():
        if sha(ROOT / name) != digest:
            raise RuntimeError("Physical source differs from frozen source: " + name)
    return payload


def oscillator():
    errors, energy_errors, raw = [], [], {}
    for h in [.1, .05, .025]:
        n = round(10 / h)
        out = np.zeros((n + 1, 2)); out[0, 0] = 1
        for t in range(n):
            q, p = out[t]
            phalf = p - .5*h*q
            qnext = q + h*phalf
            out[t+1] = [qnext, phalf - .5*h*qnext]
        ts = np.arange(n+1)*h
        ref = np.column_stack([np.cos(ts), -np.sin(ts)])
        errors.append(float(np.linalg.norm(out[-1] - ref[-1])))
        energy_errors.append(float(np.max(np.abs(np.sum(out*out, axis=1) - 1))))
        raw[f"h_{h}_candidate"] = out
        raw[f"h_{h}_reference"] = ref
    orders = np.log2(np.array(errors[:-1]) / errors[1:])
    return {"endpoint_errors": errors, "convergence_orders": orders.tolist(),
            "max_relative_energy_errors": energy_errors,
            "passed": bool(np.all(orders > 1.8) and energy_errors[-1] < .0002),
            "status": "COMPATIBLE_WITH_TEST", "scope": "imported_harmonic_submodel"}, raw


def newton():
    radii = [Fraction(i) for i in range(1, 5)]
    vals = [-1 / r**2 for r in radii]
    divided = vals.copy()
    for order in range(1, 4):
        divided = [(divided[i+1]-divided[i]) / (radii[i+order]-radii[i])
                   for i in range(len(divided)-1)]
    def independent_force(t, z):
        r = z[:2]; p = z[2:]
        return np.r_[p, -r / np.linalg.norm(r)**3]
    ts = np.linspace(0, 12, 1201)
    solution = solve_ivp(independent_force, (0, 12), [1, 0, 0, .8],
                         t_eval=ts, method="DOP853", rtol=1e-11, atol=1e-13)
    z = solution.y.T
    energy = .5*np.sum(z[:, 2:]**2, axis=1) - 1/np.linalg.norm(z[:, :2], axis=1)
    angular = z[:, 0]*z[:, 3] - z[:, 1]*z[:, 2]
    eres = float(np.max(np.abs((energy-energy[0])/energy[0])))
    lres = float(np.max(np.abs((angular-angular[0])/angular[0])))
    return {"third_divided_difference": str(divided[0]),
            "algebraic_obstruction": divided[0] != 0,
            "reason": "A quadratic has zero third divided difference; -1/r^2 does not.",
            "orbit_oracle_success": bool(solution.success),
            "orbit_energy_relative_residual": eres, "orbit_angular_relative_residual": lres,
            "passed": bool(divided[0] != 0 and solution.success and eres < 1e-8 and lres < 1e-8),
            "status": "FALSIFIED_IN_REGIME",
            "scope": "exact_direct_coordinate_degree2_force; auxiliary embeddings not tested",
            "oracle_status": "EMBEDDED_AS_AN_INPUT; orbit is outside direct-coordinate F0"}, \
            {"t": ts, "orbit": z, "energy": energy, "angular_momentum": angular,
             "witness_radii": np.arange(1., 5.), "witness_force": np.array([float(v) for v in vals])}


def jump_thermodynamics():
    beta, delta, nu, dt, n = 1.3, 1.1, .7, .2, 4
    energy = np.array([0., delta])
    up, down = nu*np.exp(-beta*delta/2), nu*np.exp(beta*delta/2)
    Q = np.array([[-up, up], [down, -down]])
    pi = np.exp(-beta*energy); pi /= pi.sum()
    reference = np.tile(pi, (2, 1)) + np.exp(-(up+down)*dt)*(np.eye(2)-np.tile(pi, (2, 1)))
    P = expm(Q*dt)
    p0 = np.array([.8, .2]); pt = p0 @ np.linalg.matrix_power(P, n)
    paths = np.array(list(itertools.product([0, 1], repeat=n+1)), dtype=int)
    pf, pr, sigma, thermosigma = [], [], [], []
    for path in paths:
        f = p0[path[0]]; r = pt[path[-1]]
        for a, b in zip(path[:-1], path[1:]):
            f *= P[a, b]; r *= P[b, a]
        pf.append(f); pr.append(r); sigma.append(np.log(f/r))
        heat = energy[path[-1]] - energy[path[0]]
        thermosigma.append(np.log(p0[path[0]]/pt[path[-1]])-beta*heat)
    pf, pr, sigma, thermosigma = map(np.array, [pf, pr, sigma, thermosigma])
    db = abs(pi[0]*up - pi[1]*down)
    stationary = np.max(np.abs(pi @ P-pi))
    analytic = np.max(np.abs(P-reference))
    integral = float(pf @ np.exp(-sigma)); mean = float(pf @ sigma)
    kl_drop = float(np.sum(p0*np.log(p0/pi))-np.sum(pt*np.log(pt/pi)))
    decomposition = float(np.max(np.abs(sigma-thermosigma)))
    passed = (db < 1e-12 and stationary < 1e-12 and analytic < 1e-12 and
              abs(integral-1) < 1e-12 and mean >= -1e-12 and
              abs(mean-kl_drop) < 1e-12 and decomposition < 1e-12)
    return {"beta": beta, "temperature_kB1": 1/beta, "energy_gap": delta,
            "heat_convention": "Q_into_system=E_final-E_initial; work=0",
            "detailed_balance_residual": float(db), "stationary_residual": float(stationary),
            "analytic_transition_residual": float(analytic),
            "exact_path_count": len(paths), "forward_probability_sum": float(pf.sum()),
            "reverse_probability_sum": float(pr.sum()),
            "integral_fluctuation_expectation": integral,
            "mean_total_entropy_production": mean, "relative_entropy_decrease": kl_drop,
            "entropy_decomposition_residual": decomposition, "passed": bool(passed),
            "status": "COMPATIBLE_WITH_TEST", "scope": "imported_equilibrium_jump_process"}, \
            {"Q": Q, "P": P, "P_reference": reference, "pi": pi, "p0": p0, "pT": pt,
             "paths": paths, "p_forward": pf, "p_reverse": pr,
             "sigma": sigma, "sigma_system_plus_bath": thermosigma}


def ou():
    kappa, friction, kbt, m0, v0, horizon = 1.4, .9, .8, 1., .2, 1.
    a, sigma2 = kappa/friction, 2*kbt/friction
    ref = np.array([m0*np.exp(-a*horizon),
                    v0*np.exp(-2*a*horizon)+sigma2/(2*a)*(1-np.exp(-2*a*horizon))])
    candidates, errors, discrete_eq = [], [], []
    for h in [.1, .05, .025]:
        m, v = m0, v0
        for _ in range(round(horizon/h)):
            m, v = (1-a*h)*m, (1-a*h)**2*v + sigma2*h
        candidates.append([m, v]); errors.append(float(np.linalg.norm(np.array([m, v])-ref)))
        discrete_eq.append(sigma2/(2*a-a*a*h))
    orders = np.log2(np.array(errors[:-1])/errors[1:])
    return {"moment_errors": errors, "convergence_orders": orders.tolist(),
            "equilibrium_variance_continuum": kbt/kappa,
            "equilibrium_variance_euler": discrete_eq,
            "passed": bool(np.all(orders > .85) and errors[-1] < .015),
            "status": "COMPATIBLE_WITH_TEST", "scope": "imported_FDT_OU_submodel"}, \
            {"exact_final_moments": ref, "candidate_final_moments": np.array(candidates),
             "dt": np.array([.1, .05, .025])}


def local_cone():
    sites, ticks, center = 41, 8, 20
    matrix = .6*np.eye(sites)
    for i in range(sites):
        matrix[i, (i-1) % sites] = .2; matrix[i, (i+1) % sites] = .2
    candidate = np.zeros((ticks+1, sites)); reference = candidate.copy()
    candidate[0, center] = reference[0, center] = 1
    outside, inside = [], []
    distance = np.minimum(abs(np.arange(sites)-center), sites-abs(np.arange(sites)-center))
    for t in range(1, ticks+1):
        candidate[t] = matrix @ candidate[t-1]
        reference[t] = .6*reference[t-1]+.2*np.roll(reference[t-1], 1)+.2*np.roll(reference[t-1], -1)
        outside.append(float(np.max(np.abs(candidate[t, distance>t]))))
        inside.append(float(np.max(np.abs(candidate[t, (distance>0) & (distance<=t)]))))
    agreement = float(np.max(np.abs(candidate-reference)))
    return {"outside_cone_max": max(outside), "inside_cone_min_over_ticks": min(inside),
            "implementation_agreement": agreement,
            "passed": bool(max(outside) < 1e-14 and min(inside)>0 and agreement < 1e-14),
            "status": "COMPATIBLE_WITH_TEST", "scope": "one_synchronous_graph_layer_per_tick_not_relativity"}, \
            {"candidate": candidate, "reference": reference, "graph_distance": distance,
             "transition": matrix}


def apply_super(operator, rho):
    return (operator @ rho.reshape(-1, order="F")).reshape(rho.shape, order="F")


def liouvillian(H, jumps):
    d = H.shape[0]; ident = np.eye(d)
    out = -1j*(np.kron(ident, H)-np.kron(H.T, ident))
    for L in jumps:
        LL = L.conj().T @ L
        out += np.kron(L.conj(), L)-.5*np.kron(ident, LL)-.5*np.kron(LL.T, ident)
    return out


def choi_of_map(channel, d=2):
    result = np.zeros((d*d, d*d), complex)
    for i in range(d):
        for j in range(d):
            elementary = np.zeros((d, d), complex); elementary[i, j] = 1
            result += np.kron(elementary, channel(elementary))
    return result


def trace_b(rho):
    return np.trace(rho.reshape(2, 2, 2, 2), axis1=1, axis2=3)


def trace_a(rho):
    return np.trace(rho.reshape(2, 2, 2, 2), axis1=0, axis2=2)


def quantum_channels():
    omega, gamma, t = .9, .35, .7
    rho = (I + .6*X + .2*Y + .3*Z)/2
    generator = liouvillian(omega*Z/2, [np.sqrt(gamma/2)*Z])
    propagator = expm(t*generator)
    candidate = apply_super(propagator, rho)
    c, s, damp = np.cos(omega*t), np.sin(omega*t), np.exp(-gamma*t)
    bloch_ref = np.array([damp*(.6*c-.2*s), damp*(.6*s+.2*c), .3])
    analytic = (I+bloch_ref[0]*X+bloch_ref[1]*Y+bloch_ref[2]*Z)/2
    unitary = np.diag([np.exp(-1j*omega*t/2), np.exp(1j*omega*t/2)])
    prob = (1-damp)/2
    kraus = [np.sqrt(1-prob)*unitary, np.sqrt(prob)*unitary@Z]
    reference = sum(K@rho@K.conj().T for K in kraus)
    channel = lambda r: apply_super(propagator, r)
    choi = choi_of_map(channel)
    choi_tp = np.trace(choi.reshape(2, 2, 2, 2), axis1=1, axis2=3)
    metrics = {"trace_residual": float(abs(np.trace(candidate)-1)),
               "hermitian_residual": float(np.max(abs(candidate-candidate.conj().T))),
               "analytic_residual": float(np.max(abs(candidate-analytic))),
               "kraus_residual": float(np.max(abs(candidate-reference))),
               "density_min_eigenvalue": float(np.linalg.eigvalsh(candidate).min()),
               "choi_min_eigenvalue": float(np.linalg.eigvalsh(choi).min()),
               "choi_TP_residual": float(np.max(abs(choi_tp-I)))}
    plus = (I+X)/2
    projectors = [(I+Z)/2, (I-Z)/2]
    branches = [P@plus@P for P in projectors]
    probabilities = np.array([np.trace(b).real for b in branches])
    conditional = np.array([b/p for b, p in zip(branches, probabilities)])
    unread = sum(branches)
    instrument_choi = choi_of_map(lambda r: sum(P@r@P for P in projectors))
    metrics.update({"born_probability_residual": float(max(abs(probabilities-.5))),
                    "conditional_trace_residual": float(max(abs(np.trace(conditional,axis1=1,axis2=2)-1))),
                    "conditional_min_eigenvalue": float(min(np.linalg.eigvalsh(r).min() for r in conditional)),
                    "unread_measurement_coherence": float(abs(unread[0,1])),
                    "unread_measurement_difference_from_input": float(np.linalg.norm(unread-plus)),
                    "measurement_choi_min_eigenvalue": float(np.linalg.eigvalsh(instrument_choi).min())})
    residuals = [v for k, v in metrics.items() if k.endswith("residual")]
    eigs = [v for k, v in metrics.items() if "min_eigenvalue" in k]
    passed = all(v<1e-12 for v in residuals) and all(v>-1e-12 for v in eigs) and metrics["unread_measurement_coherence"]<1e-12
    metrics.update({"passed": bool(passed), "status": "COMPATIBLE_WITH_TEST",
                    "scope": "imported_one_qubit_GKSL_Born_instrument_formalism"})
    return metrics, {"input_rho": rho, "generator": generator, "propagator": propagator,
                     "candidate_rho": candidate, "analytic_rho": analytic,
                     "kraus_rho": reference, "choi": choi, "instrument_choi": instrument_choi,
                     "probabilities": probabilities, "conditional_states": conditional,
                     "unread_state": unread}


def no_signaling():
    bell = np.array([1, 0, 0, 1])/np.sqrt(2)
    rho = np.outer(bell, bell.conj()); a = .37
    channels = [[I], [X], [np.diag([1, np.sqrt(1-a)]), np.array([[0, np.sqrt(a)], [0, 0]])],
                [(I+Z)/2, (I-Z)/2]]
    outputs = []
    for kraus in channels:
        out = sum(np.kron(K,I)@rho@np.kron(K,I).conj().T for K in kraus)
        outputs.append(trace_a(out))
    outputs = np.array(outputs)
    P0 = np.kron((I+Z)/2, I)
    branch = P0@rho@P0
    conditioned_b = trace_a(branch/np.trace(branch))
    residual = float(np.max(abs(outputs-I/2)))
    return {"receiver_marginal_residual": residual,
            "conditioned_B_distance_from_unread": float(np.linalg.norm(conditioned_b-I/2)),
            "passed": residual<1e-12, "status": "COMPATIBLE_WITH_TEST",
            "scope": "local_trace_preserving_operations_cannot_control_remote_unconditioned_marginal"}, \
            {"bell_rho": rho, "B_marginals": outputs, "B_conditioned_on_A0": conditioned_b}


def memory_witness():
    swap = np.array([[1,0,0,0],[0,0,1,0],[0,1,0,0],[0,0,0,1]], complex)
    # The SWAP is realizable, up to global phase, by the two-local exchange H.
    H = np.kron(X,X)+np.kron(Y,Y)+np.kron(Z,Z)
    unitary = expm(-1j*np.pi*H/4)
    phase = unitary[0,0]
    gate_residual = float(np.max(abs(unitary-phase*swap)))
    history = []
    for system in [np.diag([1,0]), np.diag([0,1])]:
        joint = np.kron(system, np.diag([1,0]))
        states = [trace_b(joint)]
        for _ in range(2):
            joint = swap@joint@swap.conj().T; states.append(trace_b(joint))
        history.append(states)
    history = np.array(history)
    distance = [.5*np.sum(abs(np.linalg.eigvalsh(history[0,t]-history[1,t]))) for t in range(3)]
    passed = np.max(abs(np.array(distance)-[1,0,1]))<1e-12 and gate_residual<1e-12
    return {"reduced_trace_distance_by_tick": [float(x) for x in distance],
            "two_local_swap_realization_residual": gate_residual,
            "passed": bool(passed), "status": "FALSIFIED_IN_REGIME",
            "scope": "memoryless_reduced_description_only; augmented_two_qubit_F0_compatible",
            "witness": "identical_system_state_at_tick1_has_distinct_tick2_outputs_after_different_histories"}, \
            {"reduced_histories": history, "trace_distances": np.array(distance),
             "swap": swap, "exchange_H": H}


def unitality_obstruction():
    kappa, t = .4, .7
    damping = 1-np.exp(-kappa*t)
    kraus = [np.diag([1, np.sqrt(1-damping)]), np.array([[0,np.sqrt(damping)],[0,0]])]
    reference = sum(K@(I/2)@K.conj().T for K in kraus)
    # Any Hermitian jump L has D[L](I)=LL†-L†L=0. Hamiltonian commutator vanishes.
    f0_generator = liouvillian(.3*X+.2*Z, [.4*X, .5*Y, .6*Z])
    prediction = apply_super(expm(t*f0_generator), I/2)
    distance = float(.5*np.sum(abs(np.linalg.eigvalsh(reference-prediction))))
    unital_residual = float(np.max(abs(prediction-I/2)))
    return {"amplitude_damping_probability": float(damping),
            "trace_distance_F0_from_reference": distance,
            "analytic_distance": float(damping/2), "F0_unital_residual": unital_residual,
            "passed": bool(abs(distance-damping/2)<1e-12 and distance>.1 and unital_residual<1e-12),
            "status": "FALSIFIED_IN_REGIME",
            "scope": "strict_Hermitian_Pauli_autonomous_reduced_generator; augmented_dilations_not_excluded"}, \
            {"input": I/2, "reference_amplitude_damped": reference,
             "F0_unital_prediction": prediction, "F0_generator_example": f0_generator}


CHECKS = {"oscillator": oscillator, "newton": newton,
          "jump_thermodynamics": jump_thermodynamics, "ou": ou,
          "local_cone": local_cone, "quantum_channels": quantum_channels,
          "no_signaling": no_signaling, "memory_witness": memory_witness,
          "unitality_obstruction": unitality_obstruction}


def run():
    frozen = assert_frozen()
    output = ROOT / "results/physics_results.json"
    if output.exists():
        raise RuntimeError("Measured physical results already exist; preserve original run.")
    start = time.monotonic(); began = utcnow(); checks = {}; log = []
    for name, function in CHECKS.items():
        t0 = time.monotonic()
        metrics, raw = function()
        elapsed = time.monotonic()-t0
        raw_path = ROOT / f"results/physics_{name}_raw.npz"
        np.savez_compressed(raw_path, **raw)
        metrics["raw_artifact"] = str(raw_path.relative_to(ROOT))
        metrics["raw_sha256"] = sha(raw_path)
        metrics["seconds"] = elapsed
        metrics["software_status"] = "SOFTWARE_VERIFIED" if metrics["passed"] else "CHECK_FAILED"
        if not metrics["passed"]:
            metrics["status"] = "INVALID_TEST_OR_FAILED_NUMERICAL_CONDITION"
        checks[name] = metrics
        log.append(json.dumps({"at_utc": utcnow(), "check": name, "elapsed_seconds": elapsed,
                               "passed": metrics["passed"], "scientific_status": metrics["status"]}))
        if time.monotonic()-start > frozen["budget_seconds"]:
            raise RuntimeError("Physical numerical budget exceeded")
    # Archive a generator example outside all benchmark partitions.
    example = generate_quantum("physics-documentation-example", "documentation", 9031, 32)
    sample = ROOT / "results/physics_S09_example_raw.npz"
    np.savez_compressed(sample, **{k:v for k,v in example.items() if k!="meta"})
    (ROOT / "results/physics_S09_example_meta.json").write_text(json.dumps(example["meta"], indent=2)+"\n")
    payload = {"started_utc": began, "completed_utc": utcnow(),
               "wall_seconds": time.monotonic()-start,
               "freeze_sha256": sha(ROOT/"results/physics_freeze.json"),
               "blas_threads_requested": {k:os.environ.get(k) for k in ["OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"]},
               "all_software_checks_passed": all(c["passed"] for c in checks.values()),
               "interpretation": "Finite compatibility and explicit scoped counterexamples, not unified physics or universal validation.",
               "checks": checks}
    output.write_text(json.dumps(payload, indent=2)+"\n")
    (ROOT / "logs/physics_execution.jsonl").write_text("\n".join(log)+"\n")
    print(json.dumps(payload, indent=2))
    return payload


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--freeze", action="store_true")
    args = parser.parse_args()
    if args.freeze:
        print(json.dumps(freeze(), indent=2))
    else:
        run()
