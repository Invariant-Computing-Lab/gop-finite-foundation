Observation instruments, calibration, masks and causal imputation are implemented in src/reference_worlds/generators.py and src/candidates/f0_generator.py.
