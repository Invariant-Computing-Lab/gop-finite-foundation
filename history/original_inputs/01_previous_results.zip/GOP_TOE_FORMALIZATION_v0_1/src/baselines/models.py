"""Comparators use exactly the candidate's observed inputs and training worlds."""
import numpy as np
from sklearn.neural_network import MLPRegressor

class SmallMLP:
    def __init__(self,alpha=.01,random_state=811):
        self.alpha=alpha;self.random_state=random_state
    def fit(self,X,Y):
        self.xmean=X.mean(0);self.xscale=np.maximum(X.std(0),1e-8)
        self.ymean=Y.mean(0);self.yscale=np.maximum(Y.std(0),1e-8)
        self.model=MLPRegressor(hidden_layer_sizes=(32,),activation='tanh',alpha=self.alpha,
            random_state=self.random_state,max_iter=70,batch_size=256,learning_rate_init=.005,
            early_stopping=True,validation_fraction=.1,n_iter_no_change=8,tol=1e-5)
        self.model.fit((X-self.xmean)/self.xscale,(Y-self.ymean)/self.yscale)
        self.n_parameters=sum(x.size for x in self.model.coefs_+self.model.intercepts_)
        self.n_nonzero=self.n_parameters;self.n_features=X.shape[1]
        self.n_iter=int(self.model.n_iter_);return self
    def predict(self,X):
        out=self.model.predict((X-self.xmean)/self.xscale)
        if out.ndim==1:out=out[:,None]
        return out*self.yscale+self.ymean

class MeanNull:
    def fit(self,X,Y):
        self.mean=Y.mean(0);self.n_parameters=self.mean.size;self.n_nonzero=self.mean.size
        self.n_features=0;return self
    def predict(self,X): return np.broadcast_to(self.mean,(len(X),len(self.mean))).copy()
