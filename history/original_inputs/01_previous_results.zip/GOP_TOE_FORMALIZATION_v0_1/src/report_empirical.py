"""Post-evaluation descriptive summaries from immutable predictions; no hypothesis revision."""
from pathlib import Path
import csv,json,collections
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parents[1]
rows=[json.loads(l) for l in (ROOT/'results/raw_metrics.jsonl').read_text().splitlines()]
groups=collections.defaultdict(list)
for r in rows:groups[(r['family'],r['test_type'],r['model'])].append(r)
summary=[]
for (family,test_type,model),rs in sorted(groups.items()):
    summary.append({'family':family,'test_type_frozen_label':test_type,'model':model,'worlds':len(rs),
      'mean_capped_nmse1':np.mean([r['mse1'] for r in rs]),'mean_capped_nmse16':np.mean([r['mse16'] for r in rs]),
      'divergent_worlds16':sum(r['diverged16'] for r in rs),
      'trajectory_coverage80':np.mean([r['coverage80'] for r in rs]) if model=='F0_P' else '',
      'interpretation':'descriptive post-evaluation stratification; no new confirmatory hypothesis'})
p=ROOT/'results/test_type_summary.csv'
with p.open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
main=json.loads((ROOT/'results/empirical_run_summary.json').read_text())['families']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                     'savefig.dpi':180,'pdf.fonttype':42})
fig,ax=plt.subplots(1,2,figsize=(11.3,4.2),gridspec_kw={'width_ratios':[1.35,1]})
x=np.arange(10);c=np.array([r['candidate_mse1'] for r in main]);b=np.array([r['comparator_mse1'] for r in main])
ax[0].plot(x,c,'o-',color='#176e8a',label='F0-P quadratic',lw=1.5)
ax[0].plot(x,b,'s--',color='#b6572c',label='Development-selected comparator',lw=1.3)
ax[0].set_xticks(x,[r['family'] for r in main]);ax[0].set_yscale('log');ax[0].set_ylabel('Mean one-step capped normalized MSE')
ax[0].set_title('A  Fixed mixed test populations',loc='left',fontweight='bold');ax[0].legend(frameon=False,fontsize=8)
labels=['known_mechanism','observer_shift','intervention_shift','composition_shift'];xx=np.arange(4)
for model,off,color,lab in [('F0_P',-.18,'#176e8a','F0-P'),('MLP',.18,'#b6572c','MLP')]:
    vals=[next(r['mean_capped_nmse1'] for r in summary if r['family']=='S10' and r['test_type_frozen_label']==t and r['model']==model) for t in labels]
    ax[1].bar(xx+off,vals,width=.34,color=color,label=lab)
ax[1].set_xticks(xx,['Known','Observer','Nominal\nintervention','Composition']);ax[1].set_yscale('log');ax[1].set_ylabel('Mean one-step capped normalized MSE')
ax[1].set_title('B  S10 by frozen test label',loc='left',fontweight='bold');ax[1].legend(frameon=False,fontsize=8)
for a in ax:a.grid(axis='y',alpha=.18);a.set_axisbelow(True)
fig.text(.07,.005,'S10 pooled advantage is mixture-dependent. F0-P diverges at 16 steps in all 16 S10 worlds. Strata are descriptive (n=4 each).',fontsize=8)
fig.tight_layout(rect=(0,.04,1,1));dest=ROOT/'results/figures';dest.mkdir(exist_ok=True)
fig.savefig(dest/'forecast_results.png',bbox_inches='tight');fig.savefig(dest/'forecast_results.pdf',bbox_inches='tight');plt.close(fig)
print(json.dumps({'stratum_rows':len(summary),'figure':'results/figures/forecast_results.pdf'}))
