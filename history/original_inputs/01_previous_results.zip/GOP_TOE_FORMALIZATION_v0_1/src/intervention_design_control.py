"""Prospectively frozen equal-budget two-measurement design comparison."""
from __future__ import annotations
import csv
import hashlib
import json
from pathlib import Path
import time
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def noise_covariance(k, sigma):
    h = k-1.
    return sigma*sigma/(h*h)*np.array([[2., -(k+1.)],[-(k+1.), k*k+1.]])


def estimate(y0, yu, label_k):
    h = np.asarray(label_k)-1.
    return np.column_stack([(yu-y0)/h, (np.asarray(label_k)*y0-yu)/h])


def main():
    started = time.monotonic()
    freeze = json.loads((ROOT/'configs/intervention_design_control_freeze.json').read_text())
    for rel, expected in freeze['sha256'].items():
        assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==expected, rel
    sigma, n = .03, 100000
    x = np.array([1., -.4])
    rng = np.random.default_rng(202610021)
    noise = rng.normal(0, sigma, size=(n,2))
    random_k = rng.uniform(1.1,2.,size=n)
    y0 = x.sum()+noise[:,0]
    a,b = .1,1.
    inv2 = (1/a-1/b)/(b-a); inv1 = np.log(b/a)/(b-a)
    random_cov = sigma*sigma*np.array([[2*inv2, -inv1-2*inv2],[-inv1-2*inv2, 1+2*inv1+2*inv2]])
    fixed_cov = noise_covariance(2.,sigma)
    designs = [('random_uniform',random_k,random_k,random_cov),
               ('fixed_informative',2.,2.,fixed_cov),
               ('classical_D_optimal',2.,2.,fixed_cov),
               ('no_effect_wrong_label',1.,2.,fixed_cov),
               ('wrong_label',2.,1.5,noise_covariance(1.5,sigma))]
    results = {}
    point_estimates = {}
    for name,actual_k,label_k,covariance in designs:
        yu = actual_k*x[0]+x[1]+noise[:,1]
        estimates = estimate(y0,yu,label_k)
        errors = estimates-x
        if np.isscalar(actual_k):
            means = estimate(np.array([x.sum()]),np.array([actual_k*x[0]+x[1]]),label_k)[0]
            bias = means-x
        else:
            bias = np.zeros(2)
        expected_mse = float(np.trace(covariance)+bias@bias)
        observed_covariance = np.cov(errors,rowvar=False,ddof=0)
        covariance_error = float(np.linalg.norm(observed_covariance-covariance)/np.linalg.norm(covariance))
        observed_mse = float(np.mean(np.sum(errors*errors,axis=1)))
        mse_error = abs(observed_mse-expected_mse)/expected_mse
        assert covariance_error<.05 and mse_error<.05
        results[name] = {'measurements_per_acquisition':2,'analytic_bias':bias.tolist(),
                         'analytic_covariance':covariance.tolist(),
                         'monte_carlo_bias':errors.mean(axis=0).tolist(),
                         'monte_carlo_covariance':observed_covariance.tolist(),
                         'analytic_mse':expected_mse,'monte_carlo_mse':observed_mse,
                         'covariance_relative_error':covariance_error,'mse_relative_error':mse_error}
        point_estimates[name] = estimates
    paired_difference = float(np.max(abs(point_estimates['fixed_informative']-point_estimates['classical_D_optimal'])))
    assert paired_difference==0.
    grid = np.linspace(1.1,2.,101)
    logdet = 2*np.log(grid-1)-4*np.log(sigma)
    assert np.all(np.diff(logdet)>0)
    M0 = np.array([[1.,1.],[1.,1.]])
    passive_rank = int(np.linalg.matrix_rank(M0.T@M0/(sigma*sigma)))
    assert passive_rank==1
    passive_sum = x.sum()+noise.mean(axis=1)
    passive_sum_variance = float(np.var(passive_sum))
    assert abs(passive_sum_variance-sigma*sigma/2)/(sigma*sigma/2)<.05
    results['passive'] = {'measurements_per_acquisition':2,'fisher_rank':passive_rank,
                          'fisher_logdet':'-infinity','latent_recovery_status':'NOT_IDENTIFIABLE',
                          'analytic_sum_variance':sigma*sigma/2,
                          'monte_carlo_sum_variance':passive_sum_variance,
                          'analytic_mse':None,'monte_carlo_mse':None}
    out = {'freeze':freeze,'seed':202610021,'acquisitions':n,'independent_worlds':0,
           'scope':'repeated synthetic acquisitions of one stationary state; no new candidate selector',
           'sigma':sigma,'truth_for_evaluation_only':x.tolist(),
           'fisher':{'formula':'det(J)=(k-1)^2/sigma^4','logdet_derivative':'2/(k-1)>0',
                     'D_optimal_k':2.,'equal_acquisition_cost_assumed':True,
                     'logdet_at_1_1':float(logdet[0]),'logdet_at_2':float(logdet[-1])},
           'results':results,'fixed_vs_D_optimal_max_paired_difference':paired_difference,
           'random_to_D_optimal_analytic_MSE_ratio':float(np.trace(random_cov)/np.trace(fixed_cov)),
           'novel_design_advantage':'NONE; fixed informative and classical D-optimal are identical',
           'software_status':'SOFTWARE_VERIFIED'}
    directory = ROOT/'results/intervention_design_control'; directory.mkdir(exist_ok=True,parents=True)
    np.savez_compressed(directory/'acquisitions.npz',measurement_noise=noise,random_k=random_k,
                        fisher_k_grid=grid,fisher_logdet_grid=logdet)
    with (directory/'design_table.csv').open('w',newline='') as f:
        writer = csv.DictWriter(f,fieldnames=['design','measurements','analytic_mse','monte_carlo_mse','status'])
        writer.writeheader()
        for name in ['passive','random_uniform','fixed_informative','classical_D_optimal','no_effect_wrong_label','wrong_label']:
            row=results[name]
            writer.writerow({'design':name,'measurements':2,'analytic_mse':row['analytic_mse'],
                             'monte_carlo_mse':row['monte_carlo_mse'],
                             'status':'NOT_IDENTIFIABLE' if name=='passive' else 'SOFTWARE_VERIFIED'})
    out['wall_seconds'] = time.monotonic()-started
    (directory/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':
    main()
