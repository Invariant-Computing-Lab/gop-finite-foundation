#!/usr/bin/env python3
"""Post-execution recovery of derived records. Never refits or changes predictions.
Some append/CSV outputs were incomplete despite all immutable archives and final
summary existing. Cause was not established. Preserve originals; rebuild atomic.
"""
import csv,hashlib,io,json,os,pickle,shutil
from pathlib import Path
import numpy as np
from run_pipeline import ROOT,FAMILIES,IDS,SEEDS,generate,jdefault,now,sha,kindof
from scoring.metrics import normalized_mse

def atomic(path,content):
    tmp=path.with_suffix(path.suffix+'.recovering');tmp.write_text(content);os.replace(tmp,path)
def csvtext(rows):
    out=io.StringIO();w=csv.DictWriter(out,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows);return out.getvalue()
def main():
    backup=ROOT/'logs/persistence_recovery';backup.mkdir(exist_ok=True)
    targets=['results/raw_metrics.jsonl','results/hypothesis_status.csv','results/transfer_and_ablation_tables.csv',
        'data/manifests/worlds.jsonl','logs/pipeline.jsonl','logs/locked_stdout.jsonl']
    for f in targets:
        p=ROOT/f;dest=backup/f.replace('/','__')
        if dest.exists():raise RuntimeError('Recovery already performed; do not overwrite preserved originals')
        if p.exists():shutil.copy2(p,dest)
    start=now();old=json.loads((ROOT/'results/empirical_run_summary.json').read_text())
    original_predictions={str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'predictions').glob('*_locked.npz')}
    manifest=[json.loads(x) for x in (ROOT/'data/manifests/worlds.jsonl').read_text().splitlines()]
    present={(x['family'],x['split'],x['world_id'],x['seed']) for x in manifest}
    rows=[];abl=[];restored_manifest=[];comparisons=[]
    for fam in FAMILIES:
        pp=ROOT/f'predictions/{fam}_locked.npz';ph=sha(pp);a=np.load(pp);scale=a['scale']
        with (ROOT/f'models/{fam}.pkl').open('rb') as f:b=pickle.load(f)
        summary=next(x for x in old['families'] if x['family']==fam)
        for name,m in b['models'].items():
            l1=[];l16=[]
            for i,wid in enumerate(a['world_ids']):
                error=np.abs((a[f'pred1__{name}'][i]-a['truth1'][i])/scale)
                r={'family':fam,'world_id':int(wid),'model':name,'test_type':str(a['test_types'][i]),
                 'mse1':normalized_mse(a['truth1'][i],a[f'pred1__{name}'][i],scale),
                 'mse16':normalized_mse(a['truth16'][i],a[f'pred16__{name}'][i],scale),
                 'coverage80':bool(np.max(error)<=b['conformal_q']) if name=='F0_P' else None,
                 'pointwise_coverage80':float(np.mean(error<=b['conformal_q'])) if name=='F0_P' else None,
                 'interval_width_mean':float(np.mean(2*b['conformal_q']*scale)) if name=='F0_P' else None,
                 'diverged16':bool(a[f'diverged16__{name}'][i]),'nonfinite1':int((~np.isfinite(a[f'pred1__{name}'][i])).sum()),
                 'nonfinite16':int((~np.isfinite(a[f'pred16__{name}'][i])).sum()),
                 'capped_residuals1':int((error>1e6).sum()),
                 'capped_residuals16':int((np.abs((a[f'pred16__{name}'][i]-a['truth16'][i])/scale)>1e6).sum()),
                 'prediction_file':str(pp.relative_to(ROOT)),'prediction_sha256':ph,'version':'F0-P-1'}
                rows.append(r);l1.append(r['mse1']);l16.append(r['mse16'])
            abl.append({'family':fam,'model':name,'mean_mse1':float(np.mean(l1)),'mean_mse16':float(np.mean(l16)),
                'development_mse1':b['development_mse'][name],'parameters':getattr(m,'n_parameters',0),
                'divergent_worlds16':int(a[f'diverged16__{name}'].sum())})
            if name in ('F0_P',b['comparator']):
                key='candidate_mse1' if name=='F0_P' else 'comparator_mse1'
                assert np.isclose(float(np.mean(l1)),summary[key],rtol=1e-12,atol=1e-14),(fam,name,key)
                comparisons.append({'family':fam,'model':name,'matches_original_summary':True})
        for i,wid in enumerate(a['world_ids']):
            for j,seed in enumerate(a['seeds']):
                key=(fam,'locked',int(wid),int(seed))
                if key in present:continue
                g=generate(fam,int(wid),'locked',int(seed),128)
                y=np.asarray(g['y'],float);u=np.asarray(g['u'],float);ctx=np.asarray(g['context'],float).reshape(-1)
                assert np.array_equal(y[2:],a['truth1'][i,j]),'Recovery reference differs from archived target'
                record={'family':fam,'split':'locked','world_id':int(wid),'seed':int(seed),'steps':128,
                    'y_shape':y.shape,'u_shape':u.shape,'context':ctx,'meta':g.get('meta',{}),
                    'observed_content_sha256':hashlib.sha256(y.tobytes()+u.tobytes()+ctx.tobytes()).hexdigest(),
                    'record_recovered_at':now(),'recovery_basis':'Frozen reference regeneration; y[2:] bit-exact to immutable archived truth1'}
                manifest.append(record);restored_manifest.append(list(key))
    assert len(rows)==1280 and len(manifest)==1680
    for p,h in original_predictions.items():assert sha(ROOT/p)==h
    atomic(ROOT/'results/raw_metrics.jsonl',''.join(json.dumps(x,default=jdefault)+'\n' for x in rows))
    atomic(ROOT/'data/manifests/worlds.jsonl',''.join(json.dumps(x,default=jdefault)+'\n' for x in manifest))
    atomic(ROOT/'results/hypothesis_status.csv',csvtext(old['families']))
    atomic(ROOT/'results/transfer_and_ablation_tables.csv',csvtext(abl))
    report={'recovery_started_at':start,'completed_at':now(),'reason':'Incomplete append/CSV persistence after successful final summary+10 prediction archives; exact cause unestablished',
        'originals_directory':str(backup.relative_to(ROOT)),'raw_metric_rows_after':len(rows),'manifest_rows_after':len(manifest),
        'restored_manifest_records':restored_manifest,'prediction_hashes_unchanged':original_predictions,
        'original_summary_comparisons':comparisons,'models_refit':False,'new_test_worlds_generated':False,
        'same_worlds_regenerated_for_manifest_only':len(restored_manifest),'historical_logs':'Original incomplete logs retained unchanged; no past events/timestamps fabricated',
        'scientific_change':'None; missing derived records recomputed from unchanged archives using frozen score; regenerated existing reference targets exactly matched'}
    atomic(ROOT/'results/PERSISTENCE_RECOVERY.json',json.dumps(report,indent=2,default=jdefault)+'\n')
    print(json.dumps({'recovered_raw_rows':len(rows),'manifest_rows':len(manifest),'metadata_reconstructed':len(restored_manifest)}))
if __name__=='__main__':main()
