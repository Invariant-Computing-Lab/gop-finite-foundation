"""Measured-drift identification and a prospective F1 class counterexample.

No imports from the candidate or benchmark generators. Reference trajectories
use DOP853; fitted candidate prediction uses independently coded RK4.
"""
from pathlib import Path
import json, hashlib, time
import numpy as np
from scipy.integrate import solve_ivp

ROOT = Path(__file__).resolve().parents[1]

def reference_endpoint(x, degree, h):
    return np.array([solve_ivp(lambda t, y: -y-y**degree, (0,h), [v],
                     method='DOP853', rtol=1e-12, atol=1e-14).y[0,-1] for v in x])

def features(x, degree):
    return np.column_stack([x**k for k in range(degree+1)])

def rk4(x, coeff, h):
    f=lambda y: features(np.atleast_1d(y),len(coeff)-1)@coeff
    a=f(x); b=f(x+h*a/2); c=f(x+h*b/2); d=f(x+h*c)
    return x+h*(a+2*b+2*c+d)/6

def run():
    started=time.perf_counter()
    out=ROOT/'results/generator_revision'; out.mkdir(parents=True,exist_ok=True)
    contract={
      'candidate_F0_G':'same-state degree<=2 drift; identity calibrated scalar coordinate',
      'revision_F1_G':'degree<=3 drift; all other restrictions retained',
      'revision_reason':'analytic cubic restoring-force obstruction for F0-G',
      'added_coefficients_scalar':1,
      'train_mechanism':'dx/dt=-x-x^3',
      'identification_protocol':'two endpoint positions; difference/h; derivative sensor noise std .001',
      'h_identification':0.0001,'train_positions':256,'train_seed':702601,
      'calibration':'none; deterministic fit error with fixed known synthetic noise',
      'fresh_mechanism':'dx/dt=-x-x^5; not used in F1 fitting',
      'class_metric':'uniform instantaneous drift error on [-1,1]',
      'F0_best_possible_cubic_error':0.25,'F1_best_possible_quintic_error':0.0625,
      'registered_requirement':0.01,
      'trajectory_horizon':2.0,'trajectory_dt':0.01,'test_initial_positions':[-1,-0.5,0.5,1],
      'scope':'resolved-generator necessary subclaim; not arbitrary hidden realizations',
      'claim':'no fixed polynomial degree is universally sufficient under this no-lift restriction',
      'statistics':'no independent-world confidence claims; deterministic minimax proof and diagnostic fits'
    }
    # Scientific contract is written before any measurements or fitting.
    cp=ROOT/'configs/generator_revision_contract.json'
    cp.write_text(json.dumps(contract,indent=2)+'\n')
    freeze={'contract_sha256':hashlib.sha256(cp.read_bytes()).hexdigest(),
            'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
    (out/'prefit_freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
    rng=np.random.default_rng(contract['train_seed'])
    x=rng.uniform(-1,1,contract['train_positions']); h=contract['h_identification']
    measured=(reference_endpoint(x,3,h)-x)/h+rng.normal(0,.001,len(x))
    coefs={f'F{d-2}':np.linalg.lstsq(features(x,d),measured,rcond=None)[0] for d in (2,3)}
    (out/'model_coefficients.json').write_text(json.dumps({k:v.tolist() for k,v in coefs.items()},indent=2))
    frozen_models={k:hashlib.sha256(v.tobytes()).hexdigest() for k,v in coefs.items()}
    (out/'F1_before_fresh_mechanism.json').write_text(json.dumps(frozen_models,indent=2))
    grid=np.linspace(-1,1,4001)
    arrays={'train_x':x,'train_measured_drift':measured,'grid':grid}
    summary={'F0_cubic_minimax_bound':.25,'F1_quintic_minimax_bound':.0625,
             'F0_status':'FALSIFIED_IN_REGIME','F1_status':'FALSIFIED_IN_REGIME',
             'metric_requirement':.01,'F1_cubic_repair':'COMPATIBLE_WITH_TEST'}
    for degree in (3,5):
        truth=-grid-grid**degree
        arrays[f'true_drift_degree{degree}']=truth
        for label,coef in coefs.items():
            pred=features(grid,len(coef)-1)@coef
            arrays[f'{label}_drift_degree{degree}']=pred
            summary[f'{label}_degree{degree}_uniform_drift_error']=float(abs(pred-truth).max())
        for x0 in contract['test_initial_positions']:
            ts=np.linspace(0,2,201)
            ref=solve_ivp(lambda t,y:-y-y**degree,(0,2),[x0],t_eval=ts,
                          method='DOP853',rtol=1e-11,atol=1e-13).y[0]
            arrays[f'ref_d{degree}_x{x0}']=ref
            for label,coef in coefs.items():
                trajectory=[x0]
                for _ in range(200): trajectory.append(float(rk4(np.array([trajectory[-1]]),coef,.01)[0]))
                arrays[f'{label}_d{degree}_x{x0}']=np.asarray(trajectory)
    # Independent numerical check of sharp analytic minimax polynomials.
    residual0=(-grid-grid**3)-(-1.75*grid)
    residual1=(-grid-grid**5)-(-11/16*grid-5/4*grid**3)
    assert np.isclose(abs(residual0).max(),.25,atol=1e-12)
    assert np.isclose(abs(residual1).max(),1/16,atol=1e-12)
    summary['runtime_seconds']=time.perf_counter()-started
    np.savez_compressed(out/'measurements_predictions.npz',**arrays)
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))

if __name__=='__main__': run()
