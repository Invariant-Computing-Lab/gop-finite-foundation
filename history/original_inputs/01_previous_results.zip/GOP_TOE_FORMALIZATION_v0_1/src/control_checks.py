"""Small frozen synthetic causal demonstrations, independent of learners."""
from __future__ import annotations
import hashlib
import itertools
import json
from pathlib import Path
import time
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def main():
    started = time.monotonic()
    freeze = json.loads((ROOT/'configs/control_checks_freeze.json').read_text())
    for rel, expected in freeze['sha256'].items():
        actual = hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
        if actual != expected:
            raise RuntimeError('Frozen source mismatch: '+rel)
    rng = np.random.default_rng(20261002)
    arrays = {}
    out = {'scope': 'frozen finite synthetic controls; no population or human-meaning inference',
           'freeze': freeze, 'resource': {}}
    steps, dt = 1000, .05
    supply = .60+.05*np.sin(.031*np.arange(steps))
    supply[300:650] -= .30
    arrays['resource_supply'] = supply
    for mode in ('passive', 'reactive', 'adaptive'):
        z = np.zeros((steps+1, 3)); z[0] = [1., 0., .5]
        budget = np.zeros((steps, 4))
        for t in range(steps):
            r, m, a = z[t]
            inflow, maintenance, cost = dt*supply[t]*a, dt*.16, dt*.06*a*a
            raw = r+inflow-maintenance-cost
            next_r = np.clip(raw, 0., 2.)
            next_m = np.clip((1-.12*dt)*m+dt*(1-r), -1., 1.) if mode=='adaptive' else 0.
            next_a = .5 if mode=='passive' else np.clip(.5+.9*(1-r)+(m if mode=='adaptive' else 0.), 0., 1.)
            z[t+1] = [next_r, next_m, next_a]
            budget[t] = [inflow, maintenance, cost, next_r-raw]
        residual = np.diff(z[:, 0])-(budget[:, 0]-budget[:, 1]-budget[:, 2]+budget[:, 3])
        assert np.max(np.abs(residual)) < 1e-12
        out['resource'][mode] = {'minimum_resource': float(z[:, 0].min()),
                                'mean_absolute_target_error': float(np.mean(abs(z[:, 0]-1))),
                                'viability_proxy_fraction': float(np.mean(z[:, 0]>.25)),
                                'total_action_cost': float(budget[:, 2].sum()),
                                'max_budget_residual': float(abs(residual).max())}
        arrays['resource_'+mode] = z
        arrays['resource_'+mode+'_budget'] = budget
    bits = rng.choice([-1., 1.], 2048)
    encoded = -2*bits; decoded = encoded/-2
    wrong_action = decoded; new_goal_target = -bits; corrected_action = -decoded
    probability = np.mean(bits==1)
    entropy = -sum(p*np.log2(p) for p in (probability, 1-probability))
    common_noise = rng.normal(0, .025, 2048)
    connected_difference = ((1+common_noise)-(-1+common_noise))
    disconnected_difference = np.zeros_like(connected_difference)
    out['communication'] = {'transmission_accuracy': float(np.mean(decoded==bits)),
                            'empirical_mutual_information_bits': float(entropy),
                            'goal_flipped_old_policy_accuracy': float(np.mean(wrong_action==new_goal_target)),
                            'goal_flipped_correct_policy_accuracy': float(np.mean(corrected_action==new_goal_target)),
                            'connected_do_effect': float(connected_difference.mean()),
                            'disconnected_max_do_effect': float(abs(disconnected_difference).max())}
    assert out['communication']['transmission_accuracy']==1.
    assert out['communication']['goal_flipped_old_policy_accuracy']==0.
    assert out['communication']['goal_flipped_correct_policy_accuracy']==1.
    assert abs(out['communication']['connected_do_effect']-2)<1e-12
    assert out['communication']['disconnected_max_do_effect']==0.
    arrays['communication_source_decoded_wrong_target_corrected'] = np.column_stack([bits,decoded,wrong_action,new_goal_target,corrected_action])
    arrays['communication_do_effects'] = np.column_stack([connected_difference,disconnected_difference])
    histories = np.array([[.25, .1, 0.], [.75, .1, 0.]])
    beta = .2; receiver = 0.; next_receiver = beta*receiver+(1-beta)*histories[:, 0]
    out['memory_witness'] = {'identical_current_and_one_lag': bool(np.array_equal(histories[0, 1:],histories[1, 1:])),
                             'distinct_next_receiver': next_receiver.tolist(),
                             'difference': float(np.diff(next_receiver)[0]),
                             'restriction': 'one-lag observed-state sufficiency at delay=3'}
    assert out['memory_witness']['identical_current_and_one_lag']
    assert abs(out['memory_witness']['difference']-.4)<1e-12
    arrays['delay_histories_oldest_to_current'] = histories
    arrays['delay_next_receiver'] = next_receiver
    drive = rng.normal(0, .3, 256)
    outputs = np.zeros((257, 2))
    for t in range(256):
        outputs[t+1] = .8*outputs[t]+drive[t]
    state = outputs[40].copy()
    plus = state+np.array([.5,0]); minus = state+np.array([-.5,0])
    def receiver_update(z, coupling):
        return .8*z[1]+coupling*(z[0]-z[1])+drive[40]
    zero_effect = receiver_update(plus,0)-receiver_update(minus,0)
    coupled_effect = receiver_update(plus,.12)-receiver_update(minus,.12)
    out['coactivity'] = {'uncoupled_common_input_correlation': float(np.corrcoef(outputs.T)[0,1]),
                         'uncoupled_do_effect': float(zero_effect), 'coupled_do_effect': float(coupled_effect)}
    assert abs(zero_effect)<1e-12 and abs(coupled_effect-.12)<1e-12
    arrays['common_input_outputs'] = outputs; arrays['common_input_drive'] = drive
    points = np.array(list(itertools.product([-1.,1.],repeat=2)))
    A = np.array([[0.,2.],[-.5,0.]])
    raw = points@A.T
    correct = np.linalg.solve(A,raw.T).T
    wrong = correct@np.diag([-1.,1.])
    constant = np.zeros_like(points)
    out['observation'] = {}
    for name, rep in [('correct',correct),('wrong',wrong),('constant',constant)]:
        assigned = np.argmin(np.sum((rep[:,None,:]-points[None,:,:])**2,axis=2),axis=1)
        out['observation'][name] = {'rmse': float(np.sqrt(np.mean((rep-points)**2))),
                                   'discrimination_accuracy': float(np.mean(assigned==np.arange(4))),
                                   'distinct_representations': int(len(np.unique(rep,axis=0)))}
        arrays['observation_'+name] = rep
    assert out['observation']['correct']['discrimination_accuracy']==1.
    assert out['observation']['wrong']['discrimination_accuracy']==0.
    assert out['observation']['constant']['discrimination_accuracy']==.25
    arrays['observation_truth'] = points; arrays['observation_raw'] = raw
    registers = np.array(list(itertools.product([0,1],repeat=3)),dtype=int)
    cnot = registers.copy(); cnot[:,1] = registers[:,0]^registers[:,1]
    reversible = cnot[:,[1,2,0]]
    erased = registers.copy(); erased[:,1] = 0
    provenance = np.column_stack([erased, registers[:,1]])
    counts = {'input': len(np.unique(registers,axis=0)),
              'reversible': len(np.unique(reversible,axis=0)),
              'erased': len(np.unique(erased,axis=0)),
              'erased_with_provenance': len(np.unique(provenance,axis=0))}
    assert counts=={'input':8,'reversible':8,'erased':4,'erased_with_provenance':8}
    out['computation'] = {'distinct_state_counts': counts,
                          'log2_distinct_states': {k:float(np.log2(v)) for k,v in counts.items()},
                          'claim': 'logical distinguishability only; no measured thermodynamic cost'}
    arrays['register_input'] = registers; arrays['register_reversible'] = reversible
    arrays['register_erased'] = erased; arrays['register_provenance'] = provenance
    out['software_status'] = 'SOFTWARE_VERIFIED'
    out['wall_seconds'] = time.monotonic()-started
    directory = ROOT/'results/controls'; directory.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(directory/'control_arrays.npz',**arrays)
    (directory/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))


if __name__=='__main__':
    main()
