"""Registered loss and world-level uncertainty. Error cap reports divergence explicitly."""
import numpy as np

def normalized_mse(truth,pred,scale):
    error=(np.asarray(pred)-truth)/scale
    error=np.nan_to_num(error,nan=1e6,posinf=1e6,neginf=-1e6)
    return float(np.mean(np.clip(error,-1e6,1e6)**2))

def paired_interval(delta,seed=993,draws=20000,alpha=.005,strata=None):
    delta=np.asarray(delta,dtype=float);rng=np.random.default_rng(seed)
    if strata is None:
        indices=rng.integers(0,len(delta),size=(draws,len(delta)))
    else:
        groups=[np.flatnonzero(np.asarray(strata)==s) for s in sorted(set(strata))]
        indices=np.concatenate([g[rng.integers(0,len(g),(draws,len(g)))] for g in groups],axis=1)
    means=delta[indices].mean(1)
    return float(delta.mean()),*[float(v) for v in np.quantile(means,[alpha/2,1-alpha/2])]

def conformal_quantile(scores,coverage=.8):
    scores=np.sort(np.asarray(scores));rank=int(np.ceil((len(scores)+1)*coverage))
    return float(scores[rank-1]) if rank<=len(scores) else float('inf')
