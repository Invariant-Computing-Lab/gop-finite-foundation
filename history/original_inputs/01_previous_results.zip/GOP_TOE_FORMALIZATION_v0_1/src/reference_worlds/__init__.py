"""Independent, NumPy-only reference worlds. Never import learners here."""
from .generators import FAMILIES, generate

__all__ = ["FAMILIES", "generate"]
