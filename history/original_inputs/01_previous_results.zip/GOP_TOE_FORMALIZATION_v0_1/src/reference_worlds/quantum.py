"""Independent, exact one-qubit prepared-ensemble tomography reference (S09)."""
from __future__ import annotations
import hashlib
import numpy as np


def generate_quantum(world_id, split, seed, steps=128):
    """No learned-candidate implementation or parameter fitting is used here.

    Three coordinates of y come from three separate ensembles. They are not a
    positive joint distribution for incompatible spin measurements on one qubit.
    """
    parameter_seed = int.from_bytes(hashlib.sha256(
        (str(world_id) + "|" + str(split) + "|quantum-physics-v1").encode()
    ).digest()[:8], "little")
    rng = np.random.default_rng(parameter_seed)
    noise_seed = int.from_bytes(hashlib.sha256(
        (str(world_id) + "|" + str(split) + "|" + str(seed) + "|noise").encode()
    ).digest()[:8], "little")
    noise_rng = np.random.default_rng(noise_seed)
    omega = float(rng.uniform(.5, 1.5))
    gamma = float(rng.uniform(.08, .3))
    kappa = float(rng.uniform(.04, .15))
    dt, shots = .05, 512
    x = np.empty((steps + 1, 3))
    v = rng.normal(size=3)
    x[0] = rng.uniform(.65, .95) * v / np.linalg.norm(v)
    u = np.empty((steps, 1))
    # A precommitted drive sequence; noise seeds do not change the physical world.
    u[:, 0] = .4 * np.sin(.19 * np.arange(steps) + rng.uniform(0, 2*np.pi))
    damp = np.exp(-(gamma + kappa / 2) * dt)
    relax = np.exp(-kappa * dt)
    for t in range(steps):
        angle = (omega + u[t, 0]) * dt
        c, s = np.cos(angle), np.sin(angle)
        x[t+1, 0] = damp * (c*x[t, 0] - s*x[t, 1])
        x[t+1, 1] = damp * (s*x[t, 0] + c*x[t, 1])
        x[t+1, 2] = 1 + (x[t, 2]-1) * relax
    y = 2 * noise_rng.binomial(shots, np.clip((1+x)/2, 0, 1)) / shots - 1
    return {"x": x, "y": y.astype(float), "u": u,
            "context": np.array([omega, gamma, kappa]),
            "y_raw": y.astype(float).copy(), "mask": np.ones_like(y, dtype=bool),
            "meta": {"family": "S09", "world_id": str(world_id), "split": str(split),
                     "seed": int(seed), "steps": int(steps), "dt": dt,
                     "context_names": ["omega", "gamma", "kappa"],
                     "mechanism": "exact_z_drive_dephasing_amplitude_damping",
                     "test_type": "known_mechanism",
                     "F0_G_compatibility": "amplitude_damping_outside_strict_Hermitian_Pauli_jump_sector",
                     "x_role": "oracle_Bloch_expectation_for_evaluation_only",
                     "observation": "three_distinct_prepared_ensemble_tomography_settings",
                     "shots_per_axis_per_time": shots,
                     "access_limitation": "replicated_ensemble_tomography_not_single_quantum_trajectory",
                     "coordinates": ["sigma_x", "sigma_y", "sigma_z"],
                     "units": {"time": "arbitrary_fixed", "omega_gamma_kappa": "inverse_time",
                               "u": "inverse_time", "x_y": "dimensionless"}}}
