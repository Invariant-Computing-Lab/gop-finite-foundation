"""Independent reference mechanisms for GOP–TOE finite stress tests.

`x` and `auxiliary` are privileged evaluation truth. Learners receive only y,
u, context and the observation mask. Public context consists of configured
experimental setpoints, never fitted truth states or future trajectories.
"""
from __future__ import annotations

import hashlib
import numpy as np

FAMILIES = ("S01", "S02", "S03", "S04", "S05", "S06", "S07", "S08", "S10")
DIMENSIONS = {"S01": (2, 1), "S02": (2, 2), "S03": (4, 2), "S04": (2, 2),
              "S05": (3, 1), "S06": (4, 2), "S07": (2, 2), "S08": (5, 1),
              "S10": (3, 2)}


def _rng(*parts):
    digest = hashlib.sha256("|".join(map(str, parts)).encode()).digest()
    return np.random.default_rng(int.from_bytes(digest[:8], "little"))


def _canonical_split(split):
    return {"development": "dev", "calibration": "cal", "evaluation": "locked",
            "test": "locked", "training": "train"}.get(split, split)


def _variant(split, world_id):
    # This assignment is public and must be frozen before any locked generation.
    if split == "locked":
        return ("in_distribution", "observer_transfer", "intervention_transfer",
                "mechanism_transfer")[world_id % 4]
    return "development_population"


def _inputs(rng, steps, k, scale, block=8):
    return np.repeat(rng.uniform(-scale, scale, ((steps + block - 1) // block, k)),
                     block, axis=0)[:steps]


def _observe(x, family, world_id, variant, wrng, nrng):
    """Known calibration is applied without using future values or true states.

    Lossy/gain-ambiguous instruments deliberately remain unresolved in y.
    Missing channels are causally carried forward and accompanied by a mask.
    """
    d = x.shape[1]
    sensor = np.eye(d)
    if variant == "observer_transfer":
        sensor = np.diag(wrng.uniform(.55, 1.75, d)) @ np.eye(d)[wrng.permutation(d)]
    noise_sd = 0.0 if family == "S10" else .008
    raw = x @ sensor.T + nrng.normal(0, noise_sd, x.shape)
    y = np.linalg.solve(sensor, raw.T).T
    mode = "known_invertible_calibration"
    calibration_known = True
    declared_sensor = sensor.copy()
    if family == "S01" and world_id % 5 == 0:
        declared_sensor = np.array([[1., 1.], [0., 0.]])
        sensor = declared_sensor.copy()
        raw = x @ sensor.T + nrng.normal(0, noise_sd, x.shape)
        raw[:, 1] = 0.0
        y = raw.copy()
        mode = "rank_one_sum_channel_second_channel_inapplicable"
    elif family == "S01" and world_id % 5 == 1:
        gain = wrng.uniform(.6, 1.6)
        sensor = gain * np.eye(d)
        declared_sensor = np.eye(d)
        raw = x @ sensor.T + nrng.normal(0, noise_sd, x.shape)
        y = raw.copy()
        calibration_known = False
        mode = "unknown_shared_sensor_gain_no_inverse_claim"
    if family == "S02" and variant == "observer_transfer":
        # Clipping is non-injective: inverse sensor calibration cannot undo it.
        raw = np.clip(raw, -.65, .65)
        y = np.linalg.solve(sensor, raw.T).T
        mode = "known_linear_calibration_after_information_losing_clipping"
    mask = np.ones_like(x, dtype=bool)
    if family == "S01" and world_id % 5 == 0:
        mask[:, 1] = False  # Structurally unavailable, distinguished from zero.
    missing_rule = "none"
    if variant == "intervention_transfer" and family in ("S01", "S02", "S05"):
        # Fixed initial-condition threshold; no future trajectory calibration.
        missing = (x[:, 0] > float(x[0, 0]) + .15) & (nrng.random(len(x)) < .35)
        mask[missing, 0] = False
        missing_rule = "P(missing first sensor)=.35 if x0(t)>x0(0)+.15"
    raw[~mask] = np.nan
    for t in range(len(x)):
        y[t, ~mask[t]] = y[t-1, ~mask[t]] if t else 0.
    return y, raw, mask, {"observation_mode": mode,
                         "sensor_matrix": declared_sensor.tolist(),
                         "sensor_calibration_known": calibration_known,
                         "true_sensor_matrix_privileged": sensor.tolist(),
                         "measurement_noise_sd_raw": noise_sd,
                         "missingness_rule": missing_rule,
                         "imputation": "causal carry forward; zero initial value; mask retained"}


def generate(family: str, world_id: int, split: str, seed: int, steps: int = 128):
    """Return one independent world and one nested stochastic realization.

    Shapes: x,y,y_raw,mask=(steps+1,d); u=(steps,k); context=(p,).
    World parameters/initial states/input protocols depend on family/split/id;
    seed changes process/measurement randomness only. No locked data are
    generated merely by importing this module.
    """
    if family not in FAMILIES:
        raise ValueError(f"Unknown family {family}; available={FAMILIES}")
    if steps < 2:
        raise ValueError("steps must be at least 2")
    split = _canonical_split(split)
    wrng = _rng("gop-reference-v1", family, split, int(world_id))
    nrng = _rng("nested-noise-v1", family, split, int(world_id), int(seed))
    variant = _variant(split, int(world_id))
    d, k = DIMENSIONS[family]
    x = np.zeros((steps+1, d), dtype=np.float64)
    auxiliary = {}
    mechanisms = []
    names, context, state_names, units = [], [], [], []
    if family == "S01":
        dt = 1.
        a, b, coupling = wrng.uniform(.70, .90), wrng.uniform(.72, .93), wrng.uniform(.03, .10)
        A = np.array([[a, coupling], [-coupling, b]])
        u = _inputs(wrng, steps, 1, .25 if variant != "intervention_transfer" else .6)
        x[0] = wrng.normal(0, .5, 2)
        process_sd = .025
        for t in range(steps):
            x[t+1] = A @ x[t] + np.array([u[t, 0], 0.]) + nrng.normal(0, process_sd, 2)
        names = ["a11", "a22", "antisymmetric_coupling", "process_sd"]
        context = [a, b, coupling, process_sd]
        mechanisms = ["stable two-component linear Gaussian state evolution", "selective first-component intervention"]
        state_names, units = ["x1", "x2"], ["dimensionless"]*2
        auxiliary["conditional_mean"] = x[:-1] @ A.T + np.column_stack([u[:, 0], np.zeros(steps)])
    elif family == "S02":
        dt = .05
        alpha, beta, delta = wrng.uniform(.7, 1.3), wrng.uniform(.7, 1.3), wrng.uniform(.12, .25)
        switch = variant == "mechanism_transfer"
        u = np.column_stack([_inputs(wrng, steps, 1, .7 if variant != "intervention_transfer" else 1.3, block=5)[:, 0], np.ones(steps)])
        if switch:
            u[steps//2:, 1] = -1.
        x[0] = wrng.uniform(-1.4, 1.4, 2)
        def drift(z, force, sign):
            return np.array([z[1], -delta*z[1] - sign*alpha*z[0] - beta*z[0]**3 + force])
        for t in range(steps):
            sign = u[t, 1]
            z, h = x[t].copy(), dt/4
            for _ in range(4):
                k1 = drift(z, u[t, 0], sign)
                k2 = drift(z+h*k1/2, u[t, 0], sign)
                k3 = drift(z+h*k2/2, u[t, 0], sign)
                k4 = drift(z+h*k3, u[t, 0], sign)
                z += h*(k1+2*k2+2*k3+k4)/6
            x[t+1] = z
        names = ["linear_stiffness", "cubic_stiffness", "damping", "switch_enabled"]
        context = [alpha, beta, delta, float(switch)]
        mechanisms = ["Duffing cubic force", "fixed four-substep RK4 reference", "midpoint stiffness sign switch" if switch else "fixed single-well potential"]
        state_names, units = ["position", "velocity"], ["L", "L/tau"]
    elif family == "S03":
        dt = .025
        mass = wrng.uniform(.8, 1.2)
        wx, wy = wrng.uniform(.75, 1.4, 2)
        mu = wrng.uniform(.8, 1.2)
        gravity = variant == "mechanism_transfer"
        u = _inputs(wrng, steps, 2, .03 if gravity else .12)
        if gravity:
            radius, phase = wrng.uniform(.8, 1.4), wrng.uniform(0, 2*np.pi)
            radial = np.array([np.cos(phase), np.sin(phase)])
            x[0, :2] = radius*radial
            x[0, 2:] = mass*np.sqrt(mu/radius)*np.array([-radial[1], radial[0]])
            def force(q):
                return -mass*mu*q/np.linalg.norm(q)**3
            for t in range(steps):
                q, p, h = x[t, :2].copy(), x[t, 2:].copy(), dt/4
                for _ in range(4):
                    p += .5*h*(force(q)+u[t])
                    q += h*p/mass
                    p += .5*h*(force(q)+u[t])
                x[t+1] = np.r_[q, p]
            energy = np.sum(x[:, 2:]**2, axis=1)/(2*mass)-mass*mu/np.linalg.norm(x[:, :2], axis=1)
        else:
            x[0] = wrng.uniform(-1., 1., 4)
            w = np.array([wx, wy]); c = np.cos(w*dt); s = np.sin(w*dt)
            for t in range(steps):
                q, p = x[t, :2], x[t, 2:]
                x[t+1, :2] = c*q+s*p/(mass*w)+u[t]*(1-c)/(mass*w*w)
                x[t+1, 2:] = c*p-mass*w*s*q+u[t]*s/w
            energy = np.sum(x[:, 2:]**2, axis=1)/(2*mass)+.5*mass*np.sum(x[:, :2]**2*np.array([wx, wy])**2, axis=1)
        context, names = [wx, wy, mass, mu, float(gravity)], ["omega_x", "omega_y", "mass", "gravitational_mu", "inverse_square_enabled"]
        state_names, units = ["qx", "qy", "px", "py"], ["L", "L", "M L/tau", "M L/tau"]
        mechanisms = ["planar inverse-square central force, four-step velocity Verlet" if gravity else "two exact harmonic propagators under piecewise constant external forces"]
        auxiliary["mechanical_energy"] = energy
    elif family == "S04":
        dt = .1
        springs = wrng.uniform(.8, 1.4, 2)
        mobility = wrng.uniform(.7, 1.2, 2)
        temperature = wrng.uniform(.08, .2)
        u = np.column_stack([_inputs(wrng, steps, 1, .5)[:, 0], np.full(steps, temperature)])
        if variant == "mechanism_transfer":
            u[steps//2:, 1] *= 2.5
        if variant == "intervention_transfer":
            u[:, 0] *= 2.
        x[0] = wrng.normal(0, .6, 2)
        decay = np.exp(-mobility*springs*dt)
        means, heat, work = [], [], []
        old_center = np.array([u[0, 0], 0.])
        for t in range(steps):
            center = np.array([u[t, 0], 0.])
            mean = center+decay*(x[t]-center)
            sd = np.sqrt((u[t, 1]/springs)*(1-decay**2))
            x[t+1] = mean+nrng.normal(0, 1, 2)*sd
            old_U = .5*np.sum(springs*(x[t]-old_center)**2)
            pre_U = .5*np.sum(springs*(x[t]-center)**2)
            post_U = .5*np.sum(springs*(x[t+1]-center)**2)
            work.append(pre_U-old_U); heat.append(post_U-pre_U); means.append(mean)
            old_center = center
        context = [*springs, *mobility]
        names = ["spring_1", "spring_2", "mobility_1", "mobility_2"]
        state_names, units = ["q1", "q2"], ["L", "L"]
        mechanisms = ["exact Gaussian Ornstein-Uhlenbeck transition", "piecewise constant trap protocol and reservoir T", "Boltzmann constant=1 in nondimensional reference units"]
        auxiliary = {"conditional_mean": np.asarray(means), "heat_into_system": np.asarray(heat), "protocol_work": np.asarray(work)}
    elif family == "S05":
        dt = .1
        mode = world_id % 3
        metabolic, action_cost, gain, leak = .16, .08, wrng.uniform(.7, 1.1), .12
        target, capacity = 1., 2.
        nonlinear = variant == "mechanism_transfer"
        u = .45+_inputs(wrng, steps, 1, .2)
        if variant == "intervention_transfer":
            u[steps//2:] *= .4
        x[0] = [wrng.uniform(.65, 1.4), 0., .5]
        terms = []
        for t in range(steps):
            r, memory, action = x[t]
            inflow = u[t, 0]*action/(.5+action) if nonlinear else u[t, 0]*action
            raw_next_r = r+dt*(inflow-metabolic-action_cost*action**2)
            next_r = np.clip(raw_next_r, 0., capacity)
            if mode == 0:
                next_m, next_a = 0., .5
            elif mode == 1:
                next_m, next_a = 0., np.clip(.5+gain*(target-r), 0., 1.)
            else:
                next_m = np.clip((1-dt*leak)*memory+dt*(target-r), -1., 1.)
                next_a = np.clip(.5+gain*(target-r)+memory, 0., 1.)
            x[t+1] = [next_r, next_m, next_a]
            terms.append([dt*inflow, dt*metabolic, dt*action_cost*action**2, next_r-raw_next_r])
        context = [metabolic, action_cost, gain, float(mode), float(nonlinear)]
        names = ["maintenance", "action_cost", "gain", "controller_mode", "saturating_harvest_enabled"]
        state_names, units = ["resource", "integral_memory", "actuator"], ["R", "R tau", "dimensionless"]
        mechanisms = ["passive" if mode == 0 else "reactive" if mode == 1 else "integral adaptive controller", "explicit clipped resource budget", "designer-defined viability proxy r>0.25"]
        auxiliary = {"budget_terms_in_out_cost_boundary": np.asarray(terms), "viability_proxy": x[:, 0]>.25}
    elif family == "S06":
        dt = 1.
        delay = 3 if variant == "mechanism_transfer" else 1
        # Balance disconnected controls across every locked transfer stratum;
        # do not couple channel status to the modulo-4 transfer assignment.
        connected = float((world_id//4 + world_id%4) % 4 != 0)
        rho, beta = wrng.uniform(.2, .5), wrng.uniform(.15, .35)
        encoding = wrng.choice([-1., 1.])*wrng.uniform(.7, 1.4)
        u = np.column_stack([wrng.normal(0, .4, steps), np.ones(steps)])
        if world_id % 3 == 0 or variant == "intervention_transfer":
            u[steps//2:, 1] = -1.
        x[0] = [wrng.normal(0, .4), 0., 0., 0.]
        arrivals = []
        for t in range(steps):
            past_index = t+1-delay
            past = x[past_index, 2] if past_index >= 0 else 0.
            received = connected*(past/encoding+nrng.normal(0, .025))
            x[t+1, 0] = rho*x[t, 0]+u[t, 0]
            x[t+1, 1] = beta*x[t, 1]+(1-beta)*received
            x[t+1, 2] = encoding*x[t, 0]
            x[t+1, 3] = u[t, 1]*x[t, 1]
            arrivals.append(received)
        context = [rho, beta, encoding, connected, float(delay)]
        names = ["source_decay", "receiver_decay", "signal_encoding", "channel_connected", "channel_delay"]
        state_names, units = ["source", "receiver_memory", "emitted_signal", "action"], ["dimensionless"]*4
        mechanisms = ["noisy calibrated linear encoding", "explicit finite delay", "goal-dependent receiver action", "disconnected channel null" if not connected else "connected channel"]
        auxiliary = {"received_message_privileged": np.asarray(arrivals), "task_target_proxy": u[:, 1]*x[:-1, 0]}
    elif family == "S07":
        dt = 1.
        common_input = world_id % 3 == 0
        decay = wrng.uniform(.65, .8)
        coupling = 0. if common_input else wrng.uniform(.06, .16)
        c12, c21 = coupling, coupling
        if variant == "mechanism_transfer" and not common_input:
            c12, c21 = 1.8*coupling, 0.
        gains = wrng.uniform(.7, 1.3, 2)
        if variant == "observer_transfer":
            gains[1] *= .6  # Public tool substitution, separate from calibration.
        u = _inputs(wrng, steps, 2, .3, block=4)
        if common_input:
            u[:, 1] = u[:, 0]
        x[0] = wrng.normal(0, .4, 2)
        for t in range(steps):
            x[t+1] = decay*x[t] + np.array([c12*np.tanh(x[t, 1]-x[t, 0]), c21*np.tanh(x[t, 0]-x[t, 1])])+gains*u[t]
            x[t+1] += nrng.normal(0, .008, 2)
        context = [decay, c12, c21, *gains]
        names = ["decay", "coupling_2_to_1", "coupling_1_to_2", "tool_gain_1", "tool_gain_2"]
        state_names, units = ["agent_1_output", "agent_2_output"], ["dimensionless"]*2
        mechanisms = ["bounded reciprocal coordination" if coupling else "uncoupled common-input control", "independently recorded assigned task drives", "no human meaning inference"]
        auxiliary["coordination_proxy"] = (x[:, 0]-x[:, 1])**2
    elif family == "S08":
        dt = 1.
        diffusivity, decay = wrng.uniform(.12, .24), wrng.uniform(.005, .04)
        periodic = variant == "mechanism_transfer"
        L = np.zeros((5, 5))
        for i in range(4):
            L[i, i] -= 1; L[i+1, i+1] -= 1; L[i, i+1] += 1; L[i+1, i] += 1
        if periodic:
            L[0, 0] -= 1; L[4, 4] -= 1; L[0, 4] += 1; L[4, 0] += 1
        A = (1-decay)*np.eye(5)+diffusivity*L
        x[0] = wrng.normal(0, .5, 5)
        u = _inputs(wrng, steps, 1, .2 if variant != "intervention_transfer" else .5, block=3)
        for t in range(steps):
            x[t+1] = A@x[t]
            x[t+1, 0] += u[t, 0]
        context, names = [diffusivity, decay, float(periodic)], ["diffusive_weight", "decay", "periodic_boundary"]
        state_names, units = [f"site_{i}" for i in range(5)], ["field_amplitude"]*5
        mechanisms = ["five-site local discrete diffusion", "periodic graph" if periodic else "reflecting chain graph", "one graph edge influence radius per discrete update; not Lorentz covariance"]
        auxiliary["reference_transition_matrix"] = A
    elif family == "S10":
        dt = 1.
        composite = variant == "mechanism_transfer"
        u = np.zeros((steps, 2))
        u[:, 0] = wrng.choice([0, 1, 2, 3, 4], steps, p=[.08, .25, .27, .12, .28])
        if composite:
            u[:, 1] = wrng.choice([1, 2, 4], steps)
        else:
            second = wrng.random(steps)<.35
            u[second, 1] = u[second, 0]; u[second, 0] = 0
        x[0] = wrng.integers(0, 2, 3)
        erase_events = []
        def gate(z, op):
            a, b, c = map(int, z)
            return np.array({0: [a, b, c], 1: [b, c, a], 2: [a, a ^ b, c],
                             3: [a, 0, c], 4: [1-a, b, c]}[int(op)], dtype=float)
        for t in range(steps):
            mid = gate(x[t], u[t, 0]); x[t+1] = gate(mid, u[t, 1])
            erase_events.append(int(u[t, 0]==3)+int(u[t, 1]==3))
        context, names = [3., 2.], ["register_count", "ordered_gate_layers"]
        state_names, units = ["bit_a", "bit_b", "bit_c"], ["bit"]*3
        mechanisms = ["identity/rotate/CNOT/erase/NOT register gates", "ordered two-gate composition" if composite else "single active gate with identity in other layer", "erasure loses distinctions unless a separate provenance register is included"]
        auxiliary["erase_gate_count"] = np.asarray(erase_events)
    y, raw, mask, sensor_meta = _observe(x, family, world_id, variant, wrng, nrng)
    test_type = {"in_distribution": "known_mechanism", "observer_transfer": "observer_shift",
                 "intervention_transfer": "intervention_shift", "mechanism_transfer": "composition_shift" if family == "S10" else "mechanism_shift"}.get(variant, "development_population")
    if variant == "mechanism_transfer" and family == "S01":
        test_type = "known_mechanism"
    if variant == "mechanism_transfer" and family == "S04":
        test_type = "intervention_shift"
    meta = {"family": family, "world_id": int(world_id), "split": split, "noise_seed": int(seed), "test_type": test_type,
            "variant": variant, "mechanisms": mechanisms, "parameters": dict(zip(names, map(float, context))),
            "context_names": names, "context_is_public": True, "state_names": state_names,
            "state_units": units, "nondimensionalization": "fixed simulator reference units; no trajectory-fitted scaling",
            "targets": ["next calibrated observation", "finite-horizon calibrated observations"],
            "truth_privileged": ["x", "auxiliary", "true_sensor_matrix_privileged"], **sensor_meta}
    result = {"x": x, "y": y, "y_raw": raw, "mask": mask, "u": np.asarray(u, dtype=float),
              "dt": float(dt), "context": np.asarray(context, dtype=float), "meta": meta, "auxiliary": auxiliary}
    if not np.isfinite(x).all() or not np.isfinite(y).all():
        raise FloatingPointError(f"Non-finite reference trajectory for {family}/{split}/{world_id}/{seed}")
    return result
