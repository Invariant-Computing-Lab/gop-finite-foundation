"""Assemble the manuscript only from executed result artifacts."""
from pathlib import Path
import csv, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
def read(path):return json.loads((ROOT/path).read_text())

def main():
    empirical=read('results/empirical_run_summary.json')
    rows=empirical['families'];assert len(rows)==10
    revision=read('results/generator_revision/summary.json')
    physics=read('results/physics_results.json')['checks']
    controls=read('results/controls/summary.json')
    hybrid=read('results/f0_generator_checks.json')
    toy=read('results/toy_identification.json')
    count={s:sum(r['status']==s for r in rows) for s in ('COMPARATIVE_SUPPORT','INCONCLUSIVE','FALSIFIED_IN_REGIME')}
    figdir=ROOT/'results/figures';figdir.mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    data=np.load(ROOT/'results/generator_revision/measurements_predictions.npz')
    grid=data['grid']
    fig,axs=plt.subplots(1,2,figsize=(9,3.5),layout='constrained')
    axs[0].plot(grid,-grid-grid**3,color='#193e60',lw=2,label='Cubic reference')
    axs[0].plot(grid,-1.75*grid,color='#c76629',ls='--',label='Best F0-G quadratic')
    axs[0].plot(grid,data['F1_drift_degree3'],color='#288276',ls=':',lw=2,label='Fitted F1-G cubic')
    axs[0].set(xlabel='Resolved coordinate x',ylabel='Instantaneous drift',title='Cubic repair')
    axs[0].legend(fontsize=8)
    axs[1].plot(grid,(-grid-grid**3)+1.75*grid,color='#c76629',label='F0 class residual: cubic')
    axs[1].plot(grid,(-grid-grid**5)+11/16*grid+5/4*grid**3,color='#288276',label='F1 class residual: quintic')
    axs[1].axhline(.01,color='#777777',lw=.8,ls=':');axs[1].axhline(-.01,color='#777777',lw=.8,ls=':')
    axs[1].set(xlabel='Resolved coordinate x',ylabel='Reference minus minimax drift',title='Irreducible class errors')
    axs[1].legend(fontsize=8,loc='lower right')
    fig.savefig(figdir/'generator_obstructions.png',dpi=200);fig.savefig(figdir/'generator_obstructions.pdf');plt.close(fig)
    fig,ax=plt.subplots(figsize=(9,3.2),layout='constrained')
    pos=np.arange(10);a=np.array([r['candidate_mse1'] for r in rows]);b=np.array([r['comparator_mse1'] for r in rows])
    ax.bar(pos-.18,a,.36,color='#193e60',label='F0-P')
    ax.bar(pos+.18,b,.36,color='#c76629',label='Development-selected comparator')
    ax.set_yscale('log');ax.set_xticks(pos,[r['family'] for r in rows]);ax.set(ylabel='One-step normalized MSE (log)',xlabel='Family')
    ax.legend(fontsize=9);fig.savefig(figdir/'prediction_comparison.png',dpi=200);fig.savefig(figdir/'prediction_comparison.pdf');plt.close(fig)
    table='| Family | F0-P | Comparator | Comparator error | Result |\n|---|---:|---|---:|---|\n'
    for r in rows:
        label={'INCONCLUSIVE':'Inconclusive','FALSIFIED_IN_REGIME':'Deficit supported','COMPARATIVE_SUPPORT':'Advantage supported'}[r['status']]
        table+=f"| {r['family']} | {r['candidate_mse1']:.6f} | {r['comparator'].replace('_',' ')} | {r['comparator_mse1']:.6f} | {label} |\n"
    s10=rows[-1]
    text=r'''---
title: 'A Falsifiable Theory-of-Everything Candidate from Generalized Occupation: Formal Closure and Synthetic Stress Tests'
author: 'Emirhan Yıldırım'
date: '2 October 2026 — Author-review draft'
fontsize: 11pt
geometry: margin=24mm
colorlinks: false
---

## Abstract

The Generalized Occupation Paradigm proposes that observation, representation, communication and action belong inside accounts of the world, while its original equations remain descriptive bookkeeping. This follow-up constructs a finite, explicit candidate with universal explanatory intent and exposes its restrictions to counterexamples. F0-G combines a local quadratic classical generator, declared observer/controller/channel maps and a restricted finite quantum sector. It is implemented in a bidirectional classical–quantum loop. A separate observation-space surrogate, F0-P, is fitted and compared across ten independent synthetic generator families. These tracks are not interchangeable. F0-G's additional fixed-coordinate infinitesimal claim fails on a confining cubic drift; a degree-three F1 repairs that example but fails a prospective quintic mechanism. Imported oscillator, thermodynamic and quantum submodels pass scoped numerical checks. Reduced memoryless and autonomous unital-sector restrictions fail explicit tests. The study produces an executable candidate and negative evidence, not a derivation of existing physical laws or a completed theory of everything.

## 1. Research question and provenance

The author's stated research chronology begins with an independent search for unity in physics; occupational therapy/science subsequently became a proposed route toward that goal. The source paper separates generalized agent–world engagement from calling every interaction an occupation, and separates human meaning from numerical efficiency. It calls its state-space equations bookkeeping rather than new laws of motion [@yildirim2026gop]. We preserve these commitments and the distinct RARI, OCIL/OCIR, AFC and SACRA programs. This study creates no fifth program and does not validate historical results by association.

The motivating conjecture is strong: every physically realizable process, including embedded observers, might admit an accountable realization under a common law architecture. A finite candidate must then state its admissible regimes, errors, physical coordinates and complexity limits. The claim that some unspecified future architecture could explain everything is not itself operationally falsifiable. We test a restricted instantiation and retain the broader ambition as unresolved.

The complete five-page conceptual source and the execution prompt were supplied and read. The previously described ZIP, editable DOCX, reading list and source/change map were absent. Newly created provenance records are identified as reconstructions, not the missing originals. The technical review verified ten external primary works with explicit access levels; it is selective, not systematic or exhaustive. Kernel composition, sparse regression, thermodynamics and quantum postulates are imported mathematics [@fritz2020; @brunton2015; @seifert2005; @lindblad1976; @gorini1976]. The new contribution is the accountable restriction and its implemented tests; explanatory physical novelty remains unestablished.

## 2. Explicit candidate and forbidden outcomes

For declared classical coordinates $z$, graph neighbourhoods $\mathcal N_i$, controls $u$ and Brownian increments $dW$, F0-G specifies

$$
dz_i=\left[c_i+\sum_{j\in\mathcal N_i}A_{ij}z_j+
\sum_{j\leq k\in\mathcal N_i}B_{ijk}z_jz_k+
\sum_\ell E_{i\ell}u_\ell\right]dt+\sum_a\Sigma_{ia}dW_a.
$$

Diffusion $\Sigma\Sigma^\top$ is constant and positive semidefinite. Every coefficient is stored; physically incompatible units are first nondimensionalized. Elementary internal and policy maps have degree at most two. Sensors are affine Gaussian instruments with declared back-action; previous-message buffers are consumed before replacement. The causal step is

$$\mathcal K_h=\mathcal D_h\circ\mathcal C\circ\mathcal A\circ\mathcal U\circ\mathcal O.$$

Here $\mathcal O$ measures, $\mathcal U$ updates internal records, $\mathcal A$ acts and emits, $\mathcal C$ transmits, and $\mathcal D_h$ evolves the environment and finite quantum state. The quantum generator imports GKSL structure,

$$
\mathcal L_z(\rho)=-\frac{i}{\hbar}[H(z),\rho]+
\sum_\alpha\gamma_\alpha\left(L_\alpha\rho L_\alpha^\dagger-
\tfrac12\{L_\alpha^\dagger L_\alpha,\rho\}\right),
$$

with a declared one/two-site Hermitian Pauli jump library and nonnegative rates. Born instruments and Hilbert space are assumed, not derived. An operator-valued classical distribution accounts for classical–quantum correlation; conditioned trajectories do not imply factorized ensembles. The mathematical supplement defines domains, normalization, finite description budgets, units, coordinate transformations, trajectory probabilities and elementary proofs.

The executed four-coordinate example has $(q,p,m,b)=(1,0,0,0)$, $h=0.05$, measurement $y=q$, back-action $p^O=p+0.02y$, internal update $m^+=0.8m+0.2(y+b)$, actuation $a=-0.4m^+$ and next buffer $b'=0.9(0.5m^+)$. Euler evolution gives $(1.001,-0.0341,0.2,0.09)$. The full 256-step implementation additionally lets quantum outcomes affect classical memory and classical state control the qubit Hamiltonian. It is an explicit open-system realization: prescribed apparatus and work sources prevent a claim of global physical closure.

The broad finite-horizon conjecture uses bounded Wasserstein distance between recorded interventional trajectories, within a declared state/description budget. The decisive scalar test adds a **separate necessary restriction G0**: in one fixed physical coordinate, with no hidden states or replacement by instrument jumps, the instantaneous drift must agree within 0.01 uniformly on $[-1,1]$. This condition is not logically implied by finite-time trajectory agreement alone. F0-G also excludes state-dependent diffusion in its classical block and unconditional amplitude damping in its autonomous Hermitian-Pauli sector. Augmented or feedback realizations may evade some reduced-sector obstructions and are not ruled out by them.

## 3. Exact counterexamples and measured F1 revision

For $\dot x=-x-x^3$, the best quadratic drift is $-7x/4$. Since $x^3=(T_3+3x)/4$, its sharp uniform error on $[-1,1]$ is $1/4$. The alternating-extrema argument proves this class lower bound independently of regression. Both this and the later quintic example are confining overdamped gradient flows in nondimensional units. Their physical applicability is an assumption of the declared effective regime; no real-world experiment is reported.

F1-G changes only maximum classical drift degree from two to three, adding one coefficient in the scalar example. Its coefficients are fitted from 256 noisy short-time endpoint differences generated by an independent DOP853 solver. Candidate trajectories use separately coded RK4. Finite differences retain a small $O(h)$ bias. The source and contract are frozen before measurement generation; fitted coefficients are frozen before the prospective quintic mechanism. The class witness was deliberately known during construction and is not a blind discovery.

For the fresh mechanism $\dot x=-x-x^5$, the best cubic is $-11x/16-5x^3/4$, with irreducible error $1/16$. Thus increasing the degree repairs one example without establishing universal adequacy. Fixed-degree/no-lift universality fails on the admitted scalar class; the broader possible hidden-realization or future-architecture conjecture remains unresolved.

![Direct-generator class obstructions and the measured F1 repair. Dotted horizontal lines mark the registered drift tolerance of 0.01.](../results/figures/generator_obstructions.png)

GENERATOR_VALUES

The identification toy separately verifies $x_1=(y_u-y_0)/(k-1)$ and $x_2=(ky_0-y_u)/(k-1)$ under stationarity and selective intervention. Independent observation noise of variance $\sigma^2$ gives $\operatorname{Var}(\hat x_1)=2\sigma^2/(k-1)^2$. With $\sigma=0.03$, decreasing $k$ from 2 to 1.001 raises this variance from 0.0018 to 1800. The 100,000 noise replicates are not 100,000 independent worlds. An unknown shared gain leaves a scale gauge; clipping produces distinct states with identical records; wrongly labeling true $k=2$ as 1.5 moves the estimate from $(0.7,-0.2)$ to $(1.4,-0.9)$. More intervention does not automatically mean more identification. A separately frozen equal-budget design control compares passive, random, informative and conventional D-optimal acquisitions. With two readings and k in [1.1,2], Fisher determinant is (k-1)^2/sigma^4, so D-optimal design selects k=2 and exactly matches the fixed informative choice. Analytic total MSE is 0.006300 for both, versus 0.041505 for uniform random k; 100,000 acquisitions verify the calculation. No novel policy advantage is demonstrated.

## 4. Ten-family learned prediction experiment

Independent reference modules implement S01 linear partial observation, S02 Duffing/switching dynamics, S03 oscillator/inverse-square mechanics, S04 exact OU processes, S05 resource controllers, S06 communication, S07 coactivity/common input, S08 local lattices, S09 one-qubit ensemble tomography and S10 reversible/erasing computation. They do not import candidate learners. Their family-specific equations and observation rules are in the generator specification. S09 coordinates are noisy expectations from separately prepared ensembles, not simultaneous outcomes of incompatible measurements on one qubit.

Each family uses 24 training, 8 development, 8 calibration and 16 locked worlds, with three nested stochastic realizations and 128 steps: **560 worlds and 1,680 trajectories** overall, of which 160 worlds are locked. World parameters, not windows or noise seeds, determine independent units. Several transfer strata contain only four worlds. Post-evaluation scope inspection found that the nominal intervention-shift slots in S03, S07 and S10 had no policy manipulation: these 12 worlds are additional known-mechanism draws. S01 nominal observer slots can be overridden by rank-loss/unknown-gain cases; S09 only tests known-mechanism generalization. Frozen labels and primary mixtures are retained, while separate scope-correction records prevent false transfer claims. These design limitations are not silently repaired by rerunning tests.

F0-P is ridge regression on a quadratic dictionary of current and previous calibrated observations, current controls and public experimental setpoints. It shares a recipe across families but has independently fitted coefficients per family. It does not recover F0-G, preserve all its physical constraints or constitute a cross-domain shared learned law. Exact configured physical constants are provided equally as context; this is known-context forecasting, not parameter discovery. Targets are causally imputed observation records. Missingness masks are preserved in the generator but are not predictor inputs, so missingness-aware inference is not demonstrated.

Comparators are persistence, linear ridge, a sparse transition dictionary containing degree-two products plus coordinate cubes, and a 32-unit tanh MLP. Each fitted main model has three development settings. Of 30 MLP trials, 14 reached the iteration limit and emitted archived convergence warnings; bounded training is not a convergence guarantee. The sparse implementation is inspired by sparse equation discovery but is not a full SINDy reproduction or unrestricted cubic library [@brunton2015]. A development-selected comparator is fixed separately per family before locked evaluation. No-memory, no-context and constant-output controls are also executed. Learned Kalman, Hamiltonian-neural and quantum-channel comparators are not fitted; structured physics checks are a separate oracle/input track, not fair learned competitors. Hamiltonian neural models illustrate a relevant future comparator rather than an implemented method here [@greydanus2019].

The primary endpoint is world-averaged one-step train-standardized MSE. Paired stratified bootstrap intervals use 20,000 resamples and 99.5% nominal intervals across ten primary families. With 16 worlds these are approximate, not an exact familywise guarantee. The predeclared engineering margin is 0.01, not a clinical or universal physical threshold. An advantage requires the upper difference interval below -0.01; a deficit requires the lower interval above 0.01; otherwise evidence is inconclusive. Sixteen-step recursive forecasts are secondary. Divergence is retained with an explicit indicator and a predeclared capped-loss rule; it is not silently deleted.

World-block split conformal calibration uses the maximum standardized residual across each world's seeds, times and coordinates. With eight calibration worlds, finite 80% coverage uses order statistic eight; 90% would require an infinite threshold. Coverage guarantees require exchangeable worlds [@lei2017]. Shifted-test coverages are descriptive and do not inherit this guarantee. The procedure is frozen locally, not externally preregistered. Separate agents share the same filesystem, so this is procedural separation without investigator blinding.

## 5. Locked results

EMPIRICAL_RESULTS

EMPIRICAL_TABLE

![Locked one-step error and the S10 mixture diagnostic. The apparent pooled advantage does not imply uniformly useful forecasts; the frozen nominal intervention label in S10 represents additional known-mechanism draws. All S10 F0-P long-horizon rollouts diverge.](../results/figures/forecast_results.png)

All model outputs are stored before scoring. The archive includes fitted models, scalers, development settings, prediction arrays, nested seed/world manifests and code hashes. The full raw table retains every comparator and ablation, including long-horizon divergence. An output-persistence inconsistency left some S10 derived records absent even though all prediction archives and the final run summary existed. The cause remains unknown. Incomplete originals were preserved; missing records were reconstructed from immutable predictions and frozen deterministic generators, with exact agreement of regenerated target observations. The independent verifier subsequently reproduced all 1,280 metric rows and hashes. This was bookkeeping recovery, without refitting or changing predictions. No outcome-dependent increase in sample size or post-locked model revision was performed. The auxiliary F1 generator experiment is independent of these locked forecasts.

## 6. Physical and operational checks

The oscillator checker compares independent exact and numerical dynamics and recovers second-order convergence; the finest relative energy residual is $1.56\times10^{-4}$. A direct-coordinate quadratic force cannot exactly equal inverse-square attraction (nonzero third divided difference $25/288$); a separate imported Newtonian orbit conserves energy within $2.10\times10^{-10}$. This checks Newtonian consistency without deriving gravitation or general relativity.

A single-reservoir two-state jump process fixes temperature, energies, heat, work and forward/reverse path laws. Exact enumeration of 32 paths gives $\langle e^{-\Delta s_{tot}}\rangle=1.0000000000000004$, avoiding rare-event Monte Carlo claims. Detailed balance and reservoir assumptions are inputs [@seifert2005]. OU numerical moments converge to the exact process. No global apparatus/feedback thermodynamic balance is obtained.

Finite quantum checks verify normalization, complete positivity through Choi matrices, Born probabilities, measurement back-action, dephasing and no signaling. The tiny minimum Choi eigenvalue of approximately $-1.59\times10^{-31}$ is roundoff at the registered numerical tolerance. A swap-memory construction has reduced trace distances $(1,0,1)$ and rejects the reduced memoryless description while admitting the explicitly augmented two-qubit process. This is consistent with distinguishing reduced Markov assumptions from process memory [@pollock2018]. Autonomous Hermitian-Pauli dissipation is unital and cannot match amplitude damping of the maximally mixed state: the tested trace-distance gap is 0.122108. It does not exclude an augmented dilation or measurement-feedback realization.

The synchronous lattice has zero effect outside its discrete causal cone. This is a one-edge-per-tick rule, not Lorentz covariance; continuous local generators need not have exact zero tails. Relativistic geometry, a dynamical metric, stress-energy coupling, continuum quantum fields and gauge-interaction recovery remain absent. Their missing maps are recorded in the physics recovery matrix.

Separate controlled examples distinguish transmission from designer-defined relevance: transmission accuracy is 1, yet an unchanged receiver policy has accuracy 0 after its goal reverses. A disconnected channel's paired causal effect is zero by construction. Common input gives nearly perfect synchrony with zero cross-agent causal effect, whereas a coupled control transmits a probe. Correct, wrongly paired and constant representations discriminate at 1, 0 and 0.25 respectively. Reversible, erased and provenance-retaining registers preserve 8, 4 and 8 distinctions. These verify specified examples, not learned causal-recovery or false-positive rates. Logical erasure is not itself a measurement of dissipated heat [@landauer1961].

Resource-controller target errors improve in the assigned task, but passive, reactive and adaptive controls all satisfy the selected viability threshold. Neither superior survival nor intrinsic autonomy follows. Counterfactual task relevance is a synthetic proxy and does not reproduce lived human meaning or clinical participation [@kolchinsky2018]. The original source's normative pluralism is preserved.

## 7. What was established and what remains

Elementary proofs cover composition validity, refinement of exact intervention-equivalence classes, non-reconstruction under non-injective observations, conditional representation transport, uniform composition-error bounds, and consequences of imported physical submodels. No proof assistant was used. Symbolic-software verification of the identification algebra was unavailable; direct algebraic arguments and numerical checks remain distinct.

The strongest justified claim is that a fully specified candidate was made vulnerable to mathematical and synthetic evidence, and several of its restrictive instances failed. The architecture does not derive its Hamiltonian, Born rule, clock, graph, probability calculus or reservoir laws. Ten family labels do not demonstrate a shared physical explanation. A finite common syntax, separately fitted regressions and valid quantum composition are insufficient to establish physical unification.

The unresolved stronger reality/observation thesis is kept separate from apparatus-dependent knowledge records: no experiment here distinguishes it from observer-independent ontologies with identical records. Global closure, autonomous agency, human meaning, clinical benefit, full counterfactual identification, and cross-domain composition of a single learned physical law remain unestablished. The requirement audit explicitly lists unexecuted variants and comparators. Future work must justify a more expressive restriction prospectively, not add exceptions until all existing tests pass.

## Reproducibility and declarations

COMPUTE_VALUES

Code, generator definitions, scalar/physical raw arrays, fitted checkpoints, predictions, seeds, scientific contracts, failed versions, independent arithmetic verification and clean-copy smoke records are distributed together. Original source bytes are unchanged. The README describes how to verify archived evidence without reopening the old test as new confirmation.

Author information follows the supplied source: occupational therapy student, Invariant Computing Program, Istanbul, Türkiye; ORCID 0009-0002-5884-3660. This is an author-review draft, not an endorsed or submitted manuscript. AI assistance generated code, derivations, experiments and this draft; parallel AI agents are not independent human investigators. No participant data or new clinical findings are reported. The source declares that the author founded the program and has roles in associated ventures.

## References
'''
    text=text.replace('GENERATOR_VALUES',f"The fitted F0-G cubic-system drift error was {revision['F0_degree3_uniform_drift_error']:.6f}; F1-G reduced it to {revision['F1_degree3_uniform_drift_error']:.6f}. On the prospective quintic mechanism, the fitted F1-G error was {revision['F1_degree5_uniform_drift_error']:.6f}. Fitted errors are distinct from the sharp class bounds 0.25 and 0.0625. No F2 was tuned to hide the remaining failure.")
    text=text.replace('EMPIRICAL_RESULTS',f"There were {count['COMPARATIVE_SUPPORT']} registered comparative advantages, {count['FALSIFIED_IN_REGIME']} supported comparative deficits and {count['INCONCLUSIVE']} inconclusive family-level results. Inconclusive does not mean equivalent or validated. For S10, F0-P error was {s10['candidate_mse1']:.6f} versus {s10['comparator_mse1']:.6f} for its frozen comparator; the difference was {s10['difference']:.6f}, with nominal 99.5% interval [{s10['ci_low99_5']:.6f}, {s10['ci_high99_5']:.6f}]. This is a narrow advantage for the fixed mixture, not support for F0-G. It is driven by the composition-shift stratum, where both predictors are poor: F0-P error 1.541 versus MLP 4.609. In known-mechanism worlds, F0-P is much worse (0.469 versus 0.00295). All 16 F0-P S10 worlds diverge during 16-step recursive prediction. These descriptive strata expose a limitation hidden by the pooled one-step endpoint; no new post-hoc confirmatory claim is made. Across the mixed locked populations, trajectory-level coverage ranged from {min(r['trajectory_coverage80'] for r in rows):.1%} to {max(r['trajectory_coverage80'] for r in rows):.1%}; interval width and shift stratum must accompany those numbers.")
    text=text.replace('EMPIRICAL_TABLE',table)
    text=text.replace('COMPUTE_VALUES',f"The recorded runtime is Python 3.12.14 with NumPy 2.3.5 and SciPy 1.17.0 on CPU. Numerical processes use one BLAS thread each within a maximum four-worker budget. Main development took {empirical['development_seconds']:.3f} seconds and locked prediction/scoring took {empirical['locked_seconds']:.3f} seconds. These are measured script times, not the total elapsed research and writing time. The core allocation was fixed after a measured smoke run; no paid service was opened.")
    (ROOT/'manuscript/paper.md').write_text(text)
    print(json.dumps({'main_markdown_written':True,'family_counts':count,'figures':2,'words_approx':len(text.split())}))

if __name__=='__main__':main()
