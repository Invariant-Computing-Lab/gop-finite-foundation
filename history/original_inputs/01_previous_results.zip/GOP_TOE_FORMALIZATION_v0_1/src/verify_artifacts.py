"""Independent, read-only scientific-artifact verifier.

No pipeline scoring or learner module is imported. Predictions are read, not
regenerated. This verifies arithmetic/provenance, not physical truth or blinding.
Only this verifier's JSON/CSV reports are written, under results/independent/.
"""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime
import argparse, csv, hashlib, json
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def capped_nmse(truth, predicted, scale):
    """Independent expression of frozen capped, standardized squared error."""
    residual = (np.asarray(predicted, dtype=float)-truth)/scale
    residual = np.where(np.isnan(residual), 1e6, residual)
    residual = np.maximum(-1e6, np.minimum(1e6, residual))
    return float(np.sum(residual*residual)/residual.size)


def close(actual, expected, rtol=2e-10, atol=2e-12):
    return bool(np.isclose(float(actual), float(expected), rtol=rtol, atol=atol,
                           equal_nan=False))


def generator_revision_checks(root):
    base = root/'results/generator_revision'
    freeze = json.loads((base/'prefit_freeze.json').read_text())
    summary = json.loads((base/'summary.json').read_text())
    coeffs = json.loads((base/'model_coefficients.json').read_text())
    array = np.load(base/'measurements_predictions.npz', allow_pickle=False)
    result = {'contract_hash': sha256(root/'configs/generator_revision_contract.json') == freeze['contract_sha256'],
              'script_hash': sha256(root/'src/generator_revision.py') == freeze['script_sha256']}
    coefficient_hashes = json.loads((base/'F1_before_fresh_mechanism.json').read_text())
    for model, coefficients in coeffs.items():
        c = np.array(coefficients, dtype=np.float64)
        result[model+'_model_hash'] = hashlib.sha256(c.tobytes()).hexdigest() == coefficient_hashes[model]
        pred = np.polynomial.polynomial.polyval(array['grid'], c)
        for degree in (3, 5):
            key = f'{model}_degree{degree}'
            recorded_pred = array[f'{model}_drift_degree{degree}']
            result[key+'_predictions'] = bool(np.allclose(pred, recorded_pred, rtol=1e-12, atol=1e-13))
            expected_truth = -array['grid']-array['grid']**degree
            result[key+'_truth'] = bool(np.array_equal(expected_truth, array[f'true_drift_degree{degree}']))
            actual = float(np.max(np.abs(pred-expected_truth)))
            result[key+'_reported_metric'] = close(actual, summary[key+'_uniform_drift_error'])
    return result


def prediction_checks(root):
    raw_rows = [json.loads(line) for line in (root/'results/raw_metrics.jsonl').read_text().splitlines() if line.strip()]
    key_of = lambda r: (str(r['family']), str(r['world_id']), str(r['model']))
    raw_index = {key_of(r): r for r in raw_rows}
    duplicate_count = len(raw_rows)-len(raw_index)
    results = {'raw_metric_unique_keys': duplicate_count == 0}
    failures, stratified, recomputed, checked_keys = [], [], [], set()
    for path in sorted((root/'predictions').glob('*_locked.npz')):
        family = path.name.split('_')[0]
        data = np.load(path, allow_pickle=False)
        y1, y16, scale = data['truth1'], data['truth16'], data['scale']
        worlds = [str(w) for w in data['world_ids']]
        types = [str(w) for w in data['test_types']]
        names = sorted(k[len('pred1__'):] for k in data.files if k.startswith('pred1__'))
        checks = {'positive_finite_training_scale': bool(np.all(np.isfinite(scale)) and np.all(scale>0)),
                  'unique_world_ids': len(set(worlds)) == len(worlds),
                  'finite_targets': bool(np.all(np.isfinite(y1)) and np.all(np.isfinite(y16))),
                  'world_shape': y1.shape[0] == y16.shape[0] == len(worlds) == len(types) == 16,
                  'three_nested_seeds': y1.shape[1] == y16.shape[1] == len(data['seeds']) == 3,
                  'eight_models': len(names) == 8}
        for model in names:
            p1, p16 = data['pred1__'+model], data['pred16__'+model]
            checks[model+'_shape'] = p1.shape == y1.shape and p16.shape == y16.shape
            for wi, world in enumerate(worlds):
                key = (family, world, model)
                checked_keys.add(key)
                reported = raw_index.get(key)
                if reported is None:
                    failures.append({'type':'missing_raw_metric','key':key}); continue
                actual = {'family':family,'world_id':world,'model':model,'test_type':types[wi],
                          'mse1':capped_nmse(y1[wi],p1[wi],scale),
                          'mse16':capped_nmse(y16[wi],p16[wi],scale),
                          'nonfinite_pred1_count':int(np.size(p1[wi])-np.count_nonzero(np.isfinite(p1[wi]))),
                          'nonfinite_pred16_count':int(np.size(p16[wi])-np.count_nonzero(np.isfinite(p16[wi])))}
                if model == 'F0_P':
                    error = np.abs((p1[wi]-y1[wi])/scale)
                    q = float(data['conformal_q'])
                    actual['coverage80'] = bool(np.max(error) <= q)
                    actual['pointwise_coverage80'] = float(np.count_nonzero(error <= q)/error.size)
                    actual['interval_width_mean'] = float(np.mean(2*q*scale))
                    for metric in ('coverage80','pointwise_coverage80','interval_width_mean'):
                        if not close(actual[metric], reported[metric]):
                            failures.append({'type':'coverage_mismatch','key':key,'metric':metric})
                if bool(data['diverged16__'+model][wi]) != bool(reported['diverged16']):
                    failures.append({'type':'divergence_flag_mismatch','key':key})
                if reported['prediction_sha256'] != sha256(path):
                    failures.append({'type':'prediction_hash_mismatch','key':key})
                for metric in ('mse1','mse16'):
                    if not close(actual[metric], reported[metric]):
                        failures.append({'type':'metric_mismatch','key':key,'metric':metric,'actual':actual[metric],'reported':reported[metric]})
                recomputed.append(actual)
        results[family] = checks
    results['no_unmatched_raw_metrics'] = set(raw_index) == checked_keys
    results['prediction_file_count'] = len(list((root/'predictions').glob('*_locked.npz')))
    results['ten_prediction_families'] = results['prediction_file_count'] == 10
    results['expected_1280_rows'] = len(recomputed) == 10*16*8
    results['world_model_rows_checked'] = len(recomputed)
    results['metric_failures'] = failures
    groups = defaultdict(list)
    for row in recomputed: groups[(row['family'],row['test_type'],row['model'])].append(row)
    for (family,test_type,model), rows in sorted(groups.items()):
        stratified.append({'family':family,'test_type':test_type,'model':model,'n_worlds':len(rows),
                           'mean_capped_nmse1':float(np.mean([r['mse1'] for r in rows])),
                           'mean_capped_nmse16':float(np.mean([r['mse16'] for r in rows])),
                           'nonfinite_prediction_values':sum(r['nonfinite_pred1_count']+r['nonfinite_pred16_count'] for r in rows)})
    return results, stratified, recomputed


def provenance_checks(root):
    freeze = json.loads((root/'versions/F0/EMPIRICAL_FREEZE.json').read_text())
    opened = json.loads((root/'versions/F0/LOCKED_OPEN.json').read_text())
    rows = [json.loads(s) for s in (root/'data/manifests/worlds.jsonl').read_text().splitlines() if s.strip()]
    hashes = {path: sha256(root/path) == expected for path,expected in freeze['files'].items()}
    keys = [(r['family'],r['split'],str(r['world_id']),str(r['seed'])) for r in rows]
    identity_splits = defaultdict(set)
    counts = Counter()
    for row in rows:
        identity_splits[(row['family'],str(row['world_id']))].add(row['split'])
        counts[(row['family'],row['split'])] += 1
    expected_counts={'train':24*3,'development':8*3,'calibration':8*3,'locked':16*3}
    count_checks = {fam+'_'+split: counts[(fam,split)] == n
                    for fam in [f'S{i:02d}' for i in range(1,11)] for split,n in expected_counts.items()}
    timecheck=datetime.fromisoformat(freeze['frozen_at']) <= datetime.fromisoformat(opened['opened_at'])
    return {'frozen_files_unchanged':hashes,'freeze_precedes_locked_open':timecheck,
            'locked_open_records_correct_freeze_hash':opened['freeze_sha256']==sha256(root/'versions/F0/EMPIRICAL_FREEZE.json'),
            'unique_nested_manifest_rows':len(keys)==len(set(keys)),
            'worlds_not_shared_between_splits':all(len(s)==1 for s in identity_splits.values()),
            'expected_world_seed_counts':count_checks,
            'n_independent_family_worlds':len(identity_splits),
            'n_nested_trajectories':len(rows)}


def hypothesis_checks(root, recomputed):
    with (root/'results/hypothesis_status.csv').open() as f:
        summaries=list(csv.DictReader(f))
    out={'ten_summary_families':len(summaries)==10}
    development={r['family']:r for r in json.loads((root/'results/development_results.json').read_text())}
    for row in summaries:
        fam=row['family']; comp=row['comparator']
        dev=development[fam]
        expected_comp=min(('persistence','linear','sparse_cubic','MLP'),key=lambda model:dev['development_mse'][model])
        calibrated=float(np.sort(np.array(dev['calibration_scores']))[7])
        c=sorted((r for r in recomputed if r['family']==fam and r['model']=='F0_P'),key=lambda r:int(r['world_id']))
        b={r['world_id']:r for r in recomputed if r['family']==fam and r['model']==comp}
        delta=np.array([r['mse1']-b[r['world_id']]['mse1'] for r in c])
        test_types=np.array([r['test_type'] for r in c])
        rng=np.random.default_rng(993)
        # Draw within each frozen stratum; equal world weights preserve its fixed mixture.
        resampled_totals=np.zeros(20000)
        for stratum in sorted(set(test_types)):
            vals=delta[test_types==stratum]
            indices=rng.integers(0,len(vals),size=(20000,len(vals)))
            resampled_totals += np.sum(vals[indices],axis=1)
        interval=np.quantile(resampled_totals/len(c),[.0025,.9975])
        expected_status='COMPARATIVE_SUPPORT' if interval[1]<-.01 else ('FALSIFIED_IN_REGIME' if interval[0]>.01 else 'INCONCLUSIVE')
        out[fam]={'comparator_selected_on_development':comp==expected_comp,
                  'world_max_calibration_quantile':close(calibrated,row['conformal_q']),
                  'candidate_mean':close(np.mean([r['mse1'] for r in c]),row['candidate_mse1']),
                  'comparator_mean':close(np.mean([r['mse1'] for r in b.values()]),row['comparator_mse1']),
                  'paired_difference':close(delta.mean(),row['difference']),
                  'ci_low':close(interval[0],row['ci_low99_5']),
                  'ci_high':close(interval[1],row['ci_high99_5']),
                  'registered_status':expected_status==row['status'],
                  'world_trajectory_coverage':close(np.mean([r['coverage80'] for r in c]),row['trajectory_coverage80'])}
    return out


def physical_artifact_checks(root):
    report=json.loads((root/'results/physics_results.json').read_text())
    frozen=json.loads((root/'results/physics_freeze.json').read_text())
    checks={'frozen_files':{name:sha256(root/name)==digest for name,digest in frozen['files_sha256'].items()},
            'freeze_identity':sha256(root/'results/physics_freeze.json')==report['freeze_sha256']}
    for name,row in report['checks'].items():
        checks[name+'_raw_hash']=sha256(root/row['raw_artifact'])==row['raw_sha256']
    def load(name): return np.load(root/f'results/physics_{name}_raw.npz',allow_pickle=False)
    a=load('oscillator')
    for idx,h in enumerate((.1,.05,.025)):
        cand=a[f'h_{h}_candidate']; ref=a[f'h_{h}_reference']
        checks[f'oscillator_endpoint_{h}']=close(np.sqrt(np.sum((cand[-1]-ref[-1])**2)),report['checks']['oscillator']['endpoint_errors'][idx])
        checks[f'oscillator_energy_{h}']=close(np.max(abs(np.sum(cand*cand,axis=1)-1)),report['checks']['oscillator']['max_relative_energy_errors'][idx])
    a=load('ou')
    vals=np.sqrt(np.sum((a['candidate_final_moments']-a['exact_final_moments'])**2,axis=1))
    checks['ou_moment_errors']=bool(np.allclose(vals,report['checks']['ou']['moment_errors'],rtol=1e-12))
    a=load('newton');z=a['orbit']
    energy=.5*np.sum(z[:,2:]**2,axis=1)-1/np.sqrt(np.sum(z[:,:2]**2,axis=1))
    angular=z[:,0]*z[:,3]-z[:,1]*z[:,2]
    checks['newton_energy_array']=bool(np.allclose(energy,a['energy'],rtol=1e-12,atol=1e-13))
    checks['newton_angular_array']=bool(np.array_equal(angular,a['angular_momentum']))
    checks['newton_energy_metric']=close(np.max(abs((energy-energy[0])/energy[0])),report['checks']['newton']['orbit_energy_relative_residual'])
    a=load('jump_thermodynamics');r=report['checks']['jump_thermodynamics']
    checks['jump_IFT']=close(np.sum(a['p_forward']*np.exp(-a['sigma'])),r['integral_fluctuation_expectation'])
    checks['jump_mean_EP']=close(np.sum(a['p_forward']*a['sigma']),r['mean_total_entropy_production'])
    checks['jump_path_logratio']=bool(np.allclose(np.log(a['p_forward']/a['p_reverse']),a['sigma'],rtol=1e-12,atol=1e-12))
    checks['jump_decomposition']=close(np.max(abs(a['sigma']-a['sigma_system_plus_bath'])),r['entropy_decomposition_residual'])
    a=load('local_cone');n=a['candidate'].shape[0]
    outside=max(float(np.max(np.abs(a['candidate'][t,a['graph_distance']>t]),initial=0)) for t in range(n))
    checks['local_outside_cone']=close(outside,report['checks']['local_cone']['outside_cone_max'])
    a=load('quantum_channels');r=report['checks']['quantum_channels'];rho=a['candidate_rho']
    vals={'trace_residual':abs(np.trace(rho)-1),'analytic_residual':np.max(abs(rho-a['analytic_rho'])),
          'kraus_residual':np.max(abs(rho-a['kraus_rho'])),'density_min_eigenvalue':np.linalg.eigvalsh(rho).min(),
          'choi_min_eigenvalue':np.linalg.eigvalsh(a['choi']).min()}
    checks['quantum_saved_residuals']={k:close(v,r[k]) for k,v in vals.items()}
    a=load('memory_witness')
    ds=[]
    for t in range(3):
        diff=a['reduced_histories'][0,t]-a['reduced_histories'][1,t]
        ds.append(float(np.sum(np.abs(np.linalg.eigvalsh(diff)))/2))
    checks['memory_trace_distances']=bool(np.allclose(ds,[1,0,1],rtol=1e-12,atol=1e-12) and np.allclose(ds,a['trace_distances']))
    a=load('unitality_obstruction');diff=a['reference_amplitude_damped']-a['F0_unital_prediction']
    td=float(np.sum(np.abs(np.linalg.eigvalsh(diff)))/2)
    checks['unitality_obstruction_trace_distance']=close(td,report['checks']['unitality_obstruction']['trace_distance_F0_from_reference'])
    return checks


def control_artifact_checks(root):
    frozen=json.loads((root/'configs/control_checks_freeze.json').read_text())
    summary=json.loads((root/'results/controls/summary.json').read_text())
    a=np.load(root/'results/controls/control_arrays.npz',allow_pickle=False)
    checks={'frozen_files':{name:sha256(root/name)==digest for name,digest in frozen['sha256'].items()},
            'freeze_matches_saved_summary':frozen==summary['freeze']}
    for mode in ('passive','reactive','adaptive'):
        z=a['resource_'+mode];budget=a['resource_'+mode+'_budget'];r=summary['resource'][mode]
        vals={'minimum_resource':z[:,0].min(),'mean_absolute_target_error':abs(z[:,0]-1).mean(),
              'viability_proxy_fraction':np.mean(z[:,0]>.25),'total_action_cost':budget[:,2].sum(),
              'max_budget_residual':np.max(abs(np.diff(z[:,0])-(budget[:,0]-budget[:,1]-budget[:,2]+budget[:,3])))}
        checks[mode]={k:close(v,r[k]) for k,v in vals.items()}
    comm=a['communication_source_decoded_wrong_target_corrected'];s0,decoded,wrong,target,correct=comm.T
    checks['transmission_accuracy']=close(np.mean(s0==decoded),summary['communication']['transmission_accuracy'])
    checks['changed_goal_wrong']=close(np.mean(wrong==target),summary['communication']['goal_flipped_old_policy_accuracy'])
    checks['changed_goal_correct']=close(np.mean(correct==target),summary['communication']['goal_flipped_correct_policy_accuracy'])
    for mode in ('correct','wrong','constant'):
        rep=a['observation_'+mode];truth=a['observation_truth']
        distance=((rep[:,None,:]-truth[None,:,:])**2).sum(axis=2)
        accuracy=np.mean(np.argmin(distance,axis=1)==np.arange(len(truth)))
        checks['observation_'+mode]=close(accuracy,summary['observation'][mode]['discrimination_accuracy'])
    for name,key in [('input','input'),('reversible','reversible'),('erased','erased'),('erased_with_provenance','provenance')]:
        count=len(set(tuple(row) for row in a['register_'+key]))
        checks['register_'+name]=count==summary['computation']['distinct_state_counts'][name]
    return checks


def all_bool_checks_pass(obj):
    if isinstance(obj, bool): return obj
    if isinstance(obj, dict):
        return all(all_bool_checks_pass(v) for k,v in obj.items() if k not in ('metric_failures',)) and not obj.get('metric_failures', [])
    if isinstance(obj, list): return all(all_bool_checks_pass(v) for v in obj)
    return True


def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--root',type=Path,default=ROOT)
    parser.add_argument('--scope',choices=['generator','physics','all'],default='all')
    args=parser.parse_args(); root=args.root.resolve()
    report={'method':'Independent arithmetic recomputation; no candidate fitting or locked rerun; not blinded',
            'generator_revision':generator_revision_checks(root)}
    if args.scope in ('physics','all'):
        report['physics']=physical_artifact_checks(root)
        report['controls']=control_artifact_checks(root)
    if args.scope == 'all':
        report['predictions'], rows, recomputed = prediction_checks(root)
        report['provenance']=provenance_checks(root)
        report['hypothesis_summaries']=hypothesis_checks(root,recomputed)
    report['all_checked_booleans_pass']=all_bool_checks_pass(report)
    out=root/'results/independent'; out.mkdir(parents=True,exist_ok=True)
    (out/f'verification_{args.scope}.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    if args.scope=='all' and rows:
        with (out/'stratified_recomputed_metrics.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print(json.dumps(report,indent=2,allow_nan=False))
    return 0 if report['all_checked_booleans_pass'] else 1

if __name__=='__main__':
    raise SystemExit(main())
