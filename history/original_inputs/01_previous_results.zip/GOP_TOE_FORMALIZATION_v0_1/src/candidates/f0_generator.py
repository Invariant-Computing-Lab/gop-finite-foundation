"""Explicit F0-G classical/quantum instrument composition.

This is separate from the learned F0-P observed transition benchmark.
Array coefficients define dynamics; names are not placeholders for unknown f.
No global energy closure is claimed for the prescribed apparatus example.
"""
from __future__ import annotations
import argparse
import csv
from dataclasses import dataclass
import json
from pathlib import Path
import numpy as np
from scipy.linalg import expm
from scipy.integrate import solve_ivp

I = np.eye(2, dtype=complex)
X = np.array([[0, 1], [1, 0]], complex)
Y = np.array([[0, -1j], [1j, 0]], complex)
Z = np.diag([1., -1.]).astype(complex)


@dataclass
class PolynomialGenerator:
    c: np.ndarray
    A: np.ndarray
    B: np.ndarray
    E: np.ndarray
    Sigma: np.ndarray

    def drift(self, z, u):
        return self.c + self.A @ z + np.einsum('ijk,j,k->i', self.B, z, z) + self.E @ u

    def euler_maruyama(self, z, u, h, rng):
        return z + h*self.drift(z, u) + np.sqrt(h)*self.Sigma @ rng.normal(size=self.Sigma.shape[1])

    def arrays(self):
        return {key: getattr(self, key).tolist() for key in ('c', 'A', 'B', 'E', 'Sigma')}


def example_generator():
    # z=(q,p,m,b); m and b are updated by the explicit instrument maps.
    A = np.zeros((4, 4)); A[0, 1] = 1; A[1, 0] = -1; A[1, 1] = -.1
    E = np.zeros((4, 1)); E[1, 0] = 1
    return PolynomialGenerator(np.zeros(4), A, np.zeros((4, 4, 4)), E, np.zeros((4, 1)))


def gksl_superoperator(H, jumps, rates):
    d = H.shape[0]
    ident = np.eye(d)
    out = -1j*(np.kron(ident, H)-np.kron(H.T, ident))  # hbar=1, column vectorization
    for L, rate in zip(jumps, rates):
        if rate < 0:
            raise ValueError('GKSL rates must be nonnegative')
        LL = L.conj().T @ L
        out += rate*(np.kron(L.conj(), L)-.5*np.kron(ident, LL)-.5*np.kron(LL.T, ident))
    return out


def quantum_evolve(rho, H, h, gamma=.12):
    superop = expm(h*gksl_superoperator(H, [Z], [gamma]))
    evolved = (superop @ rho.reshape(-1, order='F')).reshape(rho.shape, order='F')
    return evolved, superop


def measurement_branches(rho, P=Z, eta=.4):
    if not -1 <= eta <= 1:
        raise ValueError('measurement strength outside CP interval')
    branches = []
    for sign in (1., -1.):
        val, vec = np.linalg.eigh((I+sign*eta*P)/2)
        M = (vec*np.sqrt(val)) @ vec.conj().T
        branch = M @ rho @ M.conj().T
        branches.append((sign, branch, float(np.trace(branch).real)))
    return branches


def choi(superop, d=2):
    out = np.zeros((d*d, d*d), complex)
    for i in range(d):
        for j in range(d):
            E = np.zeros((d,d), complex); E[i,j] = 1
            PhiE = (superop @ E.reshape(-1, order='F')).reshape((d,d), order='F')
            out[i*d:(i+1)*d, j*d:(j+1)*d] = PhiE
    return out


def loop_step(z, rho, generator, rng, h=.05, hybrid=False):
    q, p, m, buffer = z
    y = q
    measured = z.copy()
    measured[1] = p + .02*y  # actual classical backaction
    quantum_y, branch_sum = 0., 1.
    if hybrid:
        branches = measurement_branches(rho)
        probs = np.array([branch[2] for branch in branches])
        if np.min(probs) < -1e-12:
            raise ArithmeticError('negative quantum outcome probability')
        branch_sum = probs.sum()
        branch = branches[int(rng.choice(2, p=probs/branch_sum))]
        quantum_y, unnormalized, probability = branch
        if probability <= 0:
            raise ArithmeticError('sampled impossible branch')
        rho = unnormalized/probability
    memory = .8*m+.2*(y+buffer)+(.05*quantum_y if hybrid else 0.)
    action, signal = -.4*memory, .5*memory
    measured[2], measured[3] = memory, .9*signal
    next_z = generator.euler_maruyama(measured, np.array([action]), h, rng)
    if hybrid:
        # Classical outcome/control changes the quantum Hamiltonian.
        rho, _ = quantum_evolve(rho, .5*X+.1*q*Z+.1*action*X, h)
    return next_z, rho, {'sensor_y': y, 'quantum_y': quantum_y, 'action': action,
                         'signal': signal, 'old_buffer': buffer, 'branch_probability_sum': branch_sum}


def run(output: Path, seed=61302, steps=256):
    output.mkdir(parents=True, exist_ok=True)
    generator = example_generator()
    z0 = np.array([1., 0., 0., 0.])
    rho0 = np.array([[1., 0.], [0., 0.]], complex)
    first, _, first_record = loop_step(z0, rho0, generator, np.random.default_rng(seed))
    target = np.array([1.001, -.0341, .2, .09])
    rng = np.random.default_rng(seed)
    z, rho = z0.copy(), rho0.copy()
    rows, min_eig, max_trace_error, max_prob_error = [], 1., 0., 0.
    for step in range(steps):
        z, rho, rec = loop_step(z, rho, generator, rng, hybrid=True)
        min_eig = min(min_eig, np.linalg.eigvalsh(rho).min().real)
        max_trace_error = max(max_trace_error, abs(np.trace(rho)-1))
        max_prob_error = max(max_prob_error, abs(rec['branch_probability_sum']-1))
        rows.append({'step': step+1, 'time': .05*(step+1), 'q': z[0], 'p': z[1],
                     'm': z[2], 'buffer': z[3], 'rho00': rho[0,0].real,
                     'rho01_real': rho[0,1].real, 'rho01_imag': rho[0,1].imag, **rec})
    with (output/'f0_generator_trajectory.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    # Independent analytic dephasing and CP checks, without a stochastic loop.
    plus = np.full((2,2), .5, complex)
    omega, gamma, t = .7, .12, .4
    actual, superop = quantum_evolve(plus, .5*omega*Z, t, gamma)
    expected = plus.copy(); expected[0,1] *= np.exp((-1j*omega-2*gamma)*t); expected[1,0] = expected[0,1].conjugate()
    C = choi(superop)
    # Independent deterministic solver isolates integrator error from law failure.
    exact = solve_ivp(lambda t,x: -x+.2*x*x, [0,1], [.7], rtol=1e-12, atol=1e-14).y[0,-1]
    errors = []
    for h in (.1, .05, .025):
        x = .7
        for _ in range(round(1/h)):
            x += h*(-x+.2*x*x)
        errors.append({'h': h, 'endpoint_error': abs(x-exact)})
    result = {'scientific_version': 'F0-G', 'seed': seed, 'steps': steps, 'h': .05,
              'state_dimension': 4, 'subsystem_blocks': 1, 'quantum_dimension': 2,
              'apparatus_energy_closure': 'NOT_ESTABLISHED_prescribed_maps',
              'coefficient_file': 'f0_generator_coefficients.json', 'first_classical_step': first.tolist(),
              'first_classical_step_target': target.tolist(), 'first_step_max_error': float(np.max(abs(first-target))),
              'hybrid_min_density_eigenvalue': float(min_eig), 'hybrid_max_trace_error': float(max_trace_error),
              'max_instrument_probability_sum_error': float(max_prob_error),
              'dephasing_max_analytic_error': float(np.max(abs(actual-expected))),
              'channel_min_choi_eigenvalue': float(np.linalg.eigvalsh(C).min().real),
              'euler_convergence': errors,
              'notes': 'Conditioned hybrid trajectories with quantum-to-classical outcome feedback and classical-to-quantum Hamiltonian control; no universal physics or autonomous agency conclusion.'}
    result['software_checks_passed'] = bool(result['first_step_max_error'] < 1e-12
        and min_eig > -1e-10 and max_trace_error < 1e-10 and max_prob_error < 1e-10
        and result['dephasing_max_analytic_error'] < 1e-12 and result['channel_min_choi_eigenvalue'] > -1e-10
        and errors[2]['endpoint_error'] < errors[1]['endpoint_error'] < errors[0]['endpoint_error'])
    coefficients = {'classical_generator': generator.arrays(),
                    'classical_sensor': {'H': [[1.,0.,0.,0.]], 'variance': 0., 'backaction_p_from_y': .02},
                    'internal_update': {'m': .8, 'sensor': .2, 'old_buffer': .2, 'quantum_outcome': .05},
                    'actuation': {'m_to_action': -.4, 'm_to_signal': .5}, 'channel': {'F': 0., 'K': .9},
                    'quantum': {'H': '.5 X + .1 q Z + .1 action X', 'jump': 'Z', 'rate': .12,
                                'measurement': 'unsharp Z', 'strength': .4, 'hbar': 1.}}
    (output/'f0_generator_coefficients.json').write_text(json.dumps(coefficients, indent=2)+'\n')
    (output/'f0_generator_checks.json').write_text(json.dumps(result, indent=2)+'\n')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--output', type=Path, default=Path('results'))
    args = parser.parse_args(); result = run(args.output)
    print(json.dumps({key: result[key] for key in ('scientific_version','steps','software_checks_passed','first_classical_step')}))
