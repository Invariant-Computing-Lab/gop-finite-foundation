#!/usr/bin/env python3
"""Reproducible finite F0-P surrogate study; use smoke, develop, then locked once.
The independent physical F0-G candidate is NOT identified with this predictor.
"""
from __future__ import annotations
import os
for _key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_key]='1'
import argparse, csv, hashlib, json, pickle, platform, shutil, sys, time, warnings
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
from candidates.quadratic import BasisRegressor
from baselines.models import SmallMLP,MeanNull
from scoring.metrics import normalized_mse,paired_interval,conformal_quantile

ROOT=Path(__file__).resolve().parents[1]
FAMILIES=[f'S{i:02d}' for i in range(1,11)]
IDS={'train':list(range(24)),'development':list(range(100,108)),
     'calibration':list(range(200,208)),'locked':list(range(300,316))}
SEEDS=[0,1,2]
MODELS=['F0_P','linear','sparse_cubic','MLP','persistence','constant','no_memory','no_context']
PROTOCOL={
 'study':'GOP-TOE finite surrogate tests','version':'F0-P-1','steps':128,'nested_seeds':SEEDS,
 'worlds':IDS,'finite_scope':'Pooled across worlds WITHIN each family; same dictionary rule, distinct coefficients per family',
 'candidate':'ridge regression on all quadratic products of calibrated y_t,y_(t-1),u_t,public context',
 'physical_relation':'Observation-space surrogate; not an estimator or falsification test of F0-G continuous generator',
 'preprocessing':'Training-only means/std; shared train-output scale for loss. No latent truth as input',
 'primary':'World mean one-step CAPPED normalized MSE, average over fixed nested seeds and times/coordinates',
 'secondary_horizon':16,'horizon_origins':'1,17,33,... with final target <= steps',
 'hyperparameters':{'F0_P':[.0001,.1,10.],'linear':[.0001,.1,10.],
    'sparse_cubic_threshold':[.005,.02,.05],'MLP_alpha':[.0001,.01,1.]},
 'MLP':'32 tanh hidden units; Adam lr=.005; max_iter70; train-only early stop10% validation; batch256; seed811',
 'sparse_cubic':'STLSQ: complete degree<=2 plus coordinate cubes only; ridge .01;4 threshold/refit rounds',
 'comparator_selection':'Lowest development mean MSE among persistence, linear, sparse_cubic, MLP; fixed per family',
 'CI':'20,000 stratified world bootstrap draws preserving fixed test-type mixture; percentile99.5%; Bonferroni10 primary families; approximate/descriptive inference at n16, not exact familywise guarantee',
 'margin':.01,'margin_justification':'Fixed engineering tolerance in train-standardized squared error; no claim physical meaningfulness',
 'decision':'upper difference CI < -.01: COMPARATIVE_SUPPORT; lower >+.01: F0-P comparative criterion FALSIFIED_IN_REGIME; otherwise INCONCLUSIVE',
 'conformal':'80% split conformal, score per calibration world=max standardized one-step residual over three seeds,times,coordinates; n8 rank8',
 'coverage_scope':'Finite-sample marginal guarantee only for exchangeable worlds; shifted tests report empirical coverage only',
 'residual_cap':1e6,'cap_reason':'Numerical divergence receives capped squared error1e12 and explicit divergence indicator',
 'ablations':'no_memory,no_context,constant; physics/locality/normative/K11 ablations not applicable to this observation surrogate',
 'locality':'Dense observation-space couplings; no supplied graph justifies a local observation mask; no locality claim',
 'heldout_access':'Procedural separation only; agents share filesystem; no investigator or cryptographic blinding',
 'numerical_workers':1,'wall_budget_seconds':300,'eval_budget':'16 worlds per family fixed before test; no outcome-dependent expansion',
 'missingness':'Predicted targets are causally imputed observation records, NOT latent states. Generator preserves masks, but this predictor has no mask input; missingness-aware inference NOT_RUN. Shared limitation for all comparators',
 'parameter_count':'Reported parameters count regression/network coefficients and biases only; checkpoint includes all learned preprocessing statistics and full stored scalar count separately',
 'not_run_comparators':'Kalman, Hamiltonian learned architecture and quantum learned channels not fitted; separately verified physical oracle tracks do not compete as equal-information learners',
 'revision_policy':'No post-locked refit/revision. Formal proposed F1 requires new prospectively frozen data.'}

def now():return datetime.now(timezone.utc).isoformat()
def jdefault(x):
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    return str(x)
def write_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,default=jdefault)+'\n')
def append_json(path,value):
    with Path(path).open('a') as f:f.write(json.dumps(value,default=jdefault)+'\n')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def log(event,**kw):
    append_json(ROOT/'logs/pipeline.jsonl',dict(timestamp=now(),event=event,**kw))
    print(json.dumps(dict(event=event,**kw),default=jdefault),flush=True)
def generate(family,wid,split,seed,steps):
    if family=='S09':
        from reference_worlds.quantum import generate_quantum
        return generate_quantum(wid,split,seed,steps=steps)
    from reference_worlds.generators import generate
    return generate(family,wid,split,seed,steps=steps)
def fetch(family,split,steps=128,smoke=False):
    ids=IDS[split] if not smoke else IDS[split][:2]
    seeds=SEEDS if not smoke else SEEDS[:2]
    out=[]
    for wid in ids:
        reps=[]
        for seed in seeds:
            g=generate(family,wid,split,seed,steps)
            y=np.asarray(g['y'],float);u=np.asarray(g['u'],float);ctx=np.asarray(g['context'],float).reshape(-1)
            if y.ndim==1:y=y[:,None]
            if u.ndim==1:u=u[:,None]
            assert y.shape[0]==steps+1 and u.shape[0]==steps,(family,y.shape,u.shape)
            assert all(np.isfinite(v).all() for v in (y,u,ctx)),f'Nonfinite input {family}'
            meta=g.get('meta',{})
            reps.append({'y':y,'u':u,'context':ctx,'meta':meta,'world_id':wid,'seed':seed})
            if not smoke:
                append_json(ROOT/'data/manifests/worlds.jsonl',{
                    'family':family,'split':split,'world_id':wid,'seed':seed,'steps':steps,
                    'y_shape':y.shape,'u_shape':u.shape,'context':ctx,'meta':meta,
                    'observed_content_sha256':hashlib.sha256(y.tobytes()+u.tobytes()+ctx.tobytes()).hexdigest()})
        out.append(reps)
    return out

def feature(y,prev,u,ctx,kind='full'):
    blocks=[y]
    if kind!='no_memory':blocks.append(prev)
    blocks.append(u)
    if kind!='no_context' and ctx.shape[-1]:blocks.append(ctx)
    return np.column_stack(blocks)
def flatten(worlds,kind='full'):
    xs=[];ys=[]
    for reps in worlds:
        for r in reps:
            y=r['y'];n=len(y)-2
            xs.append(feature(y[1:-1],y[:-2],r['u'][1:],np.broadcast_to(r['context'],(n,len(r['context']))),kind))
            ys.append(y[2:])
    return np.concatenate(xs),np.concatenate(ys)
def predict1(worlds,model,kind='full'):
    ys=np.array([[r['y'] for r in reps] for reps in worlds])
    if model=='persistence':return ys[:,:,1:-1]
    X,Y=flatten(worlds,kind)
    p=model.predict(X)
    return p.reshape(len(worlds),len(worlds[0]),ys.shape[2]-2,ys.shape[3])
def truth1(worlds):return np.array([[r['y'][2:] for r in reps] for reps in worlds])
def kindof(name):return name if name in ('no_memory','no_context') else 'full'
def loss_worlds(truth,pred,scale):return [normalized_mse(t,p,scale) for t,p in zip(truth,pred)]
def rollout(worlds,model,kind='full',H=16,scale=None):
    T=len(worlds[0][0]['y'])-1;origins=list(range(1,T-H+1,H));current=[];prev=[];controls=[];contexts=[];target=[]
    for reps in worlds:
        for r in reps:
            for t in origins:
                current.append(r['y'][t]);prev.append(r['y'][t-1]);controls.append(r['u'][t:t+H]);contexts.append(r['context']);target.append(r['y'][t+H])
    current=np.array(current);prev=np.array(prev);controls=np.array(controls);contexts=np.array(contexts)
    scale_guard=np.maximum(np.asarray(scale) if scale is not None else np.ones(current.shape[1]),1.)
    bad=np.zeros(len(current),bool)
    for h in range(H):
        if model=='persistence':nxt=current.copy()
        else:
            with np.errstate(over='ignore',invalid='ignore'):
                nxt=model.predict(feature(current,prev,controls[:,h],contexts,kind))
        bad|=(~np.isfinite(nxt).all(1))|(np.max(np.abs(nxt/scale_guard),axis=1)>1e6)
        nxt[bad]=1e12 # explicit divergence sink, later bounded loss with indicator
        prev,current=current,nxt
    shape=(len(worlds),len(worlds[0]),len(origins),current.shape[1])
    return np.array(target).reshape(shape),current.reshape(shape),bad.reshape(shape[:-1]).any((1,2))

def smoke():
    started=time.monotonic();report=[]
    if not (ROOT/'theory/UNIVERSALITY_CONJECTURE.md').exists():
        raise RuntimeError('Write universality and assumptions before fitting')
    for fam in FAMILIES:
        t=time.monotonic();w=fetch(fam,'train',steps=32,smoke=True);x,y=flatten(w)
        m=BasisRegressor(2,.1).fit(x,y);p=m.predict(x)
        assert p.shape==y.shape and np.isfinite(p).all()
        report.append({'family':fam,'worlds':2,'nested_seeds':2,'steps':32,'input_dim':x.shape[1],
          'output_dim':y.shape[1],'basis_features':m.n_features,'seconds':time.monotonic()-t,'in_sample_mse':float(np.mean((p-y)**2))})
    write_json(ROOT/'results/smoke_profile.json',{'started_at':now(),'seconds':time.monotonic()-started,'rows':report,
      'interpretation':'Software/profiling only; not held-out evidence'})
    log('smoke_completed',seconds=time.monotonic()-started,rows=report)

def develop():
    if (ROOT/'versions/F0/EMPIRICAL_FREEZE.json').exists():raise RuntimeError('F0 already frozen; do not silently refit')
    if not (ROOT/'theory/UNIVERSALITY_CONJECTURE.md').exists():raise RuntimeError('Theory required before fitting')
    if not (ROOT/'theory/ASSUMPTION_LEDGER.csv').exists():raise RuntimeError('Assumptions required before fitting')
    write_json(ROOT/'configs/frozen_empirical_protocol.json',PROTOCOL)
    started=time.monotonic();timings=[]
    manifest=ROOT/'data/manifests/worlds.jsonl'
    if manifest.exists():raise RuntimeError('Manifest exists; resume explicitly without duplicating fits')
    for fam in FAMILIES:
        t=time.monotonic();train=fetch(fam,'train');dev=fetch(fam,'development');cal=fetch(fam,'calibration')
        X,Y=flatten(train);scale=np.maximum(Y.std(0),1e-8);dt=truth1(dev);ct=truth1(cal)
        selected={};tuning=[]
        grids={'F0_P':[.0001,.1,10.],'linear':[.0001,.1,10.],
            'sparse_cubic':[.005,.02,.05],'MLP':[.0001,.01,1.]}
        for name,values in grids.items():
            best=None
            for val in values:
                if name=='MLP':m=SmallMLP(alpha=val)
                elif name=='sparse_cubic':m=BasisRegressor(3,.01,threshold=val)
                else:m=BasisRegressor(2 if name=='F0_P' else 1,val)
                tt=time.monotonic()
                with warnings.catch_warnings(record=True) as ws:
                    warnings.simplefilter('always');m.fit(X,Y)
                p=predict1(dev,m);loss=float(np.mean(loss_worlds(dt,p,scale)))
                row={'model':name,'setting':val,'development_mse':loss,'fit_seconds':time.monotonic()-tt,
                    'parameters':m.n_parameters,'nonzero':m.n_nonzero,'features':m.n_features,
                    'stored_numeric_scalars':sum(v.size for v in vars(m).values() if isinstance(v,np.ndarray))+ (m.n_parameters if name=='MLP' else 0),
                    'n_iter':getattr(m,'n_iter',None),'warnings':[str(q.message) for q in ws]}
                tuning.append(row)
                if best is None or loss<best[0]:best=(loss,m,val)
            selected[name]=best[1]
        selected['persistence']='persistence';selected['constant']=MeanNull().fit(X,Y)
        bestalpha=min((r for r in tuning if r['model']=='F0_P'),key=lambda r:r['development_mse'])['setting']
        for name in ('no_memory','no_context'):
            ax,ay=flatten(train,name);selected[name]=BasisRegressor(2,bestalpha).fit(ax,ay)
        dev_losses={n:float(np.mean(loss_worlds(dt,predict1(dev,m,kindof(n)),scale))) for n,m in selected.items()}
        comparator=min(('persistence','linear','sparse_cubic','MLP'),key=lambda n:dev_losses[n])
        cp=predict1(cal,selected['F0_P']);cs=np.max(np.abs((cp-ct)/scale),axis=(1,2,3));q=conformal_quantile(cs)
        bundle={'family':fam,'models':selected,'scale':scale,'tuning':tuning,'development_mse':dev_losses,
                'comparator':comparator,'conformal_q':q,'calibration_scores':cs,'input_dim':X.shape[1],
                'output_dim':Y.shape[1],'train_rows':len(Y),'fit_completed_at':now(),'seconds':time.monotonic()-t}
        with (ROOT/f'models/{fam}.pkl').open('wb') as f:pickle.dump(bundle,f,protocol=5)
        timings.append({k:v for k,v in bundle.items() if k not in ('models','scale')})
        write_json(ROOT/'results/development_results.json',timings)
        log('family_fit_completed',family=fam,seconds=bundle['seconds'],comparator=comparator,dev_mse=dev_losses,
            conformal_q=q,elapsed=time.monotonic()-started)
        if time.monotonic()-started>PROTOCOL['wall_budget_seconds']:raise RuntimeError('Numerical wall budget reached; preserve models and do not start locked')
    snapshots=ROOT/'versions/F0/empirical_theory_snapshots';snapshots.mkdir(exist_ok=True)
    for name in ('UNIVERSALITY_CONJECTURE.md','ASSUMPTION_LEDGER.csv'):
        shutil.copy2(ROOT/'theory'/name,snapshots/name)
    paths=[ROOT/'src/run_pipeline.py',ROOT/'configs/frozen_empirical_protocol.json']
    for folder in ('src/candidates','src/baselines','src/scoring','src/reference_worlds'):
        paths.extend((ROOT/folder).glob('*.py'))
    paths.extend((ROOT/'models').glob('*.pkl'));paths.extend(snapshots.iterdir());paths=sorted(paths)
    freeze={'frozen_at':now(),'fit_seconds':time.monotonic()-started,'files':{str(p.relative_to(ROOT)):sha(p) for p in paths},
            'chosen_comparators':{x['family']:x['comparator'] for x in timings},'protocol':PROTOCOL,
            'locked_generated':False,'scope':'Finite observation surrogate only; shared structural recipe, family-specific fitted coefficients'}
    write_json(ROOT/'versions/F0/EMPIRICAL_FREEZE.json',freeze)
    log('development_frozen',seconds=time.monotonic()-started)

def locked():
    freeze=json.loads((ROOT/'versions/F0/EMPIRICAL_FREEZE.json').read_text())
    if (ROOT/'versions/F0/LOCKED_OPEN.json').exists():raise RuntimeError('Locked data already opened; no confirmation restart permitted')
    for p,h in freeze['files'].items():
        assert sha(ROOT/p)==h,f'Frozen artifact changed {p}'
    write_json(ROOT/'versions/F0/LOCKED_OPEN.json',{'opened_at':now(),'freeze_sha256':sha(ROOT/'versions/F0/EMPIRICAL_FREEZE.json'),
        'separation':'No prior locked generation in this pipeline; procedural, no blinding'})
    started=time.monotonic();summaries=[];ablation=[]
    for fam in FAMILIES:
        t=time.monotonic()
        with (ROOT/f'models/{fam}.pkl').open('rb') as f:b=pickle.load(f)
        worlds=fetch(fam,'locked');true=truth1(worlds);scale=b['scale']
        types=[str(w[0]['meta'].get('test_type',w[0]['meta'].get('condition','known_mechanism' if fam=='S09' else 'unspecified'))) for w in worlds]
        archive={'truth1':true,'scale':scale,'world_ids':np.array(IDS['locked']),'seeds':np.array(SEEDS),
            'test_types':np.array(types),'conformal_q':np.array(b['conformal_q'])}
        for name,m in b['models'].items():
            archive[f'pred1__{name}']=predict1(worlds,m,kindof(name))
            truth16,p16,bad=rollout(worlds,m,kindof(name),scale=scale)
            archive['truth16']=truth16;archive[f'pred16__{name}']=p16;archive[f'diverged16__{name}']=bad
        # Predictions and targets are saved BEFORE calculating locked losses.
        pp=ROOT/f'predictions/{fam}_locked.npz';np.savez_compressed(pp,**archive)
        log('predictions_saved_before_scoring',family=fam,path=str(pp.relative_to(ROOT)),sha256=sha(pp))
        losses={};worldrows=[]
        for name in b['models']:
            l1=loss_worlds(true,archive[f'pred1__{name}'],scale)
            l16=loss_worlds(truth16,archive[f'pred16__{name}'],scale);losses[name]=l1
            for i,wid in enumerate(IDS['locked']):
                error=np.abs((archive[f'pred1__{name}'][i]-true[i])/scale)
                row={'family':fam,'world_id':wid,'model':name,'test_type':types[i],
                    'mse1':l1[i],'mse16':l16[i],'coverage80':bool(np.max(error)<=b['conformal_q']) if name=='F0_P' else None,
                    'pointwise_coverage80':float(np.mean(error<=b['conformal_q'])) if name=='F0_P' else None,
                    'interval_width_mean':float(np.mean(2*b['conformal_q']*scale)) if name=='F0_P' else None,
                    'diverged16':bool(archive[f'diverged16__{name}'][i]),
                    'nonfinite1':int((~np.isfinite(archive[f'pred1__{name}'][i])).sum()),
                    'nonfinite16':int((~np.isfinite(archive[f'pred16__{name}'][i])).sum()),
                    'capped_residuals1':int((error>1e6).sum()),
                    'capped_residuals16':int((np.abs((archive[f'pred16__{name}'][i]-truth16[i])/scale)>1e6).sum()),
                    'prediction_file':str(pp.relative_to(ROOT)),
                    'prediction_sha256':sha(pp),'version':'F0-P-1'}
                append_json(ROOT/'results/raw_metrics.jsonl',row);worldrows.append(row)
            ablation.append({'family':fam,'model':name,'mean_mse1':float(np.mean(l1)),
                'mean_mse16':float(np.mean(l16)),'development_mse1':b['development_mse'][name],
                'parameters':getattr(b['models'][name],'n_parameters',0),
                'divergent_worlds16':int(archive[f'diverged16__{name}'].sum())})
        comp=b['comparator'];delta=np.array(losses['F0_P'])-losses[comp]
        mean,lo,hi=paired_interval(delta,strata=types)
        if hi < -.01:status='COMPARATIVE_SUPPORT'
        elif lo > .01:status='FALSIFIED_IN_REGIME'
        else:status='INCONCLUSIVE'
        crows=[r for r in worldrows if r['model']=='F0_P']
        row={'family':fam,'hypothesis':'F0-P comparative adequacy: support advantage >.01 or reject deficit >.01 vs frozen comparator',
            'comparator':comp,'candidate_mse1':float(np.mean(losses['F0_P'])),
            'comparator_mse1':float(np.mean(losses[comp])),'difference':mean,'ci_low99_5':lo,'ci_high99_5':hi,
            'margin':.01,'status':status,'physical_generator_implication':'NONE from prediction score alone',
            'worlds':len(worlds),'trajectory_coverage80':float(np.mean([r['coverage80'] for r in crows])),
            'interval_width_mean':crows[0]['interval_width_mean'],'conformal_q':b['conformal_q'],
            'candidate_divergent_worlds16':int(archive['diverged16__F0_P'].sum())}
        summaries.append(row);log('family_locked_scored',**row,seconds=time.monotonic()-t)
        for path,rows in [('results/hypothesis_status.csv',summaries),('results/transfer_and_ablation_tables.csv',ablation)]:
            with (ROOT/path).open('w',newline='') as f:
                writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    write_json(ROOT/'results/empirical_run_summary.json',{'completed_at':now(),'locked_seconds':time.monotonic()-started,
      'development_seconds':freeze['fit_seconds'],'profile':PROTOCOL,'families':summaries,
      'status':'SOFTWARE_EXECUTED_PENDING_INDEPENDENT_AUDIT','files':'predictions/*_locked.npz;models/*.pkl;raw_metrics.jsonl',
      'numerical_seconds_combined':freeze['fit_seconds']+time.monotonic()-started})
    log('locked_completed',seconds=time.monotonic()-started)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('phase',choices=['smoke','develop','locked']);args=ap.parse_args()
    log('phase_start',phase=args.phase,python=sys.version,platform=platform.platform())
    try:globals()[args.phase]()
    except Exception as e:log('phase_failed',phase=args.phase,error=repr(e));raise
