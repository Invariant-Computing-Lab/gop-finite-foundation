"""Reproducible identification calculation; no fitted universal-law claim."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np


def design(k: float) -> np.ndarray:
    return np.array([[1.0, 1.0], [k, 1.0]])


def inverse(y: np.ndarray, k: float) -> np.ndarray:
    if k == 1:
        raise ValueError("k=1 is nonidentifiable")
    y = np.asarray(y)
    return np.stack(((y[..., 1] - y[..., 0]) / (k - 1),
                     (k * y[..., 0] - y[..., 1]) / (k - 1)), axis=-1)


def covariance(k: float, sigma: float) -> np.ndarray:
    if k == 1:
        raise ValueError("k=1 has no finite inverse covariance")
    return sigma**2 / (k-1)**2 * np.array([[2., -(1+k)], [-(1+k), 1+k*k]])


def run(output: Path, seed: int = 90210, draws: int = 100000) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    x = np.array([.7, -.2])
    sigma = .03
    noise = rng.normal(0, sigma, size=(draws, 2))
    cases = []
    errors = {}
    for k in (2., 1.1, 1.01, 1.001):
        y = design(k) @ x + noise
        error = inverse(y, k) - x
        expected = covariance(k, sigma)
        empirical = np.cov(error, rowvar=False, ddof=1)
        relative = np.linalg.norm(empirical-expected)/np.linalg.norm(expected)
        intervals = 1.96 * np.sqrt(np.diag(expected))
        cases.append({"k": k, "condition_number": float(np.linalg.cond(design(k))),
                      "theory_covariance": expected.tolist(),
                      "empirical_covariance": empirical.tolist(),
                      "covariance_relative_error": float(relative),
                      "component_95_coverage": (np.abs(error) <= intervals).mean(axis=0).tolist()})
        errors[str(k)] = error[:128]
    gain, scale, k_true, k_wrong = 1.7, 3.2, 2., 1.5
    gain_y = gain * design(k_true) @ x
    gauge_y = (gain/scale) * design(k_true) @ (scale*x)
    wrong = inverse(design(k_true) @ x, k_wrong)
    predicted_wrong = np.array([(k_true-1)/(k_wrong-1)*x[0],
                               x[1]+(k_wrong-k_true)/(k_wrong-1)*x[0]])
    rank_one = np.linalg.matrix_rank(design(1.))
    sat_a = np.clip(design(2.) @ np.array([1., 1.]), -1., 1.)
    sat_b = np.clip(design(2.) @ np.array([2., 2.]), -1., 1.)
    result = {"seed": seed, "draws": draws, "independent_unit": "noise replicate of one stationary two-component state",
              "not_independent_world_count": True, "latent_x": x.tolist(), "sigma": sigma,
              "noise_cases": cases, "unknown_gain_gauge_max_error": float(np.max(np.abs(gain_y-gauge_y))),
              "gain_times_state_identified": inverse(gain_y, k_true).tolist(),
              "true_gain_times_state": (gain*x).tolist(), "rank_k_equals_one": int(rank_one),
              "wrong_label_estimate": wrong.tolist(), "wrong_label_analytic": predicted_wrong.tolist(),
              "saturation_collision": {"state_a": [1,1], "state_b": [2,2],
                                       "reading_a": sat_a.tolist(), "reading_b": sat_b.tolist()},
              "symbolic_verification": "not_attempted"}
    try:
        import sympy as sp
        ks = sp.symbols('k', real=True)
        A = sp.Matrix([[1, 1], [ks, 1]])
        Ai = sp.Matrix([[-1, 1], [ks, -1]])/(ks-1)
        result["symbolic_verification"] = str(sp.simplify(Ai*A) == sp.eye(2))
    except ImportError:
        pass
    result["software_checks_passed"] = bool(all(c["covariance_relative_error"] < .03 for c in cases)
                                             and np.allclose(wrong, predicted_wrong)
                                             and np.allclose(sat_a, sat_b)
                                             and np.allclose(gain_y, gauge_y) and rank_one == 1)
    np.savez_compressed(output / 'toy_noise_errors_sample.npz', **errors)
    (output / 'toy_identification.json').write_text(json.dumps(result, indent=2)+'\n')
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=Path('results'))
    args = parser.parse_args()
    result = run(args.output)
    print(json.dumps({"software_checks_passed": result["software_checks_passed"],
                      "draws": result["draws"], "symbolic_verification": result["symbolic_verification"]}))
