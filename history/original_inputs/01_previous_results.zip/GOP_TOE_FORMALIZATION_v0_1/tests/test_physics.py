"""Independent verification of archived physical checks and interface contract.

These tests do not rerun the suite or reopen the benchmark's locked worlds.
"""
import hashlib
import json
from pathlib import Path
import sys
import unittest
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from reference_worlds.quantum import generate_quantum


class PhysicalArchiveChecks(unittest.TestCase):
    def test_frozen_hashes(self):
        freeze = json.loads((ROOT / "results/physics_freeze.json").read_text())
        for name, expected in freeze["files_sha256"].items():
            self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(), expected)

    def test_archived_numbers_and_hashes(self):
        result = json.loads((ROOT / "results/physics_results.json").read_text())
        self.assertTrue(result["all_software_checks_passed"])
        self.assertEqual(len(result["checks"]), 9)
        for check in result["checks"].values():
            self.assertTrue(check["passed"])
            raw = ROOT / check["raw_artifact"]
            self.assertEqual(hashlib.sha256(raw.read_bytes()).hexdigest(), check["raw_sha256"])

    def test_quantum_archive_independently(self):
        with np.load(ROOT/"results/physics_quantum_channels_raw.npz") as raw:
            rho, choi = raw["candidate_rho"], raw["choi"]
            self.assertAlmostEqual(float(np.trace(rho).real), 1, places=12)
            self.assertGreaterEqual(np.linalg.eigvalsh(rho).min(), -1e-12)
            self.assertGreaterEqual(np.linalg.eigvalsh(choi).min(), -1e-12)
            np.testing.assert_allclose(rho, raw["analytic_rho"], atol=1e-12)
            np.testing.assert_allclose(raw["probabilities"], [.5,.5], atol=1e-12)

    def test_entropy_archive_independently(self):
        with np.load(ROOT/"results/physics_jump_thermodynamics_raw.npz") as raw:
            pf, pr = raw["p_forward"], raw["p_reverse"]
            self.assertAlmostEqual(float(pf.sum()), 1, places=12)
            self.assertAlmostEqual(float(pr.sum()), 1, places=12)
            # Recompute the path probability ratio instead of trusting stored sigma.
            sigma = np.log(pf/pr)
            self.assertAlmostEqual(float(np.dot(pf,np.exp(-sigma))), 1, places=12)
            self.assertGreaterEqual(float(pf@sigma), -1e-12)
            np.testing.assert_allclose(sigma,raw["sigma_system_plus_bath"],atol=1e-12)

    def test_memory_and_local_archives(self):
        with np.load(ROOT/"results/physics_memory_witness_raw.npz") as raw:
            histories = raw["reduced_histories"]
            np.testing.assert_allclose(histories[0,1], histories[1,1], atol=1e-12)
            self.assertGreater(np.linalg.norm(histories[0,2]-histories[1,2]), 1)
        with np.load(ROOT/"results/physics_local_cone_raw.npz") as raw:
            for tick, state in enumerate(raw["candidate"]):
                self.assertLessEqual(np.max(abs(state[raw["graph_distance"]>tick])),1e-14)

    def test_generator_contract_noise_and_access(self):
        a = generate_quantum("interface-audit", "software", 27, 16)
        b = generate_quantum("interface-audit", "software", 28, 16)
        self.assertEqual(a["x"].shape,(17,3)); self.assertEqual(a["y"].shape,(17,3))
        self.assertEqual(a["u"].shape,(16,1)); self.assertEqual(a["context"].shape,(3,))
        np.testing.assert_array_equal(a["x"],b["x"])
        self.assertFalse(np.array_equal(a["y"],b["y"]))
        self.assertTrue(np.isfinite(a["y"]).all())
        self.assertTrue(np.max(np.linalg.norm(a["x"],axis=1))<=1+1e-12)
        self.assertIn("tomography",a["meta"]["observation"])


if __name__ == "__main__":
    unittest.main()
