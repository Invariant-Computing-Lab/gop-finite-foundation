"""Small regression checks for equations; numerical checks are not proofs."""
import importlib.util
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    sys.modules[name] = obj
    spec.loader.exec_module(obj)
    return obj


toy = module('toy_identification', ROOT/'src/toy_identification.py')
f0 = module('f0_generator', ROOT/'src/candidates/f0_generator.py')


def test_inverse_and_covariance():
    for k in (.0, .5, 1.001, 2., 5.):
        A = toy.design(k)
        x = np.array([.7,-.3])
        assert np.allclose(toy.inverse(A@x,k), x)
        inv = np.linalg.inv(A)
        assert np.allclose(toy.covariance(k,.03), .03**2*inv@inv.T)


def test_candidate_breaking_chebyshev_witness():
    x = np.array([1., .5, -.5, -1.])
    w = np.array([1., -2., 2., -1.])
    for power in (0,1,2):
        assert abs(w @ x**power) < 1e-14
    assert np.isclose(w @ x**3, 1.5)
    grid = np.linspace(-1,1,10001)
    assert np.isclose(np.max(abs(grid**3-.75*grid)), .25)


def test_explicit_loop():
    z, _, rec = f0.loop_step(np.array([1.,0.,0.,0.]), np.diag([1.,0.]).astype(complex),
                            f0.example_generator(), np.random.default_rng(1))
    assert np.allclose(z, [1.001,-.0341,.2,.09])
    assert rec['old_buffer'] == 0.


def test_quantum_instrument_is_normalized_and_backacts():
    rho = np.full((2,2), .5, complex)
    branches = f0.measurement_branches(rho, eta=1.)
    assert np.isclose(sum(branch[2] for branch in branches), 1.)
    unconditioned = sum(branch[1] for branch in branches)
    assert np.allclose(unconditioned, .5*np.eye(2))
    assert not np.allclose(unconditioned, rho)


if __name__ == '__main__':
    for test in (test_inverse_and_covariance, test_candidate_breaking_chebyshev_witness,
                 test_explicit_loop, test_quantum_instrument_is_normalized_and_backacts):
        test()
    print('4 theory checks passed')
