# Scientific revision log

Initial F0 construction is being frozen before main fitting and evaluation. Software fixes that do not change science are recorded separately in run logs. F0-G denotes the restricted continuous generator and explicit loop; F0-P denotes a discrete predictive surrogate. These cannot be treated as equivalent models.

No manuscript wording is allowed to reinterpret poor F0-P predictive performance as an F0-G counterexample without a separate argument.

## F1-G: classical polynomial degree 2 to 3

Trigger: the analytic cubic restoring-force counterexample, established during construction, exceeds the registered 0.01 uniform resolved-drift error. No ten-family locked outcome informed this change. Only the drift degree is raised; memory, coordinates and quantum maps are unchanged. Scalar added freedom: one coefficient. Contract and source hashes precede data generation and fitting in `results/generator_revision/prefit_freeze.json`; fitted coefficients are frozen again before the fresh quintic mechanism is generated.

The measured cubic drift fit repairs the example (maximum grid error 0.0004518223), but a fresh quintic mechanism exposes an irreducible degree-three class error of 0.0625. The fitted F1 drift error there is 0.1858189. These are synthetic model-class results and finite-difference identification diagnostics, not experimental tests on nature. There is no F2 fitted to rescue these results.
