"""Independent review of an uploaded result archive; source files are not modified.
No pickled estimator is loaded. New demonstrations are separated from source results.
"""
from pathlib import Path
import argparse, collections, hashlib, importlib.util, json, sys
import numpy as np
from scipy.integrate import solve_ivp

BASE = Path('/mnt/data/gop_results_review/source/GOP_TOE_FORMALIZATION_v0_1')
OUT = Path('/mnt/data/gop_results_review/our_checks')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--root', type=Path, default=BASE, help='Extracted GOP_TOE_FORMALIZATION_v0_1 folder')
parser.add_argument('--output', type=Path, default=OUT, help='New review output folder; must not be the source folder')
args = parser.parse_args()
BASE, OUT = args.root.resolve(), args.output.resolve()
if OUT == BASE or BASE.is_relative_to(OUT):
    raise ValueError('Choose a separate review output folder, not the source folder or its ancestor.')
OUT.mkdir(parents=True, exist_ok=True)

def load_module(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
    return mod

def plain(x):
    if isinstance(x, np.generic):return x.item()
    if isinstance(x,np.ndarray):return x.tolist()
    raise TypeError(type(x).__name__)

def mse(y,p,s):
    r=(p-y)/s
    r=np.nan_to_num(r,nan=1e6,posinf=1e6,neginf=-1e6)
    r=np.clip(r,-1e6,1e6)
    return np.mean(r*r,axis=tuple(range(1,r.ndim)))

report={"scope":"Independent arithmetic and bounded deterministic reproduction. Not new confirmation, not verification of original historical execution or fundamental physics.","pickle_files_loaded":False}
raw=[json.loads(s) for s in (BASE/'results/raw_metrics.jsonl').read_text().splitlines() if s.strip()]
index={(r['family'],int(r['world_id']),r['model']):r for r in raw}
manifest=[json.loads(s) for s in (BASE/'data/manifests/worlds.jsonl').read_text().splitlines() if s.strip()]
report['counts']={'raw_metric_rows':len(raw),'unique_metric_keys':len(index),'manifest_rows':len(manifest),'independent_family_worlds':len({(r['family'],r['world_id']) for r in manifest})}
summary=json.loads((BASE/'results/empirical_run_summary.json').read_text())
report['declared_training_and_test_seconds']=summary['numerical_seconds_combined']
report['families']=[];max_error=0.;metric_checks=0
for path in sorted((BASE/'predictions').glob('*_locked.npz')):
    fam=path.stem[:3]
    with np.load(path,allow_pickle=False) as d:
        worlds=d['world_ids']; types=d['test_types']; scale=d['scale'];y1=d['truth1'];y16=d['truth16']
        scores={};rollout_scores={}
        for key in sorted(d.files):
            if not key.startswith('pred1__'):continue
            model=key.split('__',1)[1]
            scores[model]=mse(y1,d[key],scale)
            rollout_scores[model]=mse(y16,d['pred16__'+model],scale)
            for j,w in enumerate(worlds):
                row=index[(fam,int(w),model)]
                for name,v in [('mse1',scores[model][j]),('mse16',rollout_scores[model][j])]:
                    err=abs(float(v)-row[name]);max_error=max(max_error,err);metric_checks+=1
                    assert np.isclose(v,row[name],rtol=3e-10,atol=3e-12),(fam,w,model,name,v,row[name])
        src=next(x for x in summary['families'] if x['family']==fam)
        item={'family':fam,'worlds':len(worlds),'F0_P_mean_1step':float(scores['F0_P'].mean()),'comparator':src['comparator'],
              'comparator_mean_1step':float(scores[src['comparator']].mean()),'source_decision':src['status'],
              'F0_P_mean_16step':float(rollout_scores['F0_P'].mean()),'divergent_worlds_16step':int(d['diverged16__F0_P'].sum()),
              'all_model_1step_means':{k:float(v.mean()) for k,v in scores.items()},
              'strata':{}}
        for t in np.unique(types):
            select=types==t
            item['strata'][str(t)]={'n_worlds':int(select.sum()),'F0_P_1step':float(scores['F0_P'][select].mean()),
                 'comparator_1step':float(scores[src['comparator']][select].mean()),
                 'all_model_1step_means':{k:float(v[select].mean()) for k,v in scores.items()}}
        report['families'].append(item)
report['own_metric_check']={'metric_values':metric_checks,'world_model_rows':metric_checks//2,'all_passed':True,'max_abs_difference':max_error}
# Regenerate only known archived reference targets; no fitting or new test set.
gen=load_module('review_reference',BASE/'src/reference_worlds/generators.py')
qgen=load_module('review_quantum_reference',BASE/'src/reference_worlds/quantum.py')
report['reference_target_reproduction']={}
for path in sorted((BASE/'predictions').glob('*_locked.npz')):
    fam=path.stem[:3];maxdiff=0.;same=True;count=0
    with np.load(path,allow_pickle=False) as d:
        for wi,w in enumerate(d['world_ids']):
            for si,s in enumerate(d['seeds']):
                g=(qgen.generate_quantum(int(w),'locked',int(s),128) if fam=='S09'
                   else gen.generate(fam,int(w),'locked',int(s),128))
                y=np.asarray(g['y'])[2:]; old=d['truth1'][wi,si]
                maxdiff=max(maxdiff,float(np.max(abs(y-old))));same &= bool(np.array_equal(y,old));count+=1
    report['reference_target_reproduction'][fam]={'trajectories':count,'exact_array_match':same,'max_abs_difference':maxdiff}
# Reproduce the actual hybrid loop in a NEW output folder.
f0=load_module('review_f0_generator',BASE/'src/candidates/f0_generator.py')
fresh=f0.run(OUT/'fresh_hybrid')
old=json.loads((BASE/'results/f0_generator_checks.json').read_text())
report['hybrid_reproduction']={'checks_passed':fresh['software_checks_passed'],
 'max_trace_error':fresh['hybrid_max_trace_error'],'first_step':fresh['first_classical_step'],
 'source_trajectory_sha256':hashlib.sha256((BASE/'results/f0_generator_trajectory.csv').read_bytes()).hexdigest(),
 'new_trajectory_sha256':hashlib.sha256((OUT/'fresh_hybrid/f0_generator_trajectory.csv').read_bytes()).hexdigest(),
 'all_summary_fields_exact_match':fresh==old}
# Least-squares fit independently recomputed from stored measurements.
with np.load(BASE/'results/generator_revision/measurements_predictions.npz',allow_pickle=False) as d:
    x=d['train_x'];v=d['train_measured_drift'];grid=d['grid']
    result={}
    for degree in (2,3):
        c=np.linalg.lstsq(np.vander(x,degree+1,increasing=True),v,rcond=None)[0]
        y=np.polynomial.polynomial.polyval(grid,c)
        result[f'degree_{degree}']={'coefficients':c.tolist(),'cubic_drift_error':float(np.max(abs(y+grid+grid**3))),
                                  'quintic_drift_error':float(np.max(abs(y+grid+grid**5)))}
    report['own_generator_refit_from_archived_measurements']=result
# New, explicitly post-review mathematical demo; NOT part of original F0 or its tests.
# For even r, w=x^r gives dx=-x-xw, dw=-r*w-r*w*w.
# Constraint residual e=w-x^r satisfies de=-r*(1+w)*e.
lift_results=[]
for power in (2,4):
    ts=np.linspace(0,2,1001)
    for x0 in (-1.,-.5,.2,.8,1.):
        def rhs(t,z):
            x,w=z
            return [-x-x*w,-power*w-power*w*w]
        sol=solve_ivp(rhs,(0,2),[x0,x0**power],method='DOP853',t_eval=ts,rtol=1e-12,atol=1e-14)
        exact=x0*np.exp(-ts)/(1+x0**power*(1-np.exp(-power*ts)))**(1/power)
        lift_results.append({'original_degree':power+1,'x0':x0,'solver_success':sol.success,
              'x_max_error_against_closed_form':float(np.max(abs(sol.y[0]-exact))),
              'constraint_max_abs_residual':float(np.max(abs(sol.y[1]-sol.y[0]**power)))})
report['new_lift_demonstration']={'status':'New reviewer demonstration; NOT an admissible F0-G0 model because it adds a nonlinear auxiliary coordinate. Not a new physical law.',
    'equations':'dx/dt=-x-x*w; dw/dt=-r*w-r*w^2; w(0)=x(0)^r; r=2 or4',
    'constraint_identity':'d(w-x^r)/dt=-r*(1+w)*(w-x^r)',
    'runs':lift_results,'max_x_error':max(x['x_max_error_against_closed_form'] for x in lift_results)}
OUT.mkdir(exist_ok=True)
(OUT/'own_review_results.json').write_text(json.dumps(report,indent=2,default=plain,allow_nan=False)+'\n')
print(json.dumps({k:report[k] for k in ('counts','own_metric_check','hybrid_reproduction','own_generator_refit_from_archived_measurements')},indent=2,default=plain))
print('All reference targets exact:',all(x['exact_array_match'] for x in report['reference_target_reproduction'].values()))
print('NEW LIFT max error',report['new_lift_demonstration']['max_x_error'])
print('S10',json.dumps(report['families'][-1],indent=2))
