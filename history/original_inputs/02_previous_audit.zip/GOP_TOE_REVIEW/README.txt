GOP–TOE v0.1 external review package

Source archive is unchanged and not duplicated here.
Read GOP_TOE_Sonuc_Denetimi_TR.md first.

To repeat the reviewer calculations after extracting the ORIGINAL result archive:
python review_checks.py --root /path/GOP_TOE_FORMALIZATION_v0_1 --output /path/new_review_output

Needs numpy and scipy (tested: 2.3.5 and 1.17.0).
The script loads no pickled model. It recalculates stored metrics, regenerates known reference targets, reruns the fixed hybrid example, and separately tests a NEW two-state lifting demonstration. No claim of fresh confirmation is made.

provided_verifier_rerun.json records the supplied verifier rerun in a copy, not an external proof certificate.
Hash checking confirms internal consistency and original-to-copy equality, not historical execution timing.
