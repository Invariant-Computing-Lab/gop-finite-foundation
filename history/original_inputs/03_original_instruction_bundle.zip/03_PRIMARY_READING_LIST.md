# Additional primary-source starting points

**Scope:** nine sources to guide the mathematical extension. Primary records/abstracts checked on 2 October 2026. This is not a systematic review, and the preparation of this list did not verify every derivation in the full texts. Inspect the relevant full text before using a theorem. Do not relabel an imported framework as a new GOP discovery.

## R1 — Composable classical probability
Tobias Fritz. **A synthetic approach to Markov kernels, conditional independence and theorems on sufficient statistics.** *Advances in Mathematics* 370 (2020), 107239. Preprint first posted 2019.
- Primary record: https://arxiv.org/abs/1908.07021
- DOI: 10.1016/j.aim.2020.107239
- Use: formal composition of classical probabilistic processes and sufficient-statistic questions.
- Boundary: classical copying/conditioning rules cannot automatically be transferred to arbitrary quantum systems.

## R2 — Quantum processes and composition
Giulio Chiribella, Giacomo M. D'Ariano, Paolo Perinotti. **Theoretical framework for quantum networks.** *Physical Review A* 80 (2009), 022339.
- Primary record: https://arxiv.org/abs/0904.4483
- DOI: 10.1103/PhysRevA.80.022339
- Use: typed quantum processes, instruments, memory, and network composition.
- Boundary: a quantum-network representation alone is not a new physical-unification result.

## R3 — Equation discovery as a serious comparator
Steven L. Brunton, Joshua L. Proctor, J. Nathan Kutz. **Discovering governing equations from data by sparse identification of nonlinear dynamical systems.** *PNAS* 113 (2016), 3932–3937.
- Primary preprint: https://arxiv.org/abs/1509.03580
- Publisher: https://www.pnas.org/doi/10.1073/pnas.1517384113
- DOI: 10.1073/pnas.1517384113
- Use: sparse, interpretable candidate dynamics and baseline comparisons.
- Boundary: basis selection and observability assumptions matter; regression performance alone is not mechanistic identification.

## R4 — Intervention-defined information relevance
Artemy Kolchinsky, David H. Wolpert. **Semantic information, autonomous agency and non-equilibrium statistical physics.** *Interface Focus* 8 (2018), 20180041.
- Primary record: https://arxiv.org/abs/1806.08053
- DOI: 10.1098/rsfs.2018.0041
- Use: counterfactual scrambling of correlations and their relevance to a modeled system's persistence.
- Boundary: a physically specified semantic-information proxy is not a complete measure of human lived meaning.

## R5 — Stochastic thermodynamic accounting
Udo Seifert. **Entropy Production along a Stochastic Trajectory and an Integral Fluctuation Theorem.** *Physical Review Letters* 95 (2005), 040602.
- Primary record: https://arxiv.org/abs/cond-mat/0503686
- DOI: 10.1103/PhysRevLett.95.040602
- Use: trajectory-level entropy accounting and finite-time consistency tests under stated assumptions.
- Boundary: define the reverse process, reservoirs, and driving; use uncertainty-aware sampling rather than equating a noisy estimate with a law violation.

## R6 — Structured physical learning
Sam Greydanus, Misko Dzamba, Jason Yosinski. **Hamiltonian Neural Networks.** *NeurIPS* (2019).
- Primary record: https://arxiv.org/abs/1906.01563
- Use: structure-respecting learned physical dynamics as a baseline or imported component.
- Boundary: learning a Hamiltonian within a Hamiltonian model does not derive Hamiltonian mechanics from GOP.

## R7 — Memory is a testable modeling issue
Felix A. Pollock, César Rodríguez-Rosario, Thomas Frauenheim, Mauro Paternostro, Kavan Modi. **Operational Markov Condition for Quantum Processes.** *Physical Review Letters* 120 (2018), 040405.
- Primary record: https://arxiv.org/abs/1801.09811
- DOI: 10.1103/PhysRevLett.120.040405
- Use: operational treatment of process memory and tests of a memoryless description.
- Boundary: fitting successive reduced-state maps is not sufficient evidence that the full process has no memory.

## R8 — Observer relations in physics
Carlo Rovelli. **Relational quantum mechanics.** *International Journal of Theoretical Physics* 35 (1996), 1637–1678.
- Primary record: https://arxiv.org/abs/quant-ph/9609002
- DOI: 10.1007/BF02302261
- Use: a comparison for how physical descriptions account for observers within the modeled world.
- Boundary: a precedent in interpretation is not evidence for GOP, nor for consciousness causing physical laws.

## R9 — What a reconstruction claim must specify
Giulio Chiribella, Giacomo M. D'Ariano, Paolo Perinotti. **Informational derivation of quantum theory.** *Physical Review A* 84 (2011), 012311.
- Primary record: https://arxiv.org/abs/1011.6451
- DOI: 10.1103/PhysRevA.84.012311
- Use: an example of clearly stated informational assumptions in a reconstruction program.
- Boundary: importing its axioms or its conclusion is not independently deriving them from occupation; identify all additional assumptions.

## Additional verification tasks for Astra

Use the original paper for occupational-science foundations, operational agency, normative pluralism, provenance, causal inference, and proper scoring rules. Verify the specific material actually used. Where GKSL generators, minimum-description-length selection, identifiability theorems, control methods, or relativistic/field-theoretic claims become load-bearing, obtain and cite the relevant primary sources rather than relying on this prompt as authority.

External articles themselves are not redistributed in this package. Only bibliographic metadata and short purpose notes are included.
