# ASTRA MASTER EXECUTION PROMPT
## Generalized Occupation → a falsifiable Theory-of-Everything candidate
**Instruction package v1.0 · 2 October 2026**
**Task type:** mathematical research, executable synthetic experiments, critical revision, and an English research manuscript.
**This is a request to execute in your available environment, not merely to propose a plan.**

## 0. The user's actual objective — preserve it

The author is **Emirhan Yıldırım, an occupational therapy student and the founder of the Invariant Computing research program**. His research began with early independent physics and a search for a **theory of everything**. Occupational therapy and occupational science became a proposed route toward that original goal, not the chronological origin of his physics interests.

His motivating problem is that empirical knowledge is produced by systems that sense, measure, represent, communicate, receive, interpret, and act within the world they seek to explain. General Occupation Theory (GOT) attempted to remove the restriction of the occupational agent to the individual human. RARI investigates observer, intervention, identity, and boundary problems within that broader ambition.

The user now requests a **substantive, mathematically explicit, revisable candidate with universal explanatory intent**, together with synthetic tests that can reject particular commitments of that candidate. Do NOT quietly substitute a narrow rehabilitation predictor, a generic machine-learning benchmark, or a purely descriptive state-space notation for that objective. Equally, do NOT announce that synthetic data establish a completed theory of everything.

The governing instruction is:

> Construct a candidate with the explicit conjectural claim that ONE common law architecture can account for ALL physically realizable processes, including the observers, representations, communications, and actions occurring within them. Make the claim explicit enough to generate prohibited outcomes, executable predictions, and counterexamples. The claim need not already be true. Its mathematical content must be capable of failing and changing.

“More advanced mathematics” means precise domains, assumptions, operators, dynamics, proofs where possible, empirical restrictions, and executable predictions. It does not mean decorating an unconstrained function with category-theoretic, geometric, quantum, or entropy vocabulary.

Use the working experiment name **GOP–TOE Formalization Study** and scientific version IDs **F0, F1, ...**. This is a study within the existing research architecture, NOT a fifth institutional research program. Preserve RARI, OCIL/OCIR, AFC, and SACRA as distinct programs. Do not relabel historical RARI P1–P8 results.

## 1. Inputs, provenance, and authority

Read `sources/Generalized_Occupation_Paradigm_Paper_v0_1.pdf` completely, including its references. The DOCX is an editable copy, not independent evidence. Read `02_SOURCE_AND_CHANGE_MAP.md` and `03_PRIMARY_READING_LIST.md`.

The v0.1 paper explicitly calls its two state-space equations bookkeeping rather than laws of motion. Your task is to move beyond that limitation, not to claim the original paper already supplied a master law. Keep its source version intact; create a mathematical/synthetic follow-up.

Preserve these commitments from the paper: substrate-open but operationally justified agency; explicit boundaries; endogenous observers; action distinct from imposed intervention; transmission distinct from shared meaning; uncertainty and provenance; normative pluralism; revisable dimensionality; distinct program responsibilities. The current instruction adds a stronger **universality conjecture, candidate dynamics, and actual synthetic falsification**.

If additional author materials are genuinely accessible—GOT, The Reality Law, TOF/TMF, SIF/THF/ISF, physical-theory papers, RARI reports—inspect them and identify exactly what you used. Do not invent missing full texts, reproduce an abstract as if it were a proof, or import unverified historical numerical results. Missing supplementary sources must not block work that can proceed from the attached paper and this instruction.

Create a source ledger with: source ID; exact title/version; access level (full text/abstract/metadata/unavailable); claim supported; page/section; URL or local path; hash if local. Verify newly added technical references with primary sources. The reading list is a starting point, not a completed literature review. Mark the distinction between author proposal, established result, new derivation, conjecture, and simulation observation throughout.

## 2. Operating rules: real work, bounded resources, resumable state

1. Inspect actual files, runtime, installed packages, CPU/GPU/RAM, execution limits, existing jobs, and any workspace budget. Do not invent tools, subagents, cloud access, sessions, or background persistence.
2. Work in a new isolated directory `GOP_TOE_FORMALIZATION_v0_1/`. Do not interrupt unrelated jobs, modify original source files, publish, push repositories, or contact collaborators.
3. Use already available and authorized compute. Do not open paid services, rent machines, buy API credits, or reuse budgets from unrelated projects. Default to local numerical computation rather than repeated paid model calls. Record any explicit budget you actually find; do not infer one from old discussions.
4. Make a small measured smoke run before selecting a full profile. Respect the environment's limits. If no resource limit is supplied, use at most four numerical workers, leave memory headroom, and select an explicit finite wall-time/task budget after profiling. Do not start an unbounded search or training loop. Save this budget before development execution.
5. Use actual subagents only if available. Useful roles are mathematical derivation, independent simulator implementation, and adversarial verification. With one agent, separate these into documented passes; do not claim independent investigators or genuine blinding.
6. Write `STATE.json`, `PROGRESS.md`, `NEXT_ACTION.md`, and append-only run logs before expensive work. Update state atomically after every meaningful result. Checkpoint long runs. Never restart the same running job just because the response was interrupted.
7. Proceed through independent available phases without repeatedly asking “continue?”. A missing dependency blocks the affected branch, not everything. If tools/time end, report the exact checkpoint and actual pending work; do not claim that an unverified background process will continue.
8. Run the code, inspect outputs, verify archived files, and report failures. A plan, unexecuted script, or manuscript with placeholder results is not completion. Negative scientific findings are legitimate completed work.

## 3. First deliverable: a non-vacuous universality claim

Before fitting a model, write `theory/UNIVERSALITY_CONJECTURE.md` and `theory/ASSUMPTION_LEDGER.csv`.

Separate three levels without abandoning the top-level objective:

- **U0 — representation:** a shared typed language can encode specified interactions and observations.
- **U1 — explanation/prediction:** a restricted common dynamical architecture generates testable constraints across different regimes, rather than independently memorizing each.
- **U2 — physical unification:** the same principles recover, constrain, or revise physical laws and the embedded observers that acquire knowledge of them.

Use the strong intended scope, not just the phrase “toward a theory of everything”: **every physically realizable process, whether agentive or not, is conjectured to admit an accountable realization under one common law architecture; sensing, knowing, communicating, and acting are processes within that architecture rather than exceptions to it.** “Every” is the hypothesis being put at risk, not a result already obtained. Non-agentive processes remain physical processes, not occupations by fiat. The scope must include physical dynamics and cannot be reduced to predicting observers' reports alone.

State an ambitious master conjecture covering physically realizable systems and their observer–action loops. Give the conjecture explicit quantifiers, admissible systems, admissible observations/interventions, approximation metric, resolution, prediction horizon, and model-description budget. Then instantiate finite claims that this study can actually test. Keep the full claim and untested obligations visible. A finite synthetic success is support for a specified instance, not proof of universal quantification.

A possible statement schema is:

> There exists a restricted law architecture L, with shared structural commitments, such that each admissible regime admits an explicit realization and observation map under which interventional trajectory predictions agree within a declared error and complexity budget.

Turn this into a precise formulation. In particular:

- Distinguish shared law parameters, world-specific physical parameters, initial/boundary conditions, sensor calibration, agent policies, and numerical discretization.
- Specify which items can be estimated from training data and which must remain fixed at transfer.
- Embeddings cannot encode future trajectories or hidden answers. Their description length, fitting data, and computation count against the model's budget.
- Do not give every family an unrestricted decoder or arbitrary residual dynamics. A universal lookup table or Turing-complete interpreter can encode things without explaining them.
- State what observations the candidate forbids. At least one central restriction must have a concrete candidate-breaking witness.
- State whether “unification” is explanatory derivation, structural analogy, embedding, approximation, or reuse of established laws. These are different achievements.
- Preserve the author's stronger reality/observation thesis as an explicit additional hypothesis. Do not infer physical reality's dependence on human perception merely from mediated access to evidence.

Produce a table of **input assumptions versus intended outputs**. An imported Hamiltonian, Born rule, metric, causal order, or entropy law cannot reappear in the output column as a newly derived fact.

## 4. Mathematical construction: make one actual candidate, not an equation-shaped placeholder

### 4.1 State, roles, and endogenous observers

Define a joint system state that can include environment, agent internal organization, physical sensors, memory, resource variables, actuator states, signal carriers, and communication buffers. Distinguish ontic/model state from recorded data, subjective report, inferred representation, and decision.

Represent the complete cycle:

**world → sensing/measurement (including back-action where relevant) → internal update → action and signal production → physical propagation/channel → reception and interpretation → subsequent world/agent change.**

Represent feedback over time, not with an unexplained simultaneous algebraic circle. Define the causal order or solve the corresponding well-posed fixed-point problem. Delays, limited memory, missing data, and non-Markovian effects cannot vanish by notation. An augmented state is permitted, but its dimension and complexity must be counted.

An experimental perturbation is exogenous relative to a selected subsystem. When claiming global closure, include the controller and apparatus in the larger state. Do not place the scientist outside the proposed universe. Similarly, entropy and energy carried by reservoirs cannot be omitted from a purported closed-system balance.

Agency is an operational hypothesis, not a name assigned to every object. Track individuation, endogenous regulation, interactional influence, persistence/adaptivity, and the source of normative criteria. Distinguish researcher-assigned objectives from intrinsic/model-defined viability. A feedback controller, optimizer, or group is not automatically an autonomous agent.

### 4.2 A recommended mathematical starting route — revisable, not a dogma

Choose and justify one coherent formal backbone. A useful starting candidate is an **operational process architecture with explicitly composed instruments/channels and restricted generators**, which includes a classical stochastic sector and a small quantum-compatible sector.

For the finite classical sector, define measurable state spaces and normalized stochastic kernels. For a finite classical–quantum sector, consider a direct-sum matrix algebra

    A = ⊕_j M_{d_j}(C)

with positive normalized states and physically admissible maps. Purely classical finite states arise when all blocks are one-dimensional; noncommuting blocks support quantum tests. Explain the assumptions and limitations of this choice. Choosing this algebra imports a representational framework; it does not derive quantum theory or the Born rule.

A schematic instrument composition is

    K_{Θ,u} = D_{θ,u} ∘ C_κ ∘ A_π ∘ U_φ ∘ O_ω,

where O models sensing and its physical consequences, U internal update, A actuation/signal production, C propagation/reception, and D remaining environmental evolution. This expression is a starting architecture, NOT the finished answer. Correct its causal ordering and conditional branches, define every map's domain/codomain, and include classical outcome registers. If your regime requires a different ordering or process-memory representation, derive it and record the change.

Supply a valid trajectory probability law and executable inference scheme. For quantum instruments, specify trace-nonincreasing branches whose sum is trace-preserving, normalize conditional states correctly, and account for memory and shared environments. Do not copy an unknown quantum state into a classical memory register or manufacture a positive joint distribution for incompatible observables.

Classical Markov-category composition and quantum process composition are not interchangeable in every respect: classical copying operations must not silently be exported to arbitrary quantum states.

An alternative backbone is allowed if it is better justified. Do not accumulate multiple incompatible formalisms for visual sophistication. Write why each mathematical object is necessary.

### 4.3 An explicit law is mandatory

Go beyond “let f be arbitrary” or “let H be any Hamiltonian.” Supply at least one **fully specified finite, computable F0 candidate**, with a bounded operator/basis library and constrained parameters, covering the loop and several regimes.

Required outputs:

- a numbered **master equation or tightly coupled master system**;
- explicit evolution generators, coupling terms, observation instruments, memory updates, channels, and policy mechanism;
- dimensions/units, initial and boundary conditions, parameter constraints, and numerical integrator;
- at least one fully substituted low-dimensional numerical instance;
- a symbolic form usable for further analysis and a code implementation producing predictions.

Specify a common compositional rule and what is genuinely shared across regimes. Merely adding unrelated classical, quantum, neural, and semantic losses together is not a theory of everything. The data-fitting objective is not the physical law. Label the law, observation process, inference algorithm, and optimization loss separately.

When using familiar dynamics (Hamiltonian, Langevin, master-equation, Lindblad/GKSL, control, or active inference), cite them and identify exactly what additional restriction your candidate introduces. A new notation for an existing model must be described as such.

If no additional unifying constraint survives scrutiny, still produce the strongest explicit candidate and its counterexamples. Report the unification contribution as unestablished; do not invent a theorem or retreat to “it is only a framework” without completing the requested construction and tests.

### 4.4 Geometry and observer equivalence

Define admissible coordinate/observer transformations and distinguish:

- coordinate relabeling or gauge freedom;
- changed physical observation apparatus;
- genuine dynamical intervention;
- coarse-graining or information destruction;
- actual change in the system or its boundary.

Prove invariance/covariance only for a declared transformation class. Test invariant *and* discriminative behavior. A constant representation must be rejected by design.

Define observational/interventional equivalence using equality of induced observable distributions over admissible interventions and a stated horizon. In finite data, use calibrated compatibility sets instead of pretending to have established exact equivalence. A tolerance-based relation need not be transitive; do not call it a mathematical equivalence relation without checking.

For cross-scale or cross-observer maps, test whether transforming then evolving agrees with evolving then transforming, with an explicit error measure. Distinguish an exact commuting diagram from an empirical approximate relation. A learned mapping cannot use held-out trajectories to construct the desired agreement.

Do not force eleven dimensions, a universal metric, or a single efficiency coefficient. Compare dimensional and structural alternatives with complexity penalties and held-out evaluation. Physical units cannot be added indiscriminately. Preserve missing/unmeasured/inapplicable distinctions.

### 4.5 Mathematical obligations

Attempt small, precise results that can actually be checked. For each, supply assumptions, statement, proof or counterexample, dependency on existing results, and numerical tests where relevant:

1. **Compositional validity:** under what conditions composed kernels/instruments remain valid and causal.
2. **Interventional refinement:** exact indistinguishability classes can only refine when the admissible intervention set increases; this does NOT prove finite-sample prediction must improve.
3. **Non-reconstruction:** a genuinely non-injective observation cannot support unique inverse recovery without extra information or restrictions.
4. **Representation transport:** conditions under which an invariant/covariant or sufficiently informative representation preserves the relevant predictions. Explain failures under coarse-graining.
5. **Error accumulation:** a finite-horizon composition bound where available, specifying state versus channel norms and uniformity assumptions. Do not use state trace distance where a channel/ancilla norm is required.
6. **Physical limits:** derive at least one explicit reduction/consistency result in a small classical or quantum regime and distinguish it from an assumed submodel.

Include counterexamples to at least three tempting but false shortcuts: greater similarity means correct recovery; more mutual information means more useful meaning; every feedback system is an autonomous agent; higher Fisher rank means better calibrated uncertainty; every perturbation helps; matching the training trajectory establishes mechanism recovery.

Computer algebra is an aid, not a proof certificate by itself. Numerical checks do not prove universal statements. Do not promise formal proof-assistant verification unless it is actually performed.

### 4.6 Mandatory transparent toy derivation

Reproduce and extend the two-component identification example:

    y0 = x1 + x2,
    yu = k*x1 + x2,  k ≠ 1,
    x1 = (yu-y0)/(k-1),
    x2 = (k*y0-yu)/(k-1).

State the stationarity and selective-intervention assumptions. With independent equal-variance observation noise, derive error amplification as k approaches 1. Add an unknown sensor gain, lossy observation, saturation, and incorrectly labeled interventions. Show exactly what becomes identifiable and what remains gauge-ambiguous. Verify algebra symbolically where possible and statistically by simulation.

Use this as the first executable proof-of-principle, not as the full theory. Its role is to keep the larger mathematics accountable to an example with known answers.

## 5. Physical-theory obligations — keep them in the main study

Create `theory/PHYSICS_RECOVERY_MATRIX.csv`. Do not remove hard sectors to protect a universal label.

Include classical mechanics; stochastic thermodynamics; finite quantum dynamics/measurement; local field propagation and relativistic constraints; gravitation; quantum fields/interactions; agentive/representational processes. For each record one of:

**DERIVED_WITHIN_STATED_ASSUMPTIONS / EMBEDDED_AS_AN_INPUT / APPROXIMATED_AND_TESTED / INCOMPATIBLE_WITH_CURRENT_CANDIDATE / UNRESOLVED / NOT_EXECUTED**.

Then state the precise result, assumptions, source, executable test, and remaining bridge. These labels are not interchangeable.

Minimum executed physical tests should include a conservative oscillator, a dissipative stochastic system, a local propagation toy, and a small quantum system. Add an inverse-square two-body limit when feasible. The latter tests Newtonian compatibility, not general relativity. A finite-speed lattice simulation alone is not Lorentz covariance or a derivation of spacetime. A one-qubit model is not quantum field theory or unification of interactions.

For thermodynamics, define reservoirs, temperature/units, energy/work/heat, reverse process, and entropy-production assumptions before using a fluctuation relation. Rare-event sampling failures must not be declared violations of a physical law. When the environment includes active feedback, account for relevant conditioning/information flows rather than blindly applying an equilibrium identity.

For quantum tests, check positivity, normalization, complete positivity where claimed, Born probabilities conditional on the imported measurement model, measurement back-action, dephasing, and absence of controllable signaling through disconnected channels. Global closed evolution and a reduced open channel must not be confused. Entanglement alone is not a message channel. Include a memory-bearing process to challenge a memoryless approximation if affordable.

If a stronger geometric/gravitational derivation is not achieved, give the exact mathematical obstruction or missing map—not a generic paragraph that the topic is difficult. Continue all executable parts. The current candidate may fail a universality obligation; that is an informative outcome.

## 6. Synthetic worlds: independent ground truth, not self-confirming simulations

Implement independent data generators rather than generating every world from the candidate equation. Separate generator and learner code. Where possible, implement reference and candidate solvers differently and compare both with analytic limits.

Use the following ten benchmark families. Each needs explicit governing equations, known ground truth, observation/intervention mechanisms, a primary estimand, controls, and a failure criterion:

| ID | World family | Main adversarial issue |
|---|---|---|
| S01 | Linear/Gaussian partial observation, the two-component toy, rank deficiency and unknown gains | Identifiability versus gauge freedom; uncertainty under loss |
| S02 | Nonlinear oscillator and chaotic/switching dynamics with observer distortions | Wrong model class, unseen dynamics, saturation; chaos-aware horizons |
| S03 | Hamiltonian oscillator and a small inverse-square two-body system | Conservation, canonical changes, stable integration, long-horizon structure |
| S04 | Langevin or thermodynamically specified jump-process world | Dissipation, reservoirs, stochastic uncertainty, coarse-grained loss |
| S05 | Resource-limited adaptive agent plus matched passive/reactive controls | Endogenous regulation versus assigned reward or generic feedback |
| S06 | Two communicating agents with noise, delay, re-encoding, task/goal changes, and disconnected channels | Transmission versus causal task relevance; no channel, no message effect |
| S07 | Coupled task/duet-like agents with tool substitution and common-input controls | Dyadic organization versus spurious synchrony or more resources |
| S08 | Small local lattice/field propagation model with altered sensors and discretizations | Locality, causal influence cone, coordinate/discretization artifacts |
| S09 | One- or two-qubit systems; incompatible measurements, dephasing, sequential instruments, optional environment memory | Classical/quantum mismatch, back-action, non-Markovian failures |
| S10 | Programmed computation/memory process, including reversible versus information-erasing maps; composite unseen assembly | Lost distinctions, retained provenance, whether cross-domain composition actually transfers |

S06/S07/S05 contain designer-defined proxies for viability, goals, cooperation, or meaning. Explicitly call these **synthetic proxies**, not human lived meaning, autonomy, clinical improvement, or consciousness. Include cases where the observer predicts behavior well while its proxy goal/meaning interpretation is wrong.

Across families include observation-only conditions; random intervention; informative intervention; intervention with no effect; wrong intervention labels; distribution shift; missing-not-at-random observations; sensor permutation/scaling; rank loss; additive and heteroscedastic noise; finite delay; confounding/common input; model mismatch; constant-embedding and disconnected-channel nulls.

### Dataset splitting

Separate **training / development / calibration / locked evaluation** at the level of independently generated worlds. Noise realizations, windows, timesteps, and repeated seeds are nested observations—not new worlds. Keep all windows/observers from a world in its assigned split unless a distinct observer-transfer experiment explicitly requires a different design.

Create separate tests for:

- new initial states/parameters within a known mechanism;
- unseen observer transformations;
- changed intervention policy;
- held-out mechanism variants or coupling topology;
- unseen compositions of previously encountered components.

New seeds in the same mechanism are not “unseen-family generalization.” Zero-shot transfer cannot include hidden refitting. Few-shot transfer must state its adaptation budget and give baselines the same allowance.

Starting planning profiles, to be finalized after resource profiling but before locked evaluation:

- **Smoke:** two worlds per family, two nested noise seeds, short trajectories; software/algebra checks only.
- **Core:** per family, 24 training + 8 development + 8 calibration + 16 locked worlds, with three nested noise seeds; typically 256 classical steps and shorter quantum sequences.
- **Extended:** 64 + 16 + 16 + 32 worlds, five nested seeds, if already authorized resources support it.

These are proposed computational allocations, not power guarantees. Determine whether the fixed independent-world count supports the registered margins. Limited precision means INCONCLUSIVE, not a pass. Freeze the chosen allocation, mechanism holdouts, margins, and compute budget before opening evaluation. Do not expand the sample until a result becomes positive.

Generate sealed evaluation data through a separate verifier process where possible. Hashes preserve identity; they do not by themselves guarantee blinding. If one agent can inspect everything, disclose procedural separation rather than claiming cryptographic or investigator blinding.

## 7. Models, training, controls, and scientific comparators

Fit/calibrate the candidate rather than using only oracle parameters. Report oracle-generator, representation-only, and learned-candidate tracks separately. Ground-truth latent variables are for evaluation unless a clearly labeled oracle track is being run.

Use eligible domain-appropriate baselines, not one weak baseline everywhere:

- persistence/linear state-space and Kalman-type baselines where appropriate;
- sparse equation discovery (including controls where needed), system identification, or delay-state alternatives;
- structured physical baselines for Hamiltonian, stochastic, and quantum sectors;
- a reasonably tuned non-unifying predictor (small MLP/RNN or Gaussian model if practical);
- random intervention and a strong classical experimental-design/information-gain policy;
- the same joint-state/metadata access without the candidate's proposed extra constraint.

All comparisons must state observation, intervention, fitting, hyperparameter-search, parameter-count, and compute budgets. Do not give the candidate truth labels, extra observations, or unlimited search. Equalize information and constrain compute; report unavoidable mismatches.

Train small models sufficient to test the mathematical claim. Huge language-model training is not required. Heavy mathematics is not the same as heavy compute.

Candidate-specific ablations: remove observer conditioning; remove channel memory; remove the agent/environment distinction or its endogenous boundary criterion; remove the unifying constraint; remove physical consistency constraints; force K=11 versus selected alternatives; replace calibrated compatibility sets with point estimates; replace normative vectors with a single utility where the synthetic task supports this comparison.

Do not apply an irrelevant ablation just to populate a table. Label its scope. If AFC's non-null premise is tested, preserve the distinction between mathematical zero, absence, unobserved data, and erasure; do not outlaw zero in every other part of mathematics.

## 8. Scoring and falsification

Freeze a scoring contract before evaluation. For each hypothesis record: independent unit; estimand; metric; eligible comparator; equivalence/non-inferiority/superiority direction; meaningful margin; uncertainty method; multiple-testing treatment; failure criterion.

Use appropriate metrics rather than a single global score:

- parameter/structure identification, modulo declared gauge freedoms;
- one-step and multi-step predictive loss; proper probabilistic scoring where distributions are claimed;
- interventional/counterfactual prediction, supported by the generator's structural assumptions;
- coverage and size of uncertainty/compatibility sets together;
- observer invariance/covariance together with discriminability;
- conservation and positivity residuals with integration/discretization convergence checks;
- communication-channel recovery, intervention-sensitive task relevance, and disconnected-channel false positives;
- reachability/viability and retained options under stated synthetic goal definitions;
- cross-world, cross-observer, and cross-composition transfer;
- complexity and wall-time.

Use world-level paired intervals or a justified hierarchical method. Report effect sizes and raw distributions, not only p-values. Plan multiplicity across primary families/hypotheses; do not change the family after seeing results. Explain when a deterministic algebraic check rather than a statistical test is appropriate.

Suggested numerical checks such as probability normalization near 1 and tiny negative-eigenvalue tolerances must be chosen for floating-point scale and solver accuracy; they are not scientific effect-size margins. Practical predictive margins must be justified and frozen. A relative error reduction with a near-zero denominator must have a predeclared alternative.

Chaotic systems need predeclared finite predictive horizons and/or distributional/structural targets; do not move the goalpost from trajectories to attractors after a failure. Distribution-free coverage must not be claimed through an unexamined distribution shift.

Separate final statuses:

- **SOFTWARE_VERIFIED:** the intended test actually ran correctly.
- **COMPATIBLE_WITH_TEST:** a stated necessary condition survived this finite test.
- **COMPARATIVE_SUPPORT:** the registered advantage is supported within scope.
- **FALSIFIED_IN_REGIME:** a specified candidate restriction failed a valid discriminating test.
- **INCONCLUSIVE / INVALID_TEST / BLOCKED / NOT_RUN.**

There must be no “ToE validated” score. A failed necessary physical condition cannot be averaged away with successes in other families. Distinguish a bug or inaccurate integrator from a theory failure by independent verification before assigning FALSIFIED_IN_REGIME.

## 9. Revision without rewriting history

Freeze F0's definitions, equations, parameterization, source dependencies, data partitions, and score contract before evaluation. Use immutable hashes and retain all failed versions.

Perform at most two development-only revision cycles within the declared run budget. For each change, record the failed prediction, proposed explanation, exact changed equation/assumption, new degrees of freedom, complexity cost, and prospective discriminating test. Prefer the smallest explanatory revision over adding a family-specific exception.

After locked evaluation is inspected, every scientific modification creates a new version. That old evaluation set becomes development history. A new confirmatory claim needs genuinely untouched data/mechanisms and a new frozen contract. Fresh noise seeds alone do not establish a new mechanism-level replication.

Do not run indefinitely until a universal claim appears to pass. If the candidate remains falsified, deliver its explicit form, the strongest counterexample, any supported subclaims, and the next precise revision. This is a successful falsification study, not a reason to fabricate success or silently narrow the original claim.

## 10. Execution sequence and checkpoints

Execute these phases, respecting dependencies:

**00 — Audit and freeze the research objective.** Read source; build provenance/change map; inspect resources; initialize state and source ledger.

**01 — Construct F0.** Produce primitives, master conjecture, explicit candidate dynamics, inference method, equation card, and theory-vs-standard-method comparison. Complete the toy derivation and initial proof/counterexample work. Do not spend the entire run on narrative.

**02 — Build independent generators and verifiers.** Implement reference worlds, observation/intervention interfaces, controls, analytical checks, and artifact schemas. Test generators against known limits before training.

**03 — Smoke execution.** Actually run all feasible families. Fix software bugs; measure resource use. Record blocked sectors and select/freeze the full compute profile. Smoke results are not confirmatory evidence.

**04 — Development, fitting, and bounded revision.** Fit F0 and baselines. Perform ablations and counterexample searches only on allowed data. Attempt deeper proofs/reductions in parallel or sequentially according to real capabilities.

**05 — Freeze confirmation.** Hash candidate, equations, code, environment, hyperparameters, preprocessing, splits, intervention policies, calibration method, metrics, margins, and evaluation code. Calibration may fit predeclared uncertainty parameters but may not become hidden model selection.

**06 — Locked tests and verification.** Save predictions before scoring where practicable. Verify outputs with a separately implemented checker. Do not change science and rerun the same test as confirmation.

**07 — Formal and empirical synthesis.** Write claim-by-claim results, physics recovery matrix, generalization table, failure atlas, and residual obligations. Distinguish representation compatibility from explanatory novelty and physical-law derivation.

**08 — Manuscript, reproducibility, archive.** Generate English LaTeX/PDF and editable text; run a clean reproduction smoke test; inspect tables/equations; verify every result points to an actual artifact; package all logs and failures. Supply a Turkish summary.

After every phase save file hashes, start/end times, actual commands, exit codes, produced artifacts, and next actions. While waiting for a job, follow the same job identifier using an appropriate backoff; do not create duplicate jobs or spend unnecessary model calls polling.

## 11. Required output package

Create a self-contained project, adapting only to actual capabilities:

```
GOP_TOE_FORMALIZATION_v0_1/
  README.md
  STATE.json
  PROGRESS.md
  NEXT_ACTION.md
  RESUME.md
  environment.lock-or-equivalent
  sources/SOURCE_LEDGER.csv
  theory/
    UNIVERSALITY_CONJECTURE.md
    FORMAL_CORE.tex
    EQUATION_CARD.md
    ASSUMPTION_LEDGER.csv
    CLAIM_LEDGER.csv
    PROOFS_AND_COUNTEREXAMPLES.tex
    PHYSICS_RECOVERY_MATRIX.csv
    NOVELTY_AND_BASELINE_MAP.md
    FAILURE_ATLAS.md
  configs/
    frozen_protocol.yaml
    compute_budget.json
  src/
    reference_worlds/
    candidates/
    observations/
    interventions/
    baselines/
    scoring/
    run_pipeline.py
  tests/
  data/manifests/
  predictions/
  models/
  results/
    raw_metrics.jsonl
    hypothesis_status.csv
    transfer_and_ablation_tables.csv
    figures/
  versions/F0/
  revisions/REVISION_LOG.md
  manuscript/
    paper.tex
    references.bib
    paper.pdf
    paper.md
  logs/
  SHA256SUMS.txt
```

Persist enough data/seeds/code for reconstruction; do not pretend filenames alone establish data availability. Checkpoint and model weights are required for actually fitted models. A metric file must trace to specific predictions, configuration, and version.

The suggested follow-up paper title is:

**“A Falsifiable Theory-of-Everything Candidate from Generalized Occupation: Formal Closure and Synthetic Stress Tests.”**

Use this title only while accurately describing the result as a candidate. If no predictive dynamical restriction is achieved, explicitly report that failure in the abstract and avoid disguising a representational framework as a new law. Keep the universal objective visible in the research question.

The main paper should be clear and relatively concise; put full definitions, proofs, assumptions, derivations, hyperparameters, and all negative results in the technical supplement. There is no minimum theorem or page count that licenses filler. Write references only for sources actually verified/read to the stated access level. Preserve authorship/affiliation facts and disclose AI assistance; do not invent collaborators or institutional endorsement.

## 12. Final response: answer these questions with actual artifacts

1. What is the explicit candidate master equation/system, and what do its terms mean?
2. What exactly does its universality conjecture claim, and what does it forbid?
3. What came from the original paper, what is imported mathematics, and what is new?
4. Which statements were proved, which were only simulated, and which remain conjectures?
5. Which worlds, models, counts, and compute were actually run?
6. Where did the candidate beat a fair comparator, merely reproduce an imported law, or fail?
7. What happened to observer ambiguity, uncertainty, communication, agency proxies, and cross-domain composition?
8. Which physical-unification obligations are still unresolved or contradicted?
9. What revisions were made, using which data, and what remained untouched?
10. Where are the executable code, equations, predictions, logs, checkpoints, manuscript, and final archive?

End with an accurate execution status, not an assurance that every hypothesis passed. The goal is a **serious universal candidate made vulnerable to evidence**, not a guaranteed positive result.

**Start now with source inspection and state initialization, then derive, implement, execute, critique, and package the work. Do not stop after returning this plan.**
