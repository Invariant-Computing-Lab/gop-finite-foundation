# Astra: Genelleştirilmiş Okupasyon → sınanabilir her şeyin teorisi adayı

Bu paket, v0.1 paradigma makalesini açık matematiksel dinamiklere ve gerçek sentetik deneylere ilerletmek için hazırlanmış bir **görev komutudur**. İçinde çalıştırılmış deney sonucu veya kanıtlanmış bir ana yasa yoktur.

## Kullanım

Paketi Astra'ya ekle ve `00_ASTRA_BASLAT_TR.txt` içeriğini mesaj olarak gönder. Ayrıntılı ve yetkili görev dosyası `01_ASTRA_MASTER_PROMPT_EN.md` dosyasıdır. Tek metin tercihinde bu dosyanın tamamı doğrudan yapıştırılabilir. Makalenin PDF ve Word kopyaları `sources/` içindedir.

## Komutun istediği işler

Açık bir evrensellik savı; boş fonksiyonlar yerine kısıtlanmış ve hesaplanabilir F0 aday denklemi; gözlem–temsil–iletişim–eylem döngüsü; ispatlar veya karşı örnekler; on sentetik dünya ailesi; fiziksel tutarlılık sınamaları; adil karşılaştırmalar; ayrı geliştirme/kalibrasyon/kapalı test; değiştirilemez sürümler; gerçek kod, veri üretimi, eğitim, log, rapor ve makale teslimi.

Her şeyin teorisi iddiası korunur, fakat sınırlı sentetik başarıdan evrensel doğrulama sonucu çıkarılmaz. Aday başarısız olabilir ve değişebilir. Görevin tamamlanması, bütün hipotezlerin başarılı olması demek değildir.

## Dosyalar

- `00_ASTRA_BASLAT_TR.txt`: Astra'ya gönderilecek başlangıç mesajı.
- `01_ASTRA_MASTER_PROMPT_EN.md`: Yaklaşık 5.000 kelimelik ayrıntılı yürütme komutu.
- `02_SOURCE_AND_CHANGE_MAP.md`: Kaynak makalenin söyledikleri ile bu görevde istenen yeni katkıların ayrımı.
- `03_PRIMARY_READING_LIST.md`: Dokuz ek birincil teknik kaynak ve kullanım sınırları.
- `04_KESINTIDEN_DEVAM_TR.txt`: Kesintide aynı çalışmaya devam komutu.
- `sources/`: Kaynak makalenin değiştirilmemiş PDF ve DOCX kopyaları.
- `PACKAGE_MANIFEST.json`, `SHA256SUMS.txt`: Paket kimliği ve dosya bütünlüğü kayıtları.

Astra'nın gerçek araçları ve mevcut izinli hesaplama kaynakları başlangıçta denetlenecektir. Komut herhangi bir yeni ücretli hizmet açma, dışarıda yayımlama veya ilgisiz işlere müdahale etme yetkisi vermez.
